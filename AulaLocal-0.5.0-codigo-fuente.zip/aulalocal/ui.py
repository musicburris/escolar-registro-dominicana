import sys, time, traceback, secrets
from datetime import date, datetime
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QLockFile, QEvent, QUrl, QDate, QTime
from PySide6.QtGui import QDesktopServices, QAction, QFont
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,QPushButton,QLineEdit,QTextEdit,QComboBox,QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,QDialog,QDialogButtonBox,QFormLayout,QScrollArea,QMessageBox,QFileDialog,QInputDialog,QListWidget,QFrame,QCheckBox,QGroupBox,QDateEdit,QTimeEdit)
from .core import Store,AppError,app_directory,local_now,timezone_label
from .catalog import MODULES,ACCESS,ROLES
from . import reports
from .backup import create_backup,restore_backup,atomic_write
from .assistant import interpret

STYLE='''
QMainWindow,QDialog {background:#F4F7FA;color:#142B3A;}
QWidget {font-size:13px;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text";}
QLabel#brand {font-size:25px;font-weight:750;color:#102F3E;}
QLabel#title {font-size:30px;font-weight:750;color:#102F3E;}
QLabel#muted {color:#607482;font-size:12px;}
QLabel#clock {color:#315465;font-size:12px;font-weight:600;}
QFrame#card,QGroupBox {background:#FFFFFF;border:1px solid #DDE7EC;border-radius:14px;margin-top:7px;}
QGroupBox::title {subcontrol-origin:margin;left:14px;padding:0 5px;color:#47616F;font-weight:650;}
QPushButton {background:#FFFFFF;border:1px solid #C9D8E0;border-radius:9px;padding:9px 14px;color:#173B4B;font-weight:550;}
QPushButton:hover {background:#EAF4F6;border-color:#9FC3CB;}
QPushButton#primary {background:#087F8C;color:white;border:1px solid #087F8C;font-weight:700;}
QPushButton#primary:hover {background:#076D78;}
QPushButton:disabled {color:#91A0A9;background:#EDF1F3;}
QLineEdit,QTextEdit,QComboBox {background:#FFFFFF;border:1px solid #C8D7DF;border-radius:8px;padding:8px;color:#142F40;selection-background-color:#087F8C;}
QLineEdit:focus,QTextEdit:focus,QComboBox:focus {border:2px solid #2F98A2;}
QListWidget {background:#123847;color:#DFEDF1;border:0;border-radius:14px;padding:10px;outline:0;}
QListWidget::item {padding:13px 11px;border-radius:8px;margin:2px 0;}
QListWidget::item:hover {background:#1D4C5C;}
QListWidget::item:selected {background:#087F8C;color:white;font-weight:650;}
QTableWidget {background:#FFFFFF;alternate-background-color:#F5F9FA;border:1px solid #DDE7EC;border-radius:10px;gridline-color:#EDF2F4;selection-background-color:#D9F0F2;selection-color:#173B4B;}
QHeaderView::section {background:#E8F0F3;color:#274957;padding:11px;border:0;border-right:1px solid #D9E4E9;font-weight:650;}
QStatusBar {background:#FFFFFF;border-top:1px solid #DDE7EC;color:#54707E;}
'''

def label(text,name=None):
    w=QLabel(text); w.setTextFormat(Qt.PlainText); w.setWordWrap(True)
    if name: w.setObjectName(name)
    return w

def button(text,fn,primary=False):
    b=QPushButton(text); b.clicked.connect(fn)
    if primary:b.setObjectName('primary')
    return b

def clear_layout(layout):
    while layout.count():
        item=layout.takeAt(0)
        if item.widget():
            item.widget().hide(); item.widget().deleteLater()
        elif item.layout(): clear_layout(item.layout())

def error(parent,e): QMessageBox.warning(parent,'No se pudo completar',str(e))

def ask_password(parent,prompt):
    text,ok=QInputDialog.getText(parent,'Confirmación',prompt,QLineEdit.Password)
    return text if ok else None

def table_widget(headers,rows):
    t=QTableWidget(len(rows),len(headers)); t.setHorizontalHeaderLabels(headers)
    for i,row in enumerate(rows):
        for j,value in enumerate(row):
            item=QTableWidgetItem(str(value)); item.setToolTip(str(value)); t.setItem(i,j,item)
    t.setSelectionBehavior(QAbstractItemView.SelectRows); t.setSelectionMode(QAbstractItemView.SingleSelection)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers); t.setAlternatingRowColors(True); t.verticalHeader().setVisible(False)
    t.horizontalHeader().setSectionResizeMode(QHeaderView.ResizeToContents); t.horizontalHeader().setStretchLastSection(True)
    t.verticalHeader().setDefaultSectionSize(40)
    return t

class Form(QDialog):
    def __init__(self,parent,title,fields,values=None,store=None,year=None):
        super().__init__(parent); self.setWindowTitle(title); self.resize(650,620); self.inputs={}; self.fields=fields
        outer=QVBoxLayout(self); outer.addWidget(label(title,'brand')); outer.addWidget(label('Los campos con * son obligatorios. Fechas: AAAA-MM-DD.','muted'))
        scroll=QScrollArea(); scroll.setWidgetResizable(True); content=QWidget(); form=QFormLayout(content); form.setVerticalSpacing(12); values=values or {}
        for f in fields:
            value=values.get(f.key,'')
            if f.type=='choice':
                w=QComboBox(); w.addItems(f.options)
                if value: w.setCurrentText(str(value))
            elif f.type=='service_choice':
                w=QComboBox();w.setEditable(True);w.addItems(store.food_services())
                if value and w.findText(str(value))<0:w.addItem(str(value))
                if value:w.setCurrentText(str(value))
            elif f.type in ('staff_ref','menu_ref'):
                w=QComboBox(); w.addItem('Seleccione…','')
                target='staff' if f.type=='staff_ref' else 'menus'
                for r in store.list_records(target,year):
                    d=r['data']; text=d['nombre']
                    if target=='menus' and d.get('estado')!='Activo' and r['id']!=value:continue
                    if target=='menus': text+=f" · {d['servicio']} · {d['ciclo']} · {d['dia']}"
                    w.addItem(text,r['id'])
                idx=w.findData(value); w.setCurrentIndex(max(0,idx))
            elif f.type=='level_ref':
                w=QComboBox();w.addItem('Seleccione…','')
                for item in store.academic_levels():w.addItem(item['name'],item['id'])
                idx=w.findText(str(value));w.setCurrentIndex(max(0,idx))
            elif f.type=='grade_ref':
                w=QComboBox();w.setProperty('initialValue',str(value))
            elif f.type=='section_ref':
                w=QComboBox();w.setProperty('initialValue',str(value))
            elif f.type=='date':
                w=QDateEdit();w.setCalendarPopup(True);w.setDisplayFormat('dd/MM/yyyy');w.setMinimumDate(QDate(1900,1,1));w.setMaximumDate(QDate(2100,12,31));w.setSpecialValueText('Seleccione una fecha')
                parsed=QDate.fromString(str(value),Qt.ISODate);w.setDate(parsed if parsed.isValid() else w.minimumDate())
                if not parsed.isValid():w.calendarWidget().setCurrentPage(QDate.currentDate().year(),QDate.currentDate().month())
            elif f.type=='time':
                w=QTimeEdit();w.setDisplayFormat('hh:mm AP');w.setMinimumTime(QTime(0,0));w.setSpecialValueText('Seleccione una hora')
                parsed=QTime.fromString(str(value),'HH:mm');w.setTime(parsed if parsed.isValid() else w.minimumTime())
            elif f.type=='long': w=QTextEdit(); w.setPlainText(str(value)); w.setMinimumHeight(85); w.setMaximumHeight(120)
            else:
                w=QLineEdit(str(value))
                if f.type=='password': w.setEchoMode(QLineEdit.Password)
                if f.type=='date': w.setPlaceholderText('AAAA-MM-DD')
                if f.type=='time': w.setPlaceholderText('HH:MM')
                if f.type=='money': w.setPlaceholderText('0.00')
            self.inputs[f.key]=w; form.addRow(f.label+(' *' if f.required else ''),w)
        if all(k in self.inputs for k in ('nivel','grado','seccion')):
            def grades():
                level=self.inputs['nivel'].currentData();current=self.inputs['grado'].currentText() or self.inputs['grado'].property('initialValue')
                self.inputs['grado'].clear();self.inputs['grado'].addItem('Seleccione…','')
                for item in store.grades(level):self.inputs['grado'].addItem(item['name'],item['id'])
                self.inputs['grado'].setCurrentIndex(max(0,self.inputs['grado'].findText(str(current))));sections()
            def sections():
                grade=self.inputs['grado'].currentData();current=self.inputs['seccion'].currentText() or self.inputs['seccion'].property('initialValue')
                self.inputs['seccion'].clear();self.inputs['seccion'].addItem('Seleccione…','')
                for item in store.sections(year,grade):self.inputs['seccion'].addItem(item['name'],item['id'])
                self.inputs['seccion'].setCurrentIndex(max(0,self.inputs['seccion'].findText(str(current))))
            self.inputs['nivel'].currentIndexChanged.connect(grades);self.inputs['grado'].currentIndexChanged.connect(sections);grades()
        if all(k in self.inputs for k in ('servicio','menu')):
            menu=self.inputs['menu'];selected=values.get('menu','');records=store.list_records('menus',year)
            def load_menus():
                current=menu.currentData() or selected;service=self.inputs['servicio'].currentText();menu.clear();menu.addItem('Seleccione…','')
                for r in records:
                    d=r['data']
                    if d.get('servicio')==service and (d.get('estado')=='Activo' or r['id']==current):menu.addItem(f"{d['nombre']} · {d['ciclo']} · {d['dia']}",r['id'])
                menu.setCurrentIndex(max(0,menu.findData(current)))
            self.inputs['servicio'].currentTextChanged.connect(load_menus);load_menus()
        scroll.setWidget(content); outer.addWidget(scroll)
        self.buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); self.buttons.button(QDialogButtonBox.Save).setText('Guardar'); self.buttons.button(QDialogButtonBox.Cancel).setText('Cancelar')
        self.buttons.accepted.connect(self.accept); self.buttons.rejected.connect(self.reject); outer.addWidget(self.buttons)
    def values(self):
        out={}
        for f in self.fields:
            w=self.inputs[f.key]
            if f.type in ('staff_ref','menu_ref'):out[f.key]=w.currentData()
            elif isinstance(w,QDateEdit):out[f.key]='' if w.date()==w.minimumDate() else w.date().toString(Qt.ISODate)
            elif isinstance(w,QTimeEdit):out[f.key]='' if w.time()==w.minimumTime() else w.time().toString('HH:mm')
            elif isinstance(w,QComboBox):out[f.key]=w.currentText()
            elif isinstance(w,QTextEdit):out[f.key]=w.toPlainText()
            else:out[f.key]=w.text()
        return out

class Login(QDialog):
    def __init__(self,store):
        super().__init__(); self.store=store; self.setWindowTitle('AulaLocal · Acceso'); self.setFixedWidth(450)
        l=QVBoxLayout(self); l.setContentsMargins(32,32,32,32); l.setSpacing(16); l.addWidget(label('AulaLocal','title')); l.addWidget(label('Gestión escolar, en tu Mac.','muted'))
        self.setup=not store.initialized(); self.inputs={}; f=QFormLayout()
        fields=[('username','Usuario'),('password','Contraseña')]
        if self.setup: fields=[('school','Nombre del centro'),('name','Nombre del director'),*fields,('repeat','Repita la contraseña')]
        for key,title in fields:
            w=QLineEdit()
            if key in ('password','repeat'):w.setEchoMode(QLineEdit.Password)
            self.inputs[key]=w; f.addRow(title,w)
        l.addLayout(f)
        if self.setup:l.addWidget(label('La contraseña debe tener al menos 12 caracteres. Al terminar recibirás un código de recuperación para guardarlo en un lugar seguro.','muted'))
        else:
            self.remember=QCheckBox('Mantener mi sesión iniciada en este Mac');self.remember.setChecked(True);l.addWidget(self.remember)
        self.message=label(''); self.message.setStyleSheet('color:#a12d3a;'); l.addWidget(self.message)
        l.addWidget(button('Configurar mi centro' if self.setup else 'Entrar',self.submit,True))
        if not self.setup:l.addWidget(button('Olvidé mi usuario o contraseña',self.recover))
        self.inputs['password'].returnPressed.connect(self.submit)
    def submit(self):
        d={k:w.text() for k,w in self.inputs.items()}
        try:
            if self.setup:
                if d['password']!=d['repeat']:raise AppError('Las contraseñas no coinciden.')
                recovery=self.store.bootstrap(d['username'],d['password'],d['name'],d['school'])
                QMessageBox.information(self,'Guarda tu código de recuperación',f'Este código permite recuperar el acceso sin internet. Guárdalo fuera del Mac y no lo compartas.\n\n{recovery}\n\nPor seguridad solo se muestra ahora; podrás generar otro desde Usuarios y permisos.')
            else:self.store.login(d['username'],d['password'],self.remember.isChecked())
            self.accept()
        except AppError as e:self.message.setText(str(e))
    def recover(self):
        d=QDialog(self);d.setWindowTitle('Recuperar acceso');d.resize(520,300);layout=QVBoxLayout(d)
        layout.addWidget(label('Recuperar usuario y contraseña','brand'));layout.addWidget(label('Escribe el código de recuperación guardado al configurar la cuenta. Este proceso funciona completamente sin internet.','muted'))
        form=QFormLayout();code=QLineEdit();username=QLineEdit();password=QLineEdit();repeat=QLineEdit();password.setEchoMode(QLineEdit.Password);repeat.setEchoMode(QLineEdit.Password)
        form.addRow('Código de recuperación',code);form.addRow('Nuevo usuario',username);form.addRow('Nueva contraseña',password);form.addRow('Repita la contraseña',repeat);layout.addLayout(form)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Save).setText('Recuperar acceso');buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);layout.addWidget(buttons)
        while d.exec()==QDialog.Accepted:
            try:
                if password.text()!=repeat.text():raise AppError('Las contraseñas no coinciden.')
                new_code=self.store.recover_access(code.text(),username.text(),password.text());self.inputs['username'].setText(username.text());QMessageBox.information(self,'Acceso recuperado',f'Tu usuario y contraseña fueron actualizados. Entra con los datos nuevos.\n\nGuarda este nuevo código de recuperación; el anterior ya no funciona:\n\n{new_code}');return
            except AppError as e:error(d,e)

class MainWindow(QMainWindow):
    def __init__(self,store):
        super().__init__();QApplication.instance().setQuitOnLastWindowClosed(False); self.store=store; self.setWindowTitle('AulaLocal'); self.resize(1380,880); self.setMinimumSize(1100,720); self.current='dashboard'; self.rows=[]
        root=QWidget(); self.setCentralWidget(root); layout=QHBoxLayout(root); layout.setContentsMargins(22,22,22,22); layout.setSpacing(24)
        sidebar=QVBoxLayout(); brand=label('AulaLocal','brand'); sidebar.addWidget(brand); sidebar.addWidget(label('GESTIÓN DEL CENTRO','muted'))
        self.nav=QListWidget(); self.nav.setFixedWidth(248);self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); self.keys=['dashboard']+list(ACCESS[store.user['role']]); self.keys=['dashboard']+[k for k in MODULES if k in ACCESS[store.user['role']]]
        if store.user['role'] in ('admin','direccion'):self.keys+=['audit']
        if store.user['role']=='admin':self.keys+=['academic','years','settings','users','backup']
        self.keys+=['assistant','help']
        names={'dashboard':'Dirección','audit':'Auditoría','academic':'Estructura académica','years':'Años escolares','settings':'Mi centro','users':'Usuarios y permisos','backup':'Copias y restauración','assistant':'Asistente local','help':'Ayuda e instructivo'}
        symbols={'dashboard':'◆','students':'●','staff':'●','attendance':'✓','menus':'◫','receipts':'▣','expenses':'$','facilities':'⌂','visits':'↪','deliveries':'□','reminders':'◷','coaching':'◇','audit':'◎','academic':'▦','years':'◷','settings':'⚙','users':'♙','backup':'⇩','assistant':'✦','help':'?'}
        for k in self.keys:self.nav.addItem(f"{symbols.get(k,'•')}  {MODULES[k][0] if k in MODULES else names[k]}")
        sidebar.addWidget(self.nav,1); sidebar.addWidget(label('100 % local · Sin telemetría','muted')); sidebar.addWidget(button('Cerrar sesión',self.lock))
        layout.addLayout(sidebar)
        right=QVBoxLayout(); layout.addLayout(right,1)
        top=QHBoxLayout(); self.school=label(store.settings()['centro'],'brand'); top.addWidget(self.school,1)
        top.addWidget(label('Año escolar')); self.year_combo=QComboBox(); self.year_combo.setMinimumWidth(200); top.addWidget(self.year_combo); right.addLayout(top)
        identity=QHBoxLayout();self.identity=label(f"{store.user['name']} · {ROLES[store.user['role']]}",'muted');self.identity.setWordWrap(False);identity.addWidget(self.identity);identity.addStretch();self.clock=label('','clock');self.clock.setWordWrap(False);identity.addWidget(self.clock);right.addLayout(identity)
        self.body=QVBoxLayout(); self.body.setSpacing(15); right.addLayout(self.body,1)
        self.statusBar().showMessage('Listo. Los cambios se guardan localmente.')
        self.refresh_years(); self.nav.currentRowChanged.connect(self.navigate); self.year_combo.currentIndexChanged.connect(self.render); self.nav.setCurrentRow(0)
        self.timer=QTimer(self); self.timer.timeout.connect(self.check_session); self.timer.start(1000);self.check_session()
        QApplication.instance().installEventFilter(self)
        self.reminder_timer=QTimer(self);self.reminder_timer.setSingleShot(True);self.reminder_timer.timeout.connect(self.show_due_reminders);self.reminder_timer.start(900)
    def eventFilter(self,obj,event):
        if self.store.user and event.type() in (QEvent.KeyPress,QEvent.MouseButtonPress,QEvent.Wheel):
            self.store.last_active=time.monotonic()
        return super().eventFilter(obj,event)
    def closeEvent(self,event):
        self.timer.stop();self.reminder_timer.stop();QApplication.instance().removeEventFilter(self);super().closeEvent(event)
    def check_session(self):
        if not self.store.user:self.lock();return
        self.clock.setText(local_now().strftime('%d/%m/%Y · %I:%M:%S %p')+' · '+timezone_label())
    def lock(self):
        app=QApplication.instance(); app.setQuitOnLastWindowClosed(False)
        self.timer.stop();self.reminder_timer.stop(); self.store.logout()
        for child in self.findChildren(QDialog): child.reject()
        self.hide();app.processEvents()
        login=Login(self.store)
        if login.exec()==QDialog.Accepted:
            replacement=MainWindow(self.store); app.main_window=replacement; replacement.show(); self.close(); self.deleteLater(); app.setQuitOnLastWindowClosed(True)
        else:self.close(); app.quit()
    def safe(self,fn):
        try:return fn()
        except AppError as e:error(self,e)
        except Exception as exc:
            code=datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(2).upper()
            try:
                with (self.store.root/'errores.log').open('a',encoding='utf-8') as log:
                    log.write(f'\n[{code}] {datetime.now().astimezone().isoformat()}\n{traceback.format_exc()}')
            except OSError:pass
            error(self,f'No se pudo completar la operación.\n\nCódigo: {code}\nDetalle: {type(exc).__name__}: {exc}\n\nLa información técnica quedó guardada localmente en errores.log.')
    def year_id(self):return self.year_combo.currentData()
    def refresh_years(self):
        old=self.year_id(); self.year_combo.blockSignals(True); self.year_combo.clear()
        for y in self.store.years():self.year_combo.addItem(f"{y['label']} · {y['status']}",y['id'])
        idx=self.year_combo.findData(old)
        if idx>=0:self.year_combo.setCurrentIndex(idx)
        self.year_combo.blockSignals(False)
    def navigate(self,index):
        if index>=0:self.current=self.keys[index]; self.render()
    def render(self,*_):self.safe(self._render)
    def _render(self):
        self.store.require(); clear_layout(self.body)
        if self.current in ('dashboard','audit') or self.current in MODULES:
            if not self.year_id():
                self.body.addWidget(label('Comienza con tu primer año escolar','title')); self.body.addWidget(label('Crea el período, por ejemplo 2026-2027, para registrar matrículas y movimientos.'))
                if self.store.user['role']=='admin':self.body.addWidget(button('Crear año escolar',lambda:self.safe(self.new_year),True))
                self.body.addStretch();return
        if self.current=='dashboard':self.dashboard()
        elif self.current in MODULES:self.module()
        else:getattr(self,self.current+'_page')()
    def dashboard(self):
        self.body.addWidget(label('Dirección','title')); self.body.addWidget(label('Resumen del año seleccionado. Los totales se calculan a partir de tus registros.','muted'))
        grid=QGridLayout()
        for i,(key,value) in enumerate(self.store.dashboard(self.year_id()).items()):
            card=QFrame(); card.setObjectName('card'); v=QVBoxLayout(card); v.setContentsMargins(20,18,20,18); v.addWidget(label(key,'muted')); v.addWidget(label(str(value),'title')); grid.addWidget(card,i//3,i%3)
        self.body.addLayout(grid); self.body.addWidget(label('Las cantidades de alimentación representan unidades aceptadas acumuladas; no equivalen a estudiantes atendidos. La asistencia de hoy cuenta los registros presentes y con tardanza.','muted'))
        self.body.addStretch(); self.body.addWidget(button('Actualizar indicadores',self.render))
    def module(self):
        kind=self.current; self.body.addWidget(label(MODULES[kind][0],'title'))
        toolbar=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText('Buscar en los registros de este año…'); toolbar.addWidget(self.search,1)
        editable=self.store.user['role']!='consulta' and self.store.year(self.year_id())['status']=='abierto'
        b=button('Nuevo registro',lambda:self.safe(self.new_record),True); b.setEnabled(editable); toolbar.addWidget(b)
        b=button('Editar',lambda:self.safe(self.edit_record)); b.setEnabled(editable); toolbar.addWidget(b)
        self.body.addLayout(toolbar)
        if kind=='students':
            filters=QHBoxLayout();filters.addWidget(label('Organizar por:'))
            self.level_filter=QComboBox();self.level_filter.addItem('Todos los niveles','')
            for level in self.store.academic_levels():self.level_filter.addItem(level['name'],level['id'])
            self.grade_filter=QComboBox();self.grade_filter.addItem('Todos los grados','');self.section_filter=QComboBox();self.section_filter.addItem('Todas las secciones','')
            def update_grades():
                self.grade_filter.blockSignals(True);self.grade_filter.clear();self.grade_filter.addItem('Todos los grados','')
                for grade in self.store.grades(self.level_filter.currentData() or None):self.grade_filter.addItem(grade['name'],grade['id'])
                self.grade_filter.blockSignals(False);update_sections()
            def update_sections():
                self.section_filter.blockSignals(True);self.section_filter.clear();self.section_filter.addItem('Todas las secciones','')
                for section in self.store.sections(self.year_id(),self.grade_filter.currentData() or None):
                    if not self.level_filter.currentText().startswith('Todos') and section['level']!=self.level_filter.currentText():continue
                    self.section_filter.addItem(f"{section['name']} · {section['grade']}",section['name'])
                self.section_filter.blockSignals(False)
                if getattr(self,'table',None) is not None and self.table.isVisible():self.fill_table()
            self.level_filter.currentIndexChanged.connect(update_grades);self.grade_filter.currentIndexChanged.connect(update_sections);self.section_filter.currentIndexChanged.connect(self.fill_table)
            for w in (self.level_filter,self.grade_filter,self.section_filter):filters.addWidget(w)
            filters.addStretch();self.body.addLayout(filters);update_grades()
        self.table=table_widget([],[]); self.body.addWidget(self.table,1); self.search.textChanged.connect(self.fill_table); self.table.doubleClicked.connect(lambda _:self.safe(self.edit_record))
        self.fill_table()
        actions=[('Ver ficha',self.view_detail),('Detalle PDF',self.detail_pdf),('Reporte PDF',lambda:self.export('pdf')),('Excel',lambda:self.export('xlsx')),('Adjuntos',self.attachments_dialog)]
        if kind in ('students','staff'):
            actions.extend([('Importar Excel',self.import_excel),('Descargar plantilla',self.import_template)])
        if kind in ('staff','students') and self.store.user['role'] in ('admin','direccion','secretaria'):actions.append(('Emitir constancia',self.letter))
        if kind=='menus':actions.extend([('Retirar menú',self.retire_menu),('Tipos de alimentación',self.food_services_dialog)])
        action_grid=QGridLayout();action_grid.setHorizontalSpacing(10);action_grid.setVerticalSpacing(8)
        for i,(text,fn) in enumerate(actions):
            b=button(text,lambda checked=False,f=fn:self.safe(f),text=='Importar Excel');action_grid.addWidget(b,i//4,i%4)
        self.body.addLayout(action_grid)
        hint='Doble clic para editar. Los reportes respetan la búsqueda visible.'
        if kind=='menus':hint+=' “Ciclo / semana” indica el período en que se sirve el menú. Retirar lo oculta de nuevas recepciones sin borrar el historial.'
        else:hint+=' Para conservar el historial, utiliza el estado retirado, inactivo, completado o anulado.'
        self.body.addWidget(label(hint,'muted'))
    def fill_table(self,*_):
        kind=self.current; self.rows=self.store.list_records(kind,self.year_id(),self.search.text()); data=reports.readable_rows(self.store,kind,self.year_id(),self.search.text()); cols=reports.COLUMNS[kind]; fields={f.key:f.label for f in MODULES[kind][1]}
        fields['edad']='Edad actual'
        if kind=='students' and hasattr(self,'level_filter'):
            level='' if self.level_filter.currentText().startswith('Todos') else self.level_filter.currentText();grade='' if self.grade_filter.currentText().startswith('Todos') else self.grade_filter.currentText();section=self.section_filter.currentData() or ''
            keep=lambda r:(not level or r['data'].get('nivel')==level) and (not grade or r['data'].get('grado')==grade) and (not section or r['data'].get('seccion')==section)
            self.rows=[r for r in self.rows if keep(r)];ids={r['id'] for r in self.rows};data=[r for r in data if r['id'] in ids]
        self.table.setColumnCount(len(cols)); self.table.setHorizontalHeaderLabels([fields[c] for c in cols]); self.table.setRowCount(len(data))
        for i,r in enumerate(data):
            for j,c in enumerate(cols):
                item=QTableWidgetItem(str(r.get(c,''))); item.setToolTip(str(r.get(c,''))); self.table.setItem(i,j,item)
        self.statusBar().showMessage(f'{len(data)} registros en el año seleccionado')
    def selected(self):
        i=self.table.currentRow()
        if i<0 or i>=len(self.rows):raise AppError('Seleccione un registro de la tabla.')
        return self.rows[i]
    def new_record(self):self.record_form()
    def edit_record(self):self.record_form(self.selected())
    def record_form(self,record=None):
        kind=self.current; self.store.require(kind,write=True); self.store._open(self.year_id())
        values=record['data'] if record else {}
        if not record:
            y=self.store.year(self.year_id()); today=date.today().isoformat(); values={'fecha':today if y['start_date']<=today<=y['end_date'] else y['start_date']}
            if kind in ('receipts','deliveries'):values['hora']=local_now().strftime('%H:%M')
            if kind=='receipts':values['rechazadas']='0'
            if kind=='deliveries':values.update(cantidad='1',unidad='unidad',estado='Recibido')
            if kind=='reminders':values.update(prioridad='Normal',estado='Pendiente')
        f=Form(self,MODULES[kind][0],MODULES[kind][1],values,self.store,self.year_id())
        while f.exec()==QDialog.Accepted:
            try:
                self.store.save_record(kind,self.year_id(),f.values(),record['id'] if record else None,record['version'] if record else None); self.render();return
            except AppError as e:error(f,e)
    def export(self,fmt):
        path,_=QFileDialog.getSaveFileName(self,'Guardar reporte',f"{self.current}-{self.store.year(self.year_id())['label']}.{fmt}",f'{fmt.upper()} (*.{fmt})')
        if path:
            if not path.lower().endswith('.'+fmt):path+='.'+fmt
            include_photos=False
            if fmt=='pdf' and self.current in ('receipts','deliveries'):
                choice=QMessageBox.question(self,'Fotografías en el informe','¿Desea incluir las fotografías adjuntas en el PDF?',QMessageBox.Yes|QMessageBox.No|QMessageBox.Cancel)
                if choice==QMessageBox.Cancel:return
                include_photos=choice==QMessageBox.Yes
            if fmt=='pdf':reports.report_pdf(self.store,self.current,self.year_id(),path,self.search.text(),include_photos)
            else:reports.report_xlsx(self.store,self.current,self.year_id(),path,self.search.text())
            self.statusBar().showMessage('Reporte guardado correctamente.')
            if QMessageBox.question(self,'Reporte guardado','El archivo se creó correctamente. ¿Desea abrirlo ahora para revisar o imprimir?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:QDesktopServices.openUrl(QUrl.fromLocalFile(path))
    def detail_pdf(self):
        r=self.selected(); path,_=QFileDialog.getSaveFileName(self,'Guardar expediente',f"expediente-{r['id']}.pdf",'PDF (*.pdf)')
        if path:
            if not path.lower().endswith('.pdf'):path+='.pdf'
            reports.record_pdf(self.store,self.current,self.year_id(),r['id'],path);self.statusBar().showMessage('Expediente PDF guardado.')
            if QMessageBox.question(self,'PDF guardado','¿Desea abrirlo para revisar o imprimir?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:QDesktopServices.openUrl(QUrl.fromLocalFile(path))
    def view_detail(self):
        r=self.selected();d=QDialog(self);d.setWindowTitle('Ficha del registro');d.resize(720,680);outer=QVBoxLayout(d);outer.addWidget(label(r['data'].get('nombre',MODULES[self.current][0]),'brand'))
        if self.current=='students':
            profile=self.store.student_profile(self.year_id(),r['data']);color='#19734A' if profile['edad_en_rango'] is True else '#A05A00' if profile['edad_en_rango'] is False else '#607482'
            age=label(f"Edad actual: {profile['edad']}  ·  Al iniciar el año: {profile['edad_inicio_año']}  ·  Rango configurado: {profile['rango_esperado']}");age.setStyleSheet(f'color:{color};font-size:15px;font-weight:700;padding:10px;background:#FFFFFF;border-radius:8px;');outer.addWidget(age)
            if profile['edad_en_rango'] is False:outer.addWidget(label('La edad está fuera del rango configurado. Es una alerta informativa: el registro no se modifica automáticamente.','muted'))
        scroll=QScrollArea();scroll.setWidgetResizable(True);content=QWidget();form=QFormLayout(content)
        for field in MODULES[self.current][1]:form.addRow(field.label,label(str(r['data'].get(field.key,'') or 'No registrado')))
        scroll.setWidget(content);outer.addWidget(scroll);close=QDialogButtonBox(QDialogButtonBox.Close);close.rejected.connect(d.reject);outer.addWidget(close);d.exec()
    def import_template(self):
        path,_=QFileDialog.getSaveFileName(self,'Guardar plantilla',f'plantilla-{self.current}.xlsx','Excel (*.xlsx)')
        if path:self.store.create_import_template(self.current,path);QMessageBox.information(self,'Plantilla creada','La plantilla está lista. Puedes completarla en Excel y luego importarla.')
    def import_excel(self):
        path,_=QFileDialog.getOpenFileName(self,'Importar datos','','Excel o CSV (*.xlsx *.csv)')
        if not path:return
        defaults={}
        if self.current=='students':
            dialog=QDialog(self);dialog.setWindowTitle('Destino de los estudiantes');layout=QVBoxLayout(dialog);layout.addWidget(label('Clasificar estudiantes importados','brand'));layout.addWidget(label('Estas opciones se aplican cuando la hoja no trae nivel, grado o sección.','muted'));form=QFormLayout()
            level=QComboBox();grade=QComboBox();section=QComboBox()
            for item in self.store.academic_levels():level.addItem(item['name'],item['id'])
            def load_grades():
                grade.clear()
                for item in self.store.grades(level.currentData()):grade.addItem(item['name'],item['id'])
                load_sections()
            def load_sections():
                section.clear()
                for item in self.store.sections(self.year_id(),grade.currentData()):section.addItem(item['name'],item['id'])
            level.currentIndexChanged.connect(load_grades);grade.currentIndexChanged.connect(load_sections);form.addRow('Nivel',level);form.addRow('Grado',grade);form.addRow('Sección',section);layout.addLayout(form);load_grades()
            buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Ok).setText('Importar');buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
            if dialog.exec()!=QDialog.Accepted:return
            defaults={'nivel':level.currentText(),'grado':grade.currentText(),'seccion':section.currentText()}
        count=self.store.import_records(self.current,self.year_id(),path,defaults);QMessageBox.information(self,'Importación completada',f'Se importaron {count} registros correctamente.');self.render()
    def letter(self):
        r=self.selected(); d=QDialog(self); d.setWindowTitle('Revisar constancia antes de imprimir'); d.resize(720,650); l=QVBoxLayout(d)
        l.addWidget(label('Revisa el texto y genera el PDF','brand')); text=QTextEdit();text.setPlainText(reports.document_text(self.store,self.current,self.year_id(),r['id']));l.addWidget(text)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);l.addWidget(buttons)
        if d.exec()==QDialog.Accepted:
            path,_=QFileDialog.getSaveFileName(self,'Guardar constancia','constancia.pdf','PDF (*.pdf)')
            if path:reports.letter_pdf(self.store,self.current,self.year_id(),r['id'],path,text.toPlainText());self.statusBar().showMessage('Constancia guardada. Abra el PDF para imprimirlo.')
    def attachments_dialog(self):
        r=self.selected(); kind=self.current; year=self.year_id(); d=QDialog(self);d.setWindowTitle('Adjuntos y evidencias');d.resize(650,400);l=QVBoxLayout(d); listing=QListWidget();l.addWidget(listing); items=[]
        def refresh():
            items[:]=self.store.attachments(kind,year,r['id']);listing.clear()
            for a in items:listing.addItem(f"{a['name']} · {a['size']//1024} KB")
        def add():
            path,_=QFileDialog.getOpenFileName(d,'Adjuntar archivo','','Archivos admitidos (*.pdf *.png *.jpg *.jpeg *.xlsx *.docx *.txt)')
            if path:self.store.attach(kind,year,r['id'],path);refresh()
        def save():
            i=listing.currentRow()
            if i<0:raise AppError('Seleccione un adjunto.')
            a=items[i];path,_=QFileDialog.getSaveFileName(d,'Guardar copia',a['name'])
            if path:atomic_write(path,self.store.attachment_bytes(kind,year,r['id'],a['id']))
        refresh();bar=QHBoxLayout();b=button('Adjuntar archivo',lambda:self.safe(add),True);b.setEnabled(self.store.year(year)['status']=='abierto' and self.store.user['role']!='consulta');bar.addWidget(b);bar.addWidget(button('Guardar copia',lambda:self.safe(save)));l.addLayout(bar);l.addWidget(label('PDF, fotos, Excel, Word o TXT. Máximo 25 MB. Se conserva una copia íntegra dentro de la aplicación.','muted'));d.exec()
    def retire_menu(self):
        record=self.selected();name=record['data'].get('nombre','este menú')
        if QMessageBox.question(self,'Retirar menú',f'¿Desea retirar “{name}”?\n\nDejará de aparecer en nuevas recepciones. Las entregas anteriores y sus evidencias no se borrarán.',QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        referenced=self.store.archive_menu(self.year_id(),record['id']);self.render()
        QMessageBox.information(self,'Menú retirado','El menú fue retirado y el historial quedó protegido.' if referenced else 'El menú fue retirado de las opciones activas.')
    def food_services_dialog(self):
        d=QDialog(self);d.setWindowTitle('Tipos de alimentación');d.resize(560,460);layout=QVBoxLayout(d)
        layout.addWidget(label('Tipos de alimentación','brand'));layout.addWidget(label('Agregue cualquier alimento o modalidad adicional. Los tipos activos aparecerán automáticamente al crear menús y recepciones.','muted'))
        listing=QListWidget();layout.addWidget(listing,1);items=[]
        def refresh():
            items[:]=[(name,True) for name in self.store.food_services(True)]+[(name,False) for name in self.store.food_services(False) if name not in self.store.food_services(True)]
            listing.clear()
            for name,active in items:listing.addItem(('Activo · ' if active else 'Retirado · ')+name)
        def add():
            name,ok=QInputDialog.getText(d,'Nuevo tipo','Nombre del alimento o servicio:')
            if ok:self.store.save_food_service(name,True);refresh()
        def change(active):
            row=listing.currentRow()
            if row<0:raise AppError('Seleccione un tipo de la lista.')
            name,current=items[row]
            if current==active:return
            self.store.save_food_service(name,active);refresh()
        bar=QHBoxLayout();bar.addWidget(button('Agregar tipo',lambda:self.safe(add),True));bar.addWidget(button('Retirar',lambda:self.safe(lambda:change(False))));bar.addWidget(button('Reactivar',lambda:self.safe(lambda:change(True))));layout.addLayout(bar)
        close=QDialogButtonBox(QDialogButtonBox.Close);close.rejected.connect(d.reject);layout.addWidget(close);refresh();d.exec();self.render()
    def show_due_reminders(self):
        if 'reminders' not in ACCESS[self.store.user['role']] or not self.year_id():return
        try:rows=self.store.due_reminders(self.year_id())
        except AppError:return
        if not rows:return
        lines=[]
        for row in rows[:6]:
            data=row['data'];when=data['fecha']+(' · '+data['hora'] if data.get('hora') else '')
            lines.append(f"• {when} — {data['titulo']} ({data['prioridad']})")
        if len(rows)>6:lines.append(f'• Y {len(rows)-6} recordatorios más')
        QMessageBox.information(self,'Agenda próxima','Estos asuntos están vencidos o suceden en los próximos 7 días:\n\n'+'\n'.join(lines))
    def assistant_page(self):
        self.body.addWidget(label('Asistente local','title'));self.body.addWidget(label('Funciona completamente en este Mac. No envía estudiantes, documentos ni instrucciones a internet. Confirma antes de crear datos.','muted'))
        chat=QTextEdit();chat.setReadOnly(True);chat.setPlainText('Asistente: ¿Qué desea hacer? Puede pedirme abrir un módulo, crear un recordatorio, explicar una función o preparar un reporte PDF/Excel.');self.body.addWidget(chat,1)
        row=QHBoxLayout();entry=QLineEdit();entry.setPlaceholderText('Ejemplo: recuérdame asamblea el 15/10/2026 a las 09:00');row.addWidget(entry,1)
        def send():
            message=entry.text().strip()
            if not message:return
            chat.append('\nUsted: '+message);entry.clear();result=interpret(message);action=result['action']
            if action=='reply':chat.append('\nAsistente: '+result['message']);return
            if action=='navigate':
                target=result['target']
                if target not in self.keys:chat.append('\nAsistente: Su cuenta no tiene permiso para abrir ese módulo.');return
                chat.append('\nAsistente: '+result.get('message','Módulo abierto.'));self.nav.setCurrentRow(self.keys.index(target));return
            if action=='create_reminder':
                summary=f"{result['title']}\nFecha: {result['date']}"+(f"\nHora: {result['time']}" if result['time'] else '')
                if QMessageBox.question(self,'Confirmar recordatorio',summary+'\n\n¿Desea guardarlo?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:
                    data={'titulo':result['title'],'fecha':result['date'],'hora':result['time'],'categoria':'Otro','prioridad':'Normal','responsable':self.store.user['name'],'detalle':'Creado desde el asistente local.','estado':'Pendiente'}
                    self.store.save_record('reminders',self.year_id(),data);chat.append('\nAsistente: Recordatorio guardado correctamente.')
                else:chat.append('\nAsistente: No realicé ningún cambio.');return
            if action=='report':
                target=result['target']
                if target not in self.keys:chat.append('\nAsistente: Su cuenta no tiene permiso para generar ese reporte.');return
                self.current=target;self.nav.blockSignals(True);self.nav.setCurrentRow(self.keys.index(target));self.nav.blockSignals(False);self.render();self.export(result['format'])
        row.addWidget(button('Enviar',lambda:self.safe(send),True));self.body.addLayout(row);entry.returnPressed.connect(lambda:self.safe(send))
        self.body.addWidget(label('Órdenes disponibles: abrir estudiantes/personal/alimentación; crear recordatorios; preparar reportes; explicar menús por ciclo, impresión y respaldos.','muted'))
    def help_page(self):
        self.body.addWidget(label('Ayuda e instructivo','title'));self.body.addWidget(label('Guía rápida para trabajar sin conocimientos técnicos.','muted'))
        scroll=QScrollArea();scroll.setWidgetResizable(True);content=QWidget();layout=QVBoxLayout(content)
        sections=[
          ('Primeros pasos','1. Seleccione el año escolar arriba. 2. Entre al módulo deseado. 3. Pulse Nuevo registro. 4. Complete los campos con asterisco y pulse Guardar. Los datos permanecen en este Mac.'),
          ('Menús por ciclo','“Ciclo / semana” es el período en que se repite o aplica un menú, por ejemplo Ciclo 1 o Semana 2. Cree primero el menú y luego registre la recepción diaria. Para quitarlo de nuevas entregas, selecciónelo y pulse Retirar menú; el historial no se borra.'),
          ('Tipos de alimentación','En Menús por ciclo pulse Tipos de alimentación. Puede agregar otros alimentos además de leche, pan y almuerzo, retirarlos o reactivarlos.'),
          ('Fotos y documentos','Seleccione un registro y pulse Adjuntos. Puede añadir varias fotos, PDF, Excel, Word o TXT. En los informes de alimentación y entregas generales puede elegir PDF con fotos o sin fotos.'),
          ('Guardar, abrir e imprimir PDF','Pulse Reporte PDF o Detalle PDF, elija Escritorio o Documentos y guarde. AulaLocal ofrecerá abrir el archivo; desde Vista Previa use Archivo → Imprimir. Si macOS bloquea una carpeta, seleccione otra.'),
          ('Entregas generales','Use Entregas y bienes recibidos para sillas, equipos, materiales, donaciones u otros artículos. Registre cantidad, condición, quién entrega, quién recibe y adjunte evidencias.'),
          ('Agenda y recordatorios','Registre asambleas, reuniones, supervisiones, fechas límite y actividades. Al abrir la aplicación se mostrarán los pendientes vencidos o de los próximos siete días.'),
          ('Acompañamiento docente','Registre docente, fecha, fortalezas, resultados, acuerdos y fecha de seguimiento. El informe queda disponible en PDF y Excel para supervisión.'),
          ('Asistente local','Puede escribir “abre estudiantes”, “reporte PDF de personal” o “recuérdame asamblea el 15/10/2026 a las 09:00”. Nunca guarda datos sin pedir confirmación.'),
          ('Copias de seguridad','Entre a Copias y restauración y cree periódicamente un archivo .aulabackup en una memoria USB. Recuerde la contraseña del respaldo.')]
        for title,text in sections:
            box=QGroupBox(title);inside=QVBoxLayout(box);inside.addWidget(label(text));layout.addWidget(box)
        layout.addStretch();scroll.setWidget(content);self.body.addWidget(scroll,1)
    def new_year(self):
        from .catalog import F
        f=Form(self,'Crear año escolar',[F('label','Año escolar',required=True),F('start','Inicio','date',True),F('end','Fin','date',True)],{'label':'2026-2027','start':'2026-08-01','end':'2027-07-31'})
        while f.exec()==QDialog.Accepted:
            try:
                d=f.values();new=self.store.create_year(d['label'],d['start'],d['end']);self.refresh_years();self.year_combo.setCurrentIndex(self.year_combo.findData(new));self.render();return
            except AppError as e:error(f,e)
    def academic_page(self):
        self.body.addWidget(label('Niveles, grados y secciones','title'));self.body.addWidget(label('Estructura académica configurable. Los rangos de edad generan alertas informativas y aparecen en la ficha del estudiante.','muted'))
        tabs=QGridLayout();levels=self.store.academic_levels(False);grades=self.store.grades(active_only=False);sections=self.store.academic_summary(self.year_id()) if self.year_id() else []
        level_box=QGroupBox('Niveles educativos');ll=QVBoxLayout(level_box);ll.addWidget(table_widget(['Nivel','Orden'],[[x['name'],x['sort_order']] for x in levels]));
        grade_box=QGroupBox('Grados y rangos de edad');gl=QVBoxLayout(grade_box);gl.addWidget(table_widget(['Nivel','Grado','Edad mínima','Edad máxima'],[[x['level'],x['name'],x['min_age'] if x['min_age'] is not None else '',x['max_age'] if x['max_age'] is not None else ''] for x in grades]));
        section_box=QGroupBox('Secciones del año seleccionado');sl=QVBoxLayout(section_box);sl.addWidget(table_widget(['Nivel','Grado','Sección','Capacidad','Estudiantes'],[[x['level'],x['grade'],x['name'],x['capacity'] or '',x['students']] for x in sections]));
        tabs.addWidget(level_box,0,0);tabs.addWidget(grade_box,0,1);tabs.addWidget(section_box,1,0,1,2);self.body.addLayout(tabs,1)
        def new_level():
            from .catalog import F
            f=Form(self,'Crear nivel educativo',[F('name','Nombre',required=True),F('order','Orden','integer',True)],{'order':'40'})
            if f.exec()==QDialog.Accepted:self.store.save_level(f.values()['name'],f.values()['order']);self.render()
        def new_grade():
            d=QDialog(self);d.setWindowTitle('Crear grado');l=QFormLayout(d);level=QComboBox()
            for x in levels:level.addItem(x['name'],x['id'])
            name=QLineEdit();minimum=QLineEdit();maximum=QLineEdit();order=QLineEdit('10');l.addRow('Nivel',level);l.addRow('Nombre',name);l.addRow('Edad mínima',minimum);l.addRow('Edad máxima',maximum);l.addRow('Orden',order);buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);l.addRow(buttons)
            if d.exec()==QDialog.Accepted:self.store.save_grade(level.currentData(),name.text(),minimum.text(),maximum.text(),order.text());self.render()
        def new_section():
            d=QDialog(self);d.setWindowTitle('Crear sección');l=QFormLayout(d);grade=QComboBox()
            for x in grades:grade.addItem(f"{x['level']} · {x['name']}",x['id'])
            name=QLineEdit();capacity=QLineEdit();l.addRow('Grado',grade);l.addRow('Sección',name);l.addRow('Capacidad (opcional)',capacity);buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);l.addRow(buttons)
            if d.exec()==QDialog.Accepted:self.store.save_section(self.year_id(),grade.currentData(),name.text(),capacity.text());self.render()
        bar=QHBoxLayout();bar.addWidget(button('Crear nivel',lambda:self.safe(new_level)));bar.addWidget(button('Crear grado',lambda:self.safe(new_grade)));bar.addWidget(button('Crear sección',lambda:self.safe(new_section),True));bar.addStretch();self.body.addLayout(bar)
    def years_page(self):
        self.body.addWidget(label('Años escolares','title'));self.body.addWidget(label('Congelar bloquea los cambios. Archivar conserva el año para consultas. La reapertura requiere tu contraseña y un motivo.','muted'))
        years=self.store.years();self.body.addWidget(table_widget(['Año','Inicio','Fin','Estado'],[[y['label'],y['start_date'],y['end_date'],y['status']] for y in years]),1)
        self.body.addWidget(label('Las acciones siguientes se aplican al año seleccionado arriba.','muted'))
        bar=QHBoxLayout();bar.addWidget(button('Crear año',lambda:self.safe(self.new_year),True))
        for text,state in [('Congelar','congelado'),('Reabrir','abierto'),('Archivar','archivado')]:bar.addWidget(button(text,lambda checked=False,s=state:self.safe(lambda:self.change_year_state(s))))
        self.body.addLayout(bar);self.body.addWidget(button('Copiar matrículas o personal al año seleccionado',lambda:self.safe(self.copy_people)));self.body.addWidget(button('Exportar archivo histórico del año',lambda:self.safe(self.archive)))
    def change_year_state(self,state):
        y=self.store.year(self.year_id());reason,ok=QInputDialog.getMultiLineText(self,'Motivo de la acción',f"{y['label']}: {y['status']} → {state}\nExplique el motivo:")
        if not ok:return
        pw=ask_password(self,'Confirme su contraseña de administrador:')
        if pw is None:return
        self.store.transition(y['id'],state,reason,pw);self.refresh_years();self.render()
    def copy_people(self):
        target=self.store.year(self.year_id());sources=[y for y in self.store.years() if y['label']<target['label']]
        if not sources:raise AppError('Primero cree un año posterior y selecciónelo como destino.')
        source,ok=QInputDialog.getItem(self,'Copiar desde otro año','Año de origen:',[y['label'] for y in sources],0,False)
        if not ok:return
        kind,ok=QInputDialog.getItem(self,'Registros a copiar','Tipo:',['Estudiantes','Personal'],0,False)
        if not ok:return
        if QMessageBox.question(self,'Confirmar copia',f"Se copiarán los registros activos de {source} a {target['label']}. Los códigos existentes se omiten. Revise grado y sección después: no se promueven automáticamente.")!=QMessageBox.Yes:return
        count=self.store.copy_people(next(y['id'] for y in sources if y['label']==source),target['id'],'students' if kind=='Estudiantes' else 'staff');QMessageBox.information(self,'Copia completa',f'{count} registros copiados.');self.render()
    def archive(self):
        y=self.store.year(self.year_id());path,_=QFileDialog.getSaveFileName(self,'Guardar archivo histórico',f"archivo-{y['label']}.zip",'ZIP (*.zip)')
        if path:reports.export_year(self.store,y['id'],path);QMessageBox.information(self,'Archivo exportado','Se guardaron los registros, hojas Excel, auditoría y adjuntos de este año. Este ZIP no está cifrado; guárdelo en un lugar protegido.')
    def settings_page(self):
        self.body.addWidget(label('Mi centro','title'));self.body.addWidget(label('Identidad institucional utilizada en informes, certificaciones y archivos históricos.','muted'));s=self.store.settings();inputs={}
        scroll=QScrollArea();scroll.setWidgetResizable(True);content=QWidget();layout=QVBoxLayout(content);layout.setSpacing(18)
        summary=QFrame();summary.setObjectName('card');sl=QVBoxLayout(summary);school_name=label(s.get('centro','Centro educativo'),'title');school_name.setStyleSheet('font-size:26px;font-weight:750;color:#102F3E;');sl.addWidget(school_name);sl.addWidget(label(f"Código: {s.get('codigo') or 'No registrado'}  ·  Dirección: {s.get('director') or 'No registrada'}",'muted'));layout.addWidget(summary)
        identity_box=QGroupBox('Datos del centro educativo');form=QFormLayout(identity_box);form.setVerticalSpacing(14)
        for key,title in [('centro','Nombre completo del centro'),('codigo','Código del centro'),('director','Director/a'),('direccion','Dirección física'),('telefono','Teléfono')]:
            w=QLineEdit(s.get(key,''));w.setMinimumHeight(42);w.setStyleSheet('font-size:15px;');inputs[key]=w;form.addRow(title,w)
        layout.addWidget(identity_box)
        def save():
            self.store.save_settings({k:w.text() for k,w in inputs.items()});updated=self.store.settings();self.school.setText(updated['centro']);school_name.setText(updated['centro']);self.statusBar().showMessage('Datos del centro guardados correctamente.');QMessageBox.information(self,'Mi centro','Los datos institucionales fueron guardados.')
        layout.addWidget(button('Guardar datos del centro',lambda:self.safe(save),True))
        system_box=QGroupBox('Fecha, hora y sesión');system_layout=QVBoxLayout(system_box);system_layout.addWidget(label(f'Reloj actual del Mac: {local_now().strftime("%d/%m/%Y %I:%M:%S %p")} · {timezone_label()}','clock'));system_layout.addWidget(label('AulaLocal consulta el reloj y la zona horaria del sistema. macOS conserva la fecha aunque el equipo permanezca apagado. La sesión seguirá activa hasta que pulse Cerrar sesión.','muted'));layout.addWidget(system_box)
        templates=QGroupBox('Plantillas de documentos');tl=QVBoxLayout(templates);tl.addWidget(label('Personalice cartas y certificaciones sin modificar la programación.','muted'))
        for kind,title in [('staff','Carta de trabajo'),('students','Certificación de matrícula')]:tl.addWidget(button('Editar plantilla: '+title,lambda checked=False,k=kind:self.safe(lambda:self.edit_template(k))))
        layout.addWidget(templates);layout.addStretch();scroll.setWidget(content);self.body.addWidget(scroll,1)
    def edit_template(self,kind):
        s=self.store.settings();d=QDialog(self);d.setWindowTitle('Plantilla');d.resize(720,560);l=QVBoxLayout(d);l.addWidget(label('Conserva los nombres entre llaves para completar los datos automáticamente.','muted'));text=QTextEdit();text.setPlainText(s.get('template_'+kind,reports.DEFAULT_TEMPLATES[kind]));l.addWidget(text)
        l.addWidget(button('Restablecer texto original',lambda:text.setPlainText(reports.DEFAULT_TEMPLATES[kind])))
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);l.addWidget(buttons)
        if d.exec()==QDialog.Accepted:
            from string import Formatter
            valid={'centro','director','direccion','telefono','año','codigo_estudiante','fecha_emision'}|{f.key for f in MODULES[kind][1]}
            try:
                for _,field,spec,conv in Formatter().parse(text.toPlainText()):
                    if field is not None and (field not in valid or spec or conv):raise ValueError()
            except ValueError:raise AppError('La plantilla contiene un campo no permitido.')
            self.store.save_settings({**s,'template_'+kind:text.toPlainText()})
    def users_page(self):
        self.body.addWidget(label('Usuarios y permisos','title'));users=self.store.users();t=table_widget(['Usuario','Nombre','Rol','Estado'],[[u['username'],u['name'],ROLES[u['role']],'Activo' if u['active'] else 'Inactivo'] for u in users]);self.body.addWidget(t,1)
        def edit(existing=False):
            from .catalog import F
            u=None
            if existing:
                if t.currentRow()<0:raise AppError('Seleccione una cuenta.')
                u=users[t.currentRow()]
            values={} if not u else {**u,'role':ROLES[u['role']],'active':'Activo' if u['active'] else 'Inactivo'}
            f=Form(self,'Cuenta de usuario',[F('username','Usuario',required=True),F('name','Nombre',required=True),F('role','Rol','choice',True,tuple(ROLES.values())),F('password','Nueva contraseña (vacío = conservar)','password'),F('active','Estado','choice',True,('Activo','Inactivo'))],values)
            while f.exec()==QDialog.Accepted:
                try:
                    d=f.values();role=next(k for k,v in ROLES.items() if v==d['role']);self.store.save_user(d['username'],d['name'],role,d['password'],d['active']=='Activo',u['id'] if u else None);self.render();return
                except AppError as e:error(f,e)
        def reset_password():
            if t.currentRow()<0:raise AppError('Seleccione una cuenta.')
            u=users[t.currentRow()];pw=ask_password(self,f"Nueva contraseña para {u['username']}:")
            if pw:self.store.reset_user_password(u['id'],pw);QMessageBox.information(self,'Contraseña actualizada','La cuenta deberá entrar con la contraseña nueva.')
        def recovery_key():
            pw=ask_password(self,'Confirma tu contraseña actual:')
            if pw:
                code=self.store.create_recovery_key(pw);QMessageBox.information(self,'Nuevo código de recuperación',f'Guárdalo fuera del Mac. El código anterior deja de funcionar.\n\n{code}')
        bar=QHBoxLayout();bar.addWidget(button('Nueva cuenta',lambda:self.safe(lambda:edit(False)),True));bar.addWidget(button('Editar cuenta',lambda:self.safe(lambda:edit(True))));bar.addWidget(button('Restablecer contraseña',lambda:self.safe(reset_password)));bar.addWidget(button('Generar código de recuperación',lambda:self.safe(recovery_key)));self.body.addLayout(bar)
        self.body.addWidget(label('Consulta general puede leer todos los módulos, incluidos expedientes y gastos. Asigna ese rol solo a personas autorizadas. Secretaría, Alimentación y Contabilidad tienen acceso limitado a sus módulos.','muted'))
    def audit_page(self):
        self.body.addWidget(label('Auditoría del año','title'));rows=self.store.audit(self.year_id());self.body.addWidget(table_widget(['Fecha local','Usuario','Acción','Detalle'],[[r['at_local'],r['usuario'],r['action'],r['detail']] for r in rows]),1)
        self.body.addWidget(label('Los cambios de datos conservan los valores anteriores y nuevos. Los eventos generales de acceso se incluyen al consultar toda la auditoría.','muted'))
        def all_audit():
            d=QDialog(self);d.setWindowTitle('Auditoría completa');d.resize(1000,600);l=QVBoxLayout(d);l.addWidget(table_widget(['Fecha local','Usuario','Acción','Año','Detalle'],[[r['at_local'],r['usuario'],r['action'],r['year_id'],r['detail']] for r in self.store.audit()]));d.exec()
        self.body.addWidget(button('Ver todos los eventos',lambda:self.safe(all_audit)))
    def backup_page(self):
        self.body.addWidget(label('Copias de seguridad','title'));self.body.addWidget(label('Guarda una copia cifrada en un archivo local o en un disco externo. Incluye todos los años, usuarios, configuraciones y adjuntos.','muted'))
        self.body.addWidget(button('Crear copia cifrada',lambda:self.safe(self.backup),True));self.body.addWidget(button('Restaurar desde archivo',lambda:self.safe(self.restore)))
        self.body.addWidget(label('La contraseña de la copia puede ser diferente a la de acceso. Sin ella no se puede recuperar el archivo. Antes de restaurar se conserva una copia del estado actual con esa misma contraseña.','muted'));self.body.addStretch()
        self.body.addWidget(label('Ubicación de datos: '+str(self.store.root),'muted'));self.body.addWidget(label('Los datos de trabajo no están cifrados por la aplicación. Protege el Mac con FileVault y una cuenta individual. Las copias .aulabackup sí están cifradas.','muted'))
    def backup(self):
        path,_=QFileDialog.getSaveFileName(self,'Guardar copia cifrada',f"AulaLocal-{date.today()}.aulabackup",'Respaldo AulaLocal (*.aulabackup)')
        if not path:return
        pw=ask_password(self,'Contraseña para proteger esta copia (mínimo 12 caracteres):')
        if pw is None:return
        again=ask_password(self,'Repita la contraseña de la copia:')
        if again is None:return
        if pw!=again:raise AppError('Las contraseñas no coinciden.')
        create_backup(self.store,path,pw);QMessageBox.information(self,'Respaldo completo','Copia cifrada guardada correctamente.')
    def restore(self):
        path,_=QFileDialog.getOpenFileName(self,'Abrir respaldo','','Respaldo AulaLocal (*.aulabackup)')
        if not path:return
        if QMessageBox.question(self,'Restaurar datos','Se sustituirán TODOS los años y cuentas por los del respaldo. Se conservará una copia previa. ¿Desea continuar?')!=QMessageBox.Yes:return
        current=ask_password(self,'Contraseña actual de administrador:')
        if current is None:return
        pw=ask_password(self,'Contraseña del archivo de respaldo:')
        if pw is None:return
        recovery=restore_backup(self.store,path,pw,current);QMessageBox.information(self,'Restauración completa',f'Inicie sesión con una cuenta del respaldo.\nCopia previa: {recovery.name}');self.lock()

def run(data_dir=None):
    app=QApplication(sys.argv);app.setApplicationName('AulaLocal');app.setOrganizationName('AulaLocal');app.setStyle('Fusion');app.setStyleSheet(STYLE);app.setFont(QFont('Arial',13));app.setQuitOnLastWindowClosed(False)
    root=Path(data_dir or app_directory());root.mkdir(parents=True,exist_ok=True)
    lock=QLockFile(str(root/'application.lock'));lock.setStaleLockTime(0)
    if not lock.tryLock(100):QMessageBox.information(None,'AulaLocal','La aplicación ya está abierta con estos datos.');return 1
    try:
        store=Store(root)
        if not store.user:
            login=Login(store)
            if login.exec()!=QDialog.Accepted:store.close();return 0
        window=MainWindow(store);app.main_window=window;window.show();app.setQuitOnLastWindowClosed(True)
        result=app.exec();store.close();return result
    except Exception as e:QMessageBox.critical(None,'AulaLocal','No se pudo abrir la aplicación: '+str(e));return 1
    finally:lock.unlock()
