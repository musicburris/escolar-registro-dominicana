"""Asistente local determinista: interpreta órdenes frecuentes sin enviar datos fuera del Mac."""
import re, unicodedata
from datetime import date

def normalize(text):
    return unicodedata.normalize('NFKD',text).encode('ascii','ignore').decode().casefold().strip()

NAVIGATION={
    'estudiante':'students','matricula':'students','personal':'staff','asistencia':'attendance',
    'menu':'menus','alimentacion':'receipts','comida':'receipts','gasto':'expenses','factura':'expenses',
    'planta':'facilities','visita':'visits','entrega':'deliveries','bien recibido':'deliveries',
    'recordatorio':'reminders','agenda':'reminders','acompanamiento':'coaching','docente':'coaching',
    'centro':'settings','respaldo':'backup','copia de seguridad':'backup','ayuda':'help'
}

HELP=(
    'Puedo abrir módulos, explicar funciones, preparar reportes y crear recordatorios. '
    'Ejemplos: “abre estudiantes”, “reporte PDF de personal”, '
    '“recuérdame asamblea el 15/10/2026 a las 09:00” o “cómo retiro un menú”.'
)

def interpret(message):
    original=' '.join(str(message).split());text=normalize(original)
    if not text:return {'action':'reply','message':'Escriba una instrucción. '+HELP}
    if any(x in text for x in ('que puedes hacer','como funcionas','ayuda','instructivo')):
        return {'action':'reply','message':HELP}
    if 'menu' in text and ('ciclo' in text or any(x in text for x in ('retir','borr','elimin'))):
        return {'action':'reply','message':'Un ciclo identifica la semana o período al que pertenece el menú. Para retirarlo, abra Menús por ciclo, selecciónelo y pulse Retirar menú. Las recepciones antiguas se conservan.'}
    reminder=any(x in text for x in ('recuerdame','recordatorio','agendar','agenda'))
    if reminder:
        match=re.search(r'(\d{4}-\d{2}-\d{2}|\d{1,2}/\d{1,2}/\d{4})',original)
        if match:
            raw=match.group(1)
            if '/' in raw:
                d,m,y=raw.split('/');when=f'{int(y):04d}-{int(m):02d}-{int(d):02d}'
            else:when=raw
            try:date.fromisoformat(when)
            except ValueError:return {'action':'reply','message':'La fecha no es válida. Use día/mes/año, por ejemplo 15/10/2026.'}
            tm=re.search(r'(?:a las|hora)?\s*(\d{1,2}):(\d{2})',text)
            hour=f'{int(tm.group(1)):02d}:{tm.group(2)}' if tm and int(tm.group(1))<24 and int(tm.group(2))<60 else ''
            title=original[:match.start()].strip(' ,.-')
            title=re.sub(r'(?i)^(recu[eé]rdame|crear recordatorio|agendar|agenda)\s+(que\s+)?','',title).strip()
            title=re.sub(r'(?i)\s+el$','',title).strip() or 'Recordatorio'
            return {'action':'create_reminder','title':title[:120],'date':when,'time':hour}
        return {'action':'navigate','target':'reminders','message':'Abrí Agenda y recordatorios. Pulse Nuevo registro para indicar fecha, hora y detalles.'}
    report=any(x in text for x in ('reporte','informe','pdf','excel'))
    target=next((module for word,module in NAVIGATION.items() if word in text),None)
    if report and target in ('students','staff','attendance','menus','receipts','expenses','facilities','visits','deliveries','reminders','coaching'):
        return {'action':'report','target':target,'format':'xlsx' if 'excel' in text else 'pdf'}
    if target:return {'action':'navigate','target':target,'message':'Módulo abierto. Puede crear, buscar, editar y generar informes desde sus botones.'}
    if any(x in text for x in ('guardar','imprimir','error','no funciona')):
        return {'action':'reply','message':'Para imprimir, genere el PDF, guárdelo en Escritorio o Documentos y elija Abrir PDF. Si macOS niega permiso, seleccione otra carpeta. Los errores quedan registrados localmente en errores.log.'}
    return {'action':'reply','message':'No reconocí esa instrucción todavía. '+HELP}
