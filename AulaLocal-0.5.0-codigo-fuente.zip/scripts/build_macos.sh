#!/bin/bash
set -euo pipefail
cd "$(dirname "$0")/.."
if [ "$(uname -s)" != Darwin ] || [ "$(uname -m)" != arm64 ]; then
  echo 'Esta compilación requiere un Mac Apple Silicon ejecutándose sin Rosetta.' >&2
  exit 1
fi
BUILD_PYTHON="${AULALOCAL_BUILD_PYTHON:-python3}"
"$BUILD_PYTHON" -c 'import platform,sys; assert platform.machine()=="arm64", "Python debe ser ARM64"; assert (3,11)<=sys.version_info<(3,14), "Se requiere Python 3.11, 3.12 o 3.13"'
"$BUILD_PYTHON" -m venv .venv-build
.venv-build/bin/python -m pip install --disable-pip-version-check -r requirements-build.txt
.venv-build/bin/python -m pip install --no-deps -e .
mkdir -p docs/evidencias build-assets
.venv-build/bin/python scripts/make_icon.py build-assets/AulaLocal.png
QT_QPA_PLATFORM=offscreen .venv-build/bin/python -m pytest -q --junitxml=docs/evidencias/tests-macos.xml
export MACOSX_DEPLOYMENT_TARGET=12.0
build_app() {
  .venv-build/bin/python -m PyInstaller --noconfirm --clean --windowed --onedir \
    --name AulaLocal --target-architecture arm64 --icon build-assets/AulaLocal.png \
    --osx-bundle-identifier com.aulalocal.desktop \
    --add-data 'aulalocal/schema.sql:aulalocal' \
    --collect-data reportlab --collect-data openpyxl \
    --exclude-module PySide6.QtWebEngineCore --exclude-module PySide6.QtWebEngineWidgets \
    "$@" launcher.py
}
if [ -n "${AULALOCAL_SIGN_IDENTITY:-}" ]; then
  build_app --codesign-identity "$AULALOCAL_SIGN_IDENTITY" --osx-entitlements-file scripts/entitlements.plist
else
  build_app
fi
/usr/libexec/PlistBuddy -c 'Set :LSMinimumSystemVersion 12.0' dist/AulaLocal.app/Contents/Info.plist 2>/dev/null || \
  /usr/libexec/PlistBuddy -c 'Add :LSMinimumSystemVersion string 12.0' dist/AulaLocal.app/Contents/Info.plist
# El cambio del plist requiere volver a sellar el bundle; PyInstaller firma los binarios internos.
if [ -n "${AULALOCAL_SIGN_IDENTITY:-}" ]; then
  codesign --force --options runtime --entitlements scripts/entitlements.plist --sign "$AULALOCAL_SIGN_IDENTITY" dist/AulaLocal.app
else
  codesign --force --sign - dist/AulaLocal.app
fi
codesign --verify --deep --strict dist/AulaLocal.app
lipo dist/AulaLocal.app/Contents/MacOS/AulaLocal -verify_arch arm64
QT_QPA_PLATFORM=offscreen dist/AulaLocal.app/Contents/MacOS/AulaLocal --self-test | tee docs/evidencias/validacion-m1.json
python3 - <<'PY'
import json
data=json.load(open('docs/evidencias/validacion-m1.json'))
assert data['status']=='ok' and data['arquitectura']=='arm64'
assert all(data[k] for k in ('persistencia','pdf','excel','respaldo','sin_red','estructura_academica','importacion_excel','sesion_persistente','recuperacion_local','planta_y_visitas','agenda','entregas_generales','acompanamiento_docente','asistente_local','alimentacion_configurable'))
PY
if [ -n "${AULALOCAL_NOTARY_PROFILE:-}" ]; then
  ditto -c -k --keepParent dist/AulaLocal.app dist/AulaLocal-notarizar.zip
  xcrun notarytool submit dist/AulaLocal-notarizar.zip --keychain-profile "$AULALOCAL_NOTARY_PROFILE" --wait
  xcrun stapler staple dist/AulaLocal.app
fi
STAGING_DIR="$(mktemp -d "${TMPDIR:-/tmp}/aulalocal-dmg.XXXXXX")"
trap 'rm -rf "$STAGING_DIR"' EXIT
cp -R dist/AulaLocal.app "$STAGING_DIR/"
ln -s /Applications "$STAGING_DIR/Applications"
cp docs/INSTALACION.md "$STAGING_DIR/LEEME.md"
hdiutil create -volname AulaLocal -srcfolder "$STAGING_DIR" -ov -format UDZO dist/AulaLocal-0.5.0-arm64.dmg
if [ -n "${AULALOCAL_INSTALLER_IDENTITY:-}" ]; then
  productbuild --component dist/AulaLocal.app /Applications --sign "$AULALOCAL_INSTALLER_IDENTITY" dist/AulaLocal-0.5.0-arm64.pkg
else
  productbuild --component dist/AulaLocal.app /Applications dist/AulaLocal-0.5.0-arm64.pkg
fi
shasum -a 256 dist/*.dmg dist/*.pkg > dist/SHA256SUMS.txt
echo 'Paquetes creados en dist. La prueba manual de aceptación en Mac sigue siendo obligatoria.'
if [ -z "${AULALOCAL_NOTARY_PROFILE:-}" ]; then
  echo 'Compilación local sin notarización Apple. No está lista para distribución comercial.'
fi
