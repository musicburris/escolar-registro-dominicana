from PySide6.QtWidgets import QApplication,QDialog,QPushButton,QCheckBox
from aulalocal.ui import MainWindow,Form
from aulalocal.catalog import MODULES
from conftest import student,staff,menu,receipt,expense

def test_manual_lock_and_login_reopens_window(store,monkeypatch):
    from aulalocal.ui import Login
    from conftest import PASSWORD
    app=QApplication.instance() or QApplication([])
    window=MainWindow(store);window.show()
    def sign_in(login):
        login.store.login('director',PASSWORD);return QDialog.Accepted
    monkeypatch.setattr(Login,'exec',sign_in)
    window.lock()
    assert app.main_window.isVisible() and store.user['username']=='director'
    app.main_window.timer.stop();app.main_window.close();app.setQuitOnLastWindowClosed(False)

def test_all_pages_and_forms_render(store,tmp_path):
    app=QApplication.instance() or QApplication([])
    store.save_record('students',1,student());pid=store.save_record('staff',1,staff());mid=store.save_record('menus',1,menu());store.save_record('receipts',1,receipt(mid));store.save_record('expenses',1,expense())
    store.save_record('attendance',1,{'personal':pid,'fecha':'2026-09-01','estado':'Presente'})
    window=MainWindow(store);window.show();app.processEvents()
    for key in window.keys:
        window.current=key;window._render();app.processEvents()
        assert window.body.count()>0
    for kind in MODULES:
        form=Form(window,MODULES[kind][0],MODULES[kind][1],store=store,year=1)
        form.show();app.processEvents();assert set(form.values())=={f.key for f in MODULES[kind][1]};form.close()
    window.timer.stop();window.close();app.processEvents()

def test_navigation_hides_previous_page(store):
    app=QApplication.instance() or QApplication([])
    window=MainWindow(store);window.show();app.processEvents()
    old_title=window.body.itemAt(0).widget()
    window.nav.setCurrentRow(window.keys.index('students'));app.processEvents()
    assert not old_title.isVisible()
    assert window.current=='students'
    window.timer.stop();window.close()

def test_menu_page_has_visible_delete_and_survives_repeated_navigation(store):
    app=QApplication.instance() or QApplication([])
    window=MainWindow(store);window.show();app.processEvents()
    menu_index=window.keys.index('menus')
    for _ in range(5):
        window.nav.setCurrentRow(menu_index);app.processEvents()
        assert any(button.text()=='Eliminar' and button.isVisible() for button in window.findChildren(QPushButton))
        window.nav.setCurrentRow(0);app.processEvents()
    window.timer.stop();window.close();app.processEvents()

def test_attendance_page_has_punch_clock_import_and_period_filters(store):
    app=QApplication.instance() or QApplication([])
    window=MainWindow(store);window.show();window.nav.setCurrentRow(window.keys.index('attendance'));app.processEvents()
    assert any(button.text()=='Importar ponchador' and button.isVisible() for button in window.findChildren(QPushButton))
    assert window.attendance_from.date().toString('yyyy-MM-dd')=='2026-08-01'
    assert window.attendance_to.date().toString('yyyy-MM-dd')=='2027-07-31'
    window.timer.stop();window.close();app.processEvents()

def test_every_module_has_safe_delete_restore_and_weekly_menu_action(store):
    app=QApplication.instance() or QApplication([]);window=MainWindow(store);window.show()
    for key in MODULES:
        window.nav.setCurrentRow(window.keys.index(key));app.processEvents()
        visible={b.text() for b in window.findChildren(QPushButton) if b.isVisible()}
        assert {'Eliminar','Restaurar'}<=visible
        assert any(box.text()=='Mostrar eliminados' and box.isVisible() for box in window.findChildren(QCheckBox))
    window.nav.setCurrentRow(window.keys.index('menus'));app.processEvents()
    assert any(b.text()=='Planificar semana' and b.isVisible() for b in window.findChildren(QPushButton))
    window.timer.stop();window.close();app.processEvents()
