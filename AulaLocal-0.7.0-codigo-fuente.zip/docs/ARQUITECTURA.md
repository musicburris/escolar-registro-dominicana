# Arquitectura y seguridad

AulaLocal 0.7.0 es una aplicación de escritorio Qt/PySide6 empaquetada como aplicación macOS ARM64. No contiene servidor web, telemetría, API externa, sincronización ni dependencia de servicios en línea. La aplicación empaquetada incluye su intérprete y bibliotecas.

## Componentes

- `ui.py`: interfaz, formularios, navegación y diálogos nativos de archivos.
- `catalog.py`: campos, módulos y permisos.
- `core.py`: reglas, autenticación, años, estructura académica, importación y auditoría.
- `attendance_import.py`: reconocimiento local de formatos de ponchador, relación segura con el personal y consolidación diaria.
- `schema.sql`: esquema SQLite versión 2, índices, restricciones y bloqueos históricos.
- `backup.py`: respaldo cifrado, validación y restauración atómica.
- `reports.py`: PDF, Excel, constancias y archivo histórico.

## Datos y migración

SQLite es apropiado para una aplicación local de un centro: ofrece transacciones ACID, claves foráneas, WAL, `synchronous=FULL` y respaldo consistente sin administrar un servidor. Cada registro operativo lleva `year_id`; las consultas, secciones, adjuntos y reportes verifican el año para evitar mezcla entre ciclos.

La versión 2 agrega tablas normalizadas para niveles, grados, rangos de edad, secciones, sesiones y recuperación. Los expedientes operativos continúan como JSON validado para mantener formularios extensibles. La importación del ponchador acepta XLSX, XLS y CSV; consolida por persona y fecha antes de una escritura atómica y no guarda coincidencias ambiguas. Al abrir una base versión 1, una migración transaccional conserva registros y adjuntos, elimina la antigua limitación de tipos y normaliza los grados reconocibles. Las versiones futuras desconocidas se rechazan en vez de abrirse de forma insegura.

Los adjuntos se guardan dentro de SQLite con SHA-256, hasta 25 MB por archivo. Esto facilita copias completas, aunque no sustituye un gestor documental para archivos multimedia masivos. La base activa no debe colocarse en iCloud, Dropbox, red o volumen compartido.

Las edades no se almacenan como un número que pueda quedar obsoleto: se calculan desde la fecha de nacimiento y la fecha local del Mac cada vez que se presentan o exportan. La eliminación operativa es lógica y recuperable. Los registros se ocultan con metadatos de usuario, fecha y motivo; las relaciones, los adjuntos y la auditoría permanecen intactos. La exportación histórica incluye también esos registros.

La planificación semanal INABIE reutiliza el motor de menús versionados. Cada día puede llevar fecha de semana, descripción, raciones previstas y observaciones. La recepción conserva la corroboración manual y las diferencias, mientras los informes resuelven el menú planificado aun si después se retira de la lista activa.

## Acceso y recuperación

Las contraseñas usan PBKDF2-HMAC-SHA256, sal aleatoria y 600 000 iteraciones. Una sesión persistente usa un token aleatorio: solo su hash queda en SQLite y el token se guarda con permisos privados en la carpeta del usuario. Cerrar sesión revoca y elimina ambos. Desactivar una cuenta invalida el acceso al comprobar cada operación.

La recuperación sin nube usa un código aleatorio de alta entropía mostrado al administrador. La base conserva únicamente su hash. Al usarlo se cambia usuario/contraseña, se revocan sesiones y se rota el código. No se implementa correo porque eso rompería el funcionamiento completamente offline y exigiría un servicio externo. Otra cuenta administradora puede restablecer la contraseña de un usuario.

Roles: Administración, Dirección, Secretaría, Alimentación, Contabilidad y Consulta. Las transiciones de año requieren reautenticación y motivo. La auditoría registra accesos, cambios, adjuntos, importaciones y exportaciones en UTC; la interfaz muestra la hora local del Mac.

## Respaldo y cifrado

Los `.aulabackup` usan AES-256-GCM y scrypt con sal y nonce aleatorios. La restauración valida estructura, integridad SQLite, relaciones y hashes antes de reemplazar la base, y conserva una copia previa. El formato completo admite hasta 512 MB.

La base activa no usa SQLCipher. Su confidencialidad en reposo depende de los permisos de macOS y FileVault. Esto evita distribuir una extensión criptográfica adicional, pero debe comunicarse claramente: un administrador del Mac conserva acceso físico a los datos.

## Empaquetado macOS

El build oficial tiene arquitectura ARM64 y objetivo mínimo macOS 12. PyInstaller crea el bundle; `lipo` verifica ARM64; `codesign` comprueba el sellado; el ejecutable realiza una prueba offline dentro del bundle. Sin credenciales privadas de Apple se usa firma local ad hoc y Gatekeeper puede pedir **Abrir** en el primer inicio. Con certificados del propietario, el mismo script admite Developer ID, hardened runtime, notarización y stapling.

## Límites conocidos

Las tablas se cargan por año y los respaldos/exportaciones grandes se ejecutan en el hilo de interfaz. Para cientos de miles de filas se necesitarían paginación y tareas en segundo plano. No hay colaboración simultánea entre varios equipos, contabilidad fiscal de doble partida, nómina ni envío de correo. Estas exclusiones evitan prometer funciones que esta entrega no implementa.
