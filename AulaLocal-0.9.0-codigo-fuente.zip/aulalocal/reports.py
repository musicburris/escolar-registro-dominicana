"""Documentos y exportaciones generados localmente, sin plantillas remotas."""
import io, json, zipfile
from datetime import date, datetime
from decimal import Decimal
from pathlib import Path
from xml.sax.saxutils import escape
import reportlab
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.enums import TA_CENTER
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, Image as PDFImage
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from .catalog import MODULES
from .core import AppError,age_text
from .backup import atomic_write

FONT_DIR=Path(reportlab.__file__).parent/'fonts'
pdfmetrics.registerFont(TTFont('AulaSans',str(FONT_DIR/'Vera.ttf')))
pdfmetrics.registerFont(TTFont('AulaSans-Bold',str(FONT_DIR/'VeraBd.ttf')))
pdfmetrics.registerFontFamily('AulaSans',normal='AulaSans',bold='AulaSans-Bold',italic='AulaSans',boldItalic='AulaSans-Bold')
BLUE=colors.HexColor('#183849')
STYLES=getSampleStyleSheet()
for name in STYLES.byName:
    STYLES[name].fontName='AulaSans-Bold' if name.startswith('Heading') or name=='Title' else 'AulaSans'
STYLES.add(ParagraphStyle(name='CellAula',fontName='AulaSans',fontSize=8,leading=11,spaceAfter=0,wordWrap='CJK'))
STYLES.add(ParagraphStyle(name='LetterAula',fontName='AulaSans',fontSize=11,leading=18,spaceAfter=14))

def p(text,style='BodyText'): return Paragraph(escape(str(text)).replace('\n','<br/>'),STYLES[style])
def institution(store,year):
    y=store.year(year)
    frozen=json.loads(y.get('institution','{}'))
    return frozen or store.settings()

def title_block(store,year,title):
    s=institution(store,year); y=store.year(year)
    return [p(s.get('centro',''),'Title'),p(f"Código: {s.get('codigo','')} · Año escolar {y['label']} · {y['status']}",'Normal'),Spacer(1,16),p(title,'Heading1'),p(f'Fecha de emisión: {date.today().strftime("%d/%m/%Y")}','Normal'),Spacer(1,18)]
def footer(canvas,doc):
    canvas.saveState(); canvas.setStrokeColor(colors.HexColor('#d9e2e8')); canvas.line(36,34,doc.pagesize[0]-36,34)
    canvas.setFont('AulaSans',8); canvas.setFillColor(BLUE)
    canvas.drawString(36,22,'AulaLocal · Registro institucional'); canvas.drawRightString(doc.pagesize[0]-36,22,f'Página {doc.page}'); canvas.restoreState()
def pdf_bytes(story,wide=False):
    out=io.BytesIO(); doc=SimpleDocTemplate(out,pagesize=landscape(A4) if wide else A4,rightMargin=36,leftMargin=36,topMargin=36,bottomMargin=48,title='AulaLocal - documento institucional')
    doc.build(story,onFirstPage=footer,onLaterPages=footer); return out.getvalue()
def table(headers,rows,width):
    values=[[p(h,'CellAula') for h in headers]]+[[p(v,'CellAula') for v in row] for row in rows]
    if not rows: values.append([p('Sin registros','CellAula')]+['']*(len(headers)-1))
    t=Table(values,colWidths=[width/len(headers)]*len(headers),repeatRows=1,hAlign='LEFT',splitInRow=1)
    t.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#dcebf0')),('ROWBACKGROUNDS',(0,1),(-1,-1),[colors.white,colors.HexColor('#f3f6f8')]),('VALIGN',(0,0),(-1,-1),'TOP'),('BOTTOMPADDING',(0,0),(-1,-1),8),('TOPPADDING',(0,0),(-1,-1),8),('LINEBELOW',(0,0),(-1,0),1,BLUE)]))
    return t

def _worked_hours(entry,exit_time):
    if not entry or not exit_time:return ''
    try:
        start=datetime.strptime(entry,'%H:%M');end=datetime.strptime(exit_time,'%H:%M')
    except ValueError:return ''
    minutes=int((end-start).total_seconds()//60)
    if minutes<0:return ''
    return f'{minutes//60:02d}:{minutes%60:02d}'

def readable_rows(store,kind,year,search='',start_date='',end_date='',include_deleted=False):
    records=store.list_records(kind,year,search,include_deleted=include_deleted); result=[]
    # Se consulta el mismo año; no resolver IDs en otros ciclos.
    refs={}
    if kind in ('attendance','coaching'): refs={r['id']:r['data']['nombre'] for r in store.list_records('staff',year,include_deleted=True)}
    if kind=='receipts': refs={r['id']:r['data']['nombre'] for r in store.list_records('menus',year,include_deleted=True)}
    for row in records:
        data=dict(row['data']); data['id']=row['id']
        for f in MODULES[kind][1]:
            if f.type in ('staff_ref','menu_ref'): data[f.key]=refs.get(data[f.key],str(data[f.key]))
        if kind=='students':data['edad']=age_text(data['nacimiento'])
        if kind=='menus' and not data.get('fecha_planificada') and data.get('semana_inicio') and data.get('dia'):
            index=('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo').index(data['dia'])
            data['fecha_planificada']=date.fromordinal(date.fromisoformat(data['semana_inicio']).toordinal()+index).isoformat()
        if kind=='receipts':
            comparison=store.receipt_comparison(year,row['data'])
            data['menu_previsto']=comparison['menu_planificado'];data['fecha_planificada']=comparison['fecha_planificada']
            data['corresponde']=comparison['verificacion'];data['diferencias']=comparison['diferencias']
        if kind in ('receipts','deliveries'):
            data['evidencias']=len(store.attachments(kind,year,row['id']))
        data['situacion']='Eliminado' if row['data'].get('_deleted') else 'Activo'
        if kind=='attendance':
            if start_date and data.get('fecha','')<start_date:continue
            if end_date and data.get('fecha','')>end_date:continue
            data['horas']=_worked_hours(data.get('entrada',''),data.get('salida',''))
        result.append(data)
    if kind=='attendance':result.sort(key=lambda row:(row.get('fecha',''),row.get('personal','')))
    return result

COLUMNS={'students':['codigo','nombre','nacimiento','edad','nivel','grado','seccion','estado'],'staff':['codigo','nombre','cargo','telefono','estado'],
 'attendance':['personal','fecha','estado','entrada','salida','horas'],'menus':['fecha_planificada','dia','servicio','descripcion','raciones_previstas','estado'],
'receipts':['fecha','hora','servicio','menu_previsto','corresponde','diferencias','suplidor','cantidad','rechazadas','evidencias'],'expenses':['fecha','concepto','suplidor','factura','monto','estado'],
'facilities':['fecha','area','condicion','accion','responsable','estado'],'visits':['fecha','hora_entrada','hora_salida','nombre','institucion','motivo','recibido_por'],
'deliveries':['fecha','hora','categoria','articulo','cantidad','unidad','entregado_por','condicion','estado','evidencias'],
'reminders':['fecha','hora','titulo','categoria','prioridad','responsable','estado'],
'coaching':['fecha','personal','tipo','resultados','acuerdos','fecha_seguimiento','estado']}

def _photo_evidence(store,kind,year,rows):
    story=[]
    for row in rows:
        attached=store.attachments(kind,year,row['id']);photos=[a for a in attached if a['mime'] in ('image/jpeg','image/png')];videos=[a for a in attached if a['mime'].startswith('video/')]
        if not photos and not videos:continue
        story.extend([PageBreak(),p(f"Evidencias · registro {row['id']}",'Heading2')])
        for photo in photos:
            try:
                image=PDFImage(io.BytesIO(store.attachment_bytes(kind,year,row['id'],photo['id'])))
                scale=min(1,480/image.imageWidth,620/image.imageHeight)
                image.drawWidth=image.imageWidth*scale;image.drawHeight=image.imageHeight*scale
                story.extend([p(photo['name'],'Normal'),Spacer(1,5),image,Spacer(1,14)])
            except Exception:
                story.append(p(f"No fue posible mostrar {photo['name']}; el archivo permanece guardado como adjunto.",'Normal'))
        if videos:
            story.append(p('Videos conservados en el expediente digital','Heading3'))
            for video in videos:story.append(p(f"{video['name']} · {video['size']/(1024*1024):.1f} MB"))
    return story

def _attendance_summary(rows):
    summary={}
    for row in rows:
        item=summary.setdefault(row.get('personal',''),{'dias':0,'Presente':0,'Tardanza':0,'Ausente':0,'Permiso':0,'Licencia':0,'minutes':0})
        item['dias']+=1;state=row.get('estado','')
        if state in item:item[state]+=1
        hours=row.get('horas','')
        if hours:
            h,m=map(int,hours.split(':'));item['minutes']+=h*60+m
    return [[name,item['dias'],item['Presente'],item['Tardanza'],item['Ausente'],item['Permiso']+item['Licencia'],f"{item['minutes']//60:02d}:{item['minutes']%60:02d}"] for name,item in sorted(summary.items())]

def report_pdf(store,kind,year,path,search='',include_photos=False,start_date='',end_date=''):
    rows=readable_rows(store,kind,year,search,start_date,end_date); cols=[c for c in COLUMNS[kind] if c!='evidencias']; fields={f.key:f for f in MODULES[kind][1]};labels={k:f.label for k,f in fields.items()};labels.update(edad='Edad actual',horas='Horas trabajadas',menu_previsto='Menú planificado',fecha_planificada='Fecha planificada',evidencias='Evidencias')
    story=title_block(store,year,MODULES[kind][0]); story.append(p(f'Registros incluidos: {len(rows)}'+(f' · Filtro de búsqueda: {search}' if search else '')))
    if kind=='attendance':
        period=f"Período: {date.fromisoformat(start_date).strftime('%d/%m/%Y') if start_date else 'inicio del año'} al {date.fromisoformat(end_date).strftime('%d/%m/%Y') if end_date else 'fin del año'}"
        story.extend([p(period),Spacer(1,10),p('Resumen por persona','Heading2'),table(['Personal','Días','Presente','Tardanza','Ausente','Permiso/licencia','Horas'],_attendance_summary(rows),landscape(A4)[0]-72),Spacer(1,16),p('Detalle diario','Heading2')])
    story.append(Spacer(1,12))
    if kind=='expenses':
        total=sum((Decimal(r['monto']) for r in rows if r['estado']!='Anulado'),Decimal(0)); story.append(p(f'Total no anulado: RD$ {total:,.2f}','Heading2'))
    story.append(table([labels[c] for c in cols],[[r.get(c,'') for c in cols] for r in rows],landscape(A4)[0]-72))
    if include_photos:story.extend(_photo_evidence(store,kind,year,rows))
    atomic_write(path,pdf_bytes(story,True)); store.log_export(kind,year)

def record_pdf(store,kind,year,rid,path):
    r=store.record(kind,year,rid); data=next(x for x in readable_rows(store,kind,year) if x['id']==rid)
    story=title_block(store,year,'Expediente / detalle del registro')
    story.append(p(f'{MODULES[kind][0]} · Registro {rid} · Versión {r["version"]}','Heading2'))
    for f in MODULES[kind][1]:
        story.extend([p(f.label,'Heading3'),p(data.get(f.key,'') or 'No registrado','LetterAula')])
    if kind=='students':
        profile=store.student_profile(year,r['data']);story.extend([p('Edad actual','Heading3'),p(profile['edad'],'LetterAula'),p('Edad al iniciar el año escolar','Heading3'),p(profile['edad_inicio_año'],'LetterAula'),p('Rango configurado para el grado','Heading3'),p(profile['rango_esperado'],'LetterAula')])
    at=store.attachments(kind,year,rid)
    if at:
        story.append(p('Adjuntos asociados','Heading2'))
        for a in at: story.append(p(a['name']))
    atomic_write(path,pdf_bytes(story)); store.log_export(kind,year)

def xlsx_bytes(store,kind,year,search='',start_date='',end_date=''):
    rows=readable_rows(store,kind,year,search,start_date,end_date); fields=MODULES[kind][1]
    wb=Workbook(); ws=wb.active; ws.title=MODULES[kind][0][:31]
    if kind=='attendance':
        ws.title='Resumen';ws.append([institution(store,year)['centro']]);ws.append([f"Año escolar {store.year(year)['label']} · Resumen de asistencia"]);ws.append(['Personal','Días registrados','Presente','Tardanza','Ausente','Permiso/licencia','Horas trabajadas'])
        for item in _attendance_summary(rows):ws.append(item)
        detail=wb.create_sheet('Detalle diario');detail.append([institution(store,year)['centro']]);detail.append([f"Período {start_date or store.year(year)['start_date']} al {end_date or store.year(year)['end_date']}"]);detail.append(['Personal','Fecha','Estado','Entrada','Salida','Horas trabajadas','Justificación / notas'])
        for row in rows:detail.append([row.get('personal',''),date.fromisoformat(row['fecha']),row.get('estado',''),row.get('entrada',''),row.get('salida',''),row.get('horas',''),row.get('notas','')])
        for sheet in (ws,detail):
            for cell in sheet[3]:cell.fill=PatternFill('solid',fgColor='183849');cell.font=Font(color='FFFFFF',bold=True)
            sheet['A1'].font=Font(size=16,bold=True,color='183849');sheet['A2'].font=Font(size=11,color='506674');sheet.freeze_panes='A4';sheet.auto_filter.ref=f'A3:{get_column_letter(sheet.max_column)}{max(3,sheet.max_row)}';sheet.sheet_view.showGridLines=False;sheet.print_title_rows='1:3';sheet.sheet_properties.pageSetUpPr.fitToPage=True;sheet.page_setup.orientation='landscape';sheet.page_setup.paperSize=sheet.PAPERSIZE_A4;sheet.page_setup.fitToWidth=1;sheet.page_setup.fitToHeight=0
            for row in sheet:
                for cell in row:
                    if isinstance(cell.value,str):cell.data_type='s'
                    cell.alignment=Alignment(vertical='top',wrap_text=True)
            for col in range(1,sheet.max_column+1):sheet.column_dimensions[get_column_letter(col)].width=34 if col in (1,sheet.max_column) else 20
        for cell in detail['B'][3:]:cell.number_format='dd/mm/yyyy'
        out=io.BytesIO();wb.save(out);return out.getvalue()
    if kind=='receipts':
        ws.title='Recepciones y comparación';ws.append([institution(store,year)['centro']]);ws.append([f"Año escolar {store.year(year)['label']} · Control INABIE"])
        headers=['Fecha recibida','Hora','Servicio','Menú planificado','Corroboración','Diferencias','Suplidor','Cantidad','Rechazadas','Responsable','Incidencias','Observaciones']
        ws.append(headers)
        for row in rows:
            ws.append([date.fromisoformat(row['fecha']),row.get('hora',''),row.get('servicio',''),row.get('menu_previsto',''),row.get('corresponde',''),row.get('diferencias',''),row.get('suplidor',''),row.get('cantidad',''),row.get('rechazadas',''),row.get('responsable',''),row.get('incidencias',''),row.get('observaciones','')])
        for row in ws:
            for cell in row:
                if isinstance(cell.value,str):cell.data_type='s'
                cell.alignment=Alignment(vertical='top',wrap_text=True)
        for cell in ws[3]:cell.fill=PatternFill('solid',fgColor='183849');cell.font=Font(color='FFFFFF',bold=True)
        ws['A1'].font=Font(size=16,bold=True,color='183849');ws['A2'].font=Font(size=11,color='506674')
        for cell in ws['A'][3:]:cell.number_format='dd/mm/yyyy'
        for col in range(1,len(headers)+1):ws.column_dimensions[get_column_letter(col)].width=42 if col in (4,6,11,12) else 19
        ws.freeze_panes='D4';ws.auto_filter.ref=f'A3:{get_column_letter(len(headers))}{max(3,ws.max_row)}';ws.sheet_view.showGridLines=False;ws.print_title_rows='1:3';ws.sheet_properties.pageSetUpPr.fitToPage=True;ws.page_setup.orientation='landscape';ws.page_setup.paperSize=ws.PAPERSIZE_A4;ws.page_setup.fitToWidth=1;ws.page_setup.fitToHeight=0
        out=io.BytesIO();wb.save(out);return out.getvalue()
    ws.append([institution(store,year)['centro']]); ws.append([f"Año escolar {store.year(year)['label']} · {MODULES[kind][0]}"]); ws.append([f.label for f in fields])
    for row in rows:
        values=[]
        for f in fields:
            v=row.get(f.key,'')
            if v!='' and f.type=='money': v=Decimal(v)
            elif v!='' and f.type=='date': v=date.fromisoformat(v)
            values.append(v)
        ws.append(values)
    # Las entradas de usuario se guardan como texto, nunca como fórmulas Excel.
    for row in ws:
        for cell in row:
            if isinstance(cell.value,str): cell.data_type='s'
            cell.alignment=Alignment(vertical='top',wrap_text=True)
    for cell in ws[3]: cell.fill=PatternFill('solid',fgColor='183849'); cell.font=Font(color='FFFFFF',bold=True)
    ws['A1'].font=Font(size=16,bold=True,color='183849'); ws['A2'].font=Font(size=11,color='506674')
    for i,f in enumerate(fields,1):
        ws.column_dimensions[get_column_letter(i)].width=34 if f.type=='long' or f.key in ('nombre','concepto') else 22
        for row in range(4,len(rows)+4):
            c=ws.cell(row,i)
            if f.type=='money': c.number_format='"RD$ "#,##0.00'
            elif f.type=='integer': c.number_format='#,##0'
            elif f.type=='date': c.number_format='dd/mm/yyyy'
    ws.freeze_panes='C4'; ws.auto_filter.ref=f'A3:{get_column_letter(len(fields))}{max(3,len(rows)+3)}'
    ws.sheet_view.showGridLines=False; ws.print_title_rows='1:3'; ws.sheet_properties.pageSetUpPr.fitToPage=True
    ws.page_setup.orientation='landscape'; ws.page_setup.paperSize=ws.PAPERSIZE_A4; ws.page_setup.fitToWidth=1; ws.page_setup.fitToHeight=0
    out=io.BytesIO(); wb.save(out); return out.getvalue()
def report_xlsx(store,kind,year,path,search='',start_date='',end_date=''):
    atomic_write(path,xlsx_bytes(store,kind,year,search,start_date,end_date)); store.log_export(kind,year)

DEFAULT_TEMPLATES={
 'staff': 'A quien pueda interesar:\n\nPor medio de la presente, {centro} hace constar que {nombre}, documento {documento}, figura en los registros del año escolar {año} con el cargo de {cargo}, fecha de ingreso {ingreso}, vínculo {vinculo} y estado {estado}.\n\nEsta constancia se expide a solicitud de la persona interesada, en fecha {fecha_emision}.',
 'students': 'A quien pueda interesar:\n\nLa Dirección de {centro} certifica que {nombre}, código {codigo_estudiante}, figura en la matrícula del año escolar {año}, en {grado}, sección {seccion}, con estado {estado}.\n\nEsta certificación se expide a solicitud de la persona interesada, en fecha {fecha_emision}.'}

def document_text(store,kind,year,rid,template=None):
    if kind not in DEFAULT_TEMPLATES: raise AppError('Seleccione un estudiante o una persona del personal.')
    d=store.record(kind,year,rid)['data']; s=institution(store,year)
    values={**d,**s,'nombre':d['nombre'],'año':store.year(year)['label'],'codigo_estudiante':d.get('codigo',''),'fecha_emision':date.today().strftime('%d/%m/%Y')}
    text=template or store.settings().get('template_'+kind,DEFAULT_TEMPLATES[kind])
    try: return text.format_map(values)
    except (KeyError,ValueError,AttributeError,IndexError) as e: raise AppError('La plantilla contiene un campo no válido. Use los campos de la plantilla original.') from e

def letter_pdf(store,kind,year,rid,path,body=None):
    store.record(kind,year,rid)
    if store.user['role'] not in ('admin','direccion','secretaria'): raise AppError('No tiene permiso para emitir certificaciones.')
    title='CONSTANCIA DE TRABAJO' if kind=='staff' else 'CERTIFICACIÓN DE MATRÍCULA'
    story=title_block(store,year,title)
    for paragraph in (body or document_text(store,kind,year,rid)).split('\n\n'): story.append(p(paragraph,'LetterAula'))
    story.extend([Spacer(1,50),p('________________________________','Normal'),p(institution(store,year).get('director',''),'Normal'),p('Dirección del centro educativo','Normal'),Spacer(1,16),p('Firma y sello institucional','Normal')])
    atomic_write(path,pdf_bytes(story)); store.log_export(kind,year)

def export_year(store,year,path):
    store.require(admin=True); y=store.year(year)
    out=io.BytesIO()
    with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
        z.writestr('LEEME.txt','Archivo histórico consultable. No restaura la aplicación. Para restaurar, use un respaldo .aulabackup.\nLos adjuntos contienen datos personales; proteja este archivo.\n')
        z.writestr('año.json',json.dumps(y,ensure_ascii=False,indent=2))
        z.writestr('centro.json',json.dumps(institution(store,year),ensure_ascii=False,indent=2))
        z.writestr('estructura_academica.json',json.dumps(store.academic_summary(year),ensure_ascii=False,indent=2))
        z.writestr('auditoria.json',json.dumps(store.audit(year),ensure_ascii=False,indent=2))
        for kind in MODULES:
            rows=store.list_records(kind,year,include_deleted=True)
            z.writestr(f'{kind}.json',json.dumps(rows,ensure_ascii=False,indent=2)); z.writestr(f'{kind}.xlsx',xlsx_bytes(store,kind,year))
            for r in rows:
                for a in store.attachments(kind,year,r['id']):
                    name=Path(a['name']).name
                    z.writestr(f"adjuntos/{kind}/{r['id']}/{a['id']}-{name}",store.attachment_bytes(kind,year,r['id'],a['id']))
    atomic_write(path,out.getvalue())
    with store.db: store._audit('exportar_año',year)
