import argparse, json, socket, tempfile
from pathlib import Path
from .ui import run

def self_test():
    """Prueba el bundle instalado sin abrir ventanas ni usar la red."""
    from .core import Store
    from .backup import create_backup, restore_backup
    from . import reports
    original_socket = socket.socket
    socket.socket = lambda *a, **k: (_ for _ in ()).throw(RuntimeError('red bloqueada'))
    try:
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            store = Store(root/'datos')
            password = 'Validacion-local-2026'
            recovery_code=store.bootstrap('admin', password, 'Dirección de prueba', 'Centro de validación')
            year = store.create_year('2026-2027', '2026-08-01', '2027-07-31')
            rid = store.save_record('students', year, {
                'codigo':'E001','nombre':'María de Validación','nacimiento':'2013-02-10',
                'sexo':'Femenino','tutor':'Tutor de prueba','telefono':'809-000-0000',
                'nivel':'Nivel Secundario','grado':'1.º de Secundaria','seccion':'A','fecha':'2026-09-01','estado':'Activo'})
            from openpyxl import Workbook
            workbook=Workbook();sheet=workbook.active;sheet.append(['Nombre completo','Fecha de nacimiento']);sheet.append(['Luis Importado','2022-04-10']);sheet.append(['Ana Importada','2022-06-12'])
            workbook.save(root/'importacion.xlsx')
            assert store.import_records('students',year,root/'importacion.xlsx',{'nivel':'Inicial','grado':'kinder','seccion':'A'})==2
            store.save_record('facilities',year,{'fecha':'2026-09-01','area':'Aula 1','condicion':'Buena','hallazgo':'Sin novedad','estado':'Resuelto'})
            store.save_record('visits',year,{'fecha':'2026-09-01','hora_entrada':'09:00','nombre':'Visita de prueba','motivo':'Supervisión','recibido_por':'Dirección'})
            store.save_food_service('Frutas',True)
            delivery=store.save_record('deliveries',year,{'fecha':'2026-09-01','hora':'09:30','categoria':'Mobiliario','articulo':'Sillas','cantidad':'12','unidad':'unidad','entregado_por':'Proveedor','recibido_por':'Dirección','condicion':'Buena','estado':'Recibido'})
            store.save_record('reminders',year,{'titulo':'Asamblea','fecha':'2026-09-15','hora':'09:00','categoria':'Asamblea','prioridad':'Importante','responsable':'Dirección','detalle':'Prueba local','estado':'Pendiente'})
            teacher=store.save_record('staff',year,{'codigo':'P001','nombre':'Docente de prueba','cargo':'Docente','ingreso':'2026-08-01','vinculo':'Fijo','salario':'1.00','estado':'Activo'})
            punch=Workbook();punch_sheet=punch.active;punch_sheet.append(['Código empleado','Nombre','Fecha y hora']);punch_sheet.append(['P001','Docente de prueba','01/09/2026 07:55']);punch_sheet.append(['P001','Docente de prueba','01/09/2026 16:05']);punch.save(root/'ponchador.xlsx')
            punch_preview=store.preview_attendance_import(year,root/'ponchador.xlsx');assert punch_preview['matched_days']==1
            assert store.apply_attendance_import(year,punch_preview)['created']==1
            reports.report_xlsx(store,'attendance',year,root/'asistencia.xlsx','', '2026-09-01','2026-09-30')
            store.save_record('coaching',year,{'fecha':'2026-09-02','personal':teacher,'tipo':'Observación de aula','fortalezas':'Planificación','resultados':'Seguimiento requerido','acuerdos':'Revisar planificación','estado':'En seguimiento'})
            reports.record_pdf(store, 'students', year, rid, root/'expediente.pdf')
            reports.report_pdf(store,'deliveries',year,root/'entregas.pdf')
            reports.report_xlsx(store, 'students', year, root/'estudiantes.xlsx')
            create_backup(store, root/'copia.aulabackup', password)
            store.save_record('students', year, {
                'codigo':'E002','nombre':'Segundo Registro','nacimiento':'2013-02-10',
                'sexo':'Masculino','tutor':'Tutor de prueba','telefono':'809-000-0000',
                'nivel':'Nivel Secundario','grado':'1.º de Secundaria','seccion':'A','fecha':'2026-09-01','estado':'Activo'})
            restore_backup(store, root/'copia.aulabackup', password, password)
            store.login('admin', password)
            assert len(store.list_records('students', year)) == 3
            assert (root/'expediente.pdf').read_bytes().startswith(b'%PDF-')
            assert (root/'estudiantes.xlsx').read_bytes().startswith(b'PK')
            store.close()
            resumed=Store(root/'datos');assert resumed.user and resumed.user['username']=='admin';resumed.logout()
            new_recovery=resumed.recover_access(recovery_code,'admin2','Validacion-nueva-2026');assert new_recovery.startswith('AULA-')
            resumed.login('admin2','Validacion-nueva-2026');resumed.close()
            return {'status':'ok','arquitectura':__import__('platform').machine(),
                    'persistencia':True,'pdf':True,'excel':True,'respaldo':True,'sin_red':True,
                    'estructura_academica':True,'importacion_excel':True,'sesion_persistente':True,
                    'recuperacion_local':True,'planta_y_visitas':True,'agenda':True,
                    'entregas_generales':True,'acompanamiento_docente':True,'asistente_local':True,
                    'alimentacion_configurable':True,'importacion_ponchador':True}
    finally:
        socket.socket = original_socket

def main():
    p=argparse.ArgumentParser(description='AulaLocal: gestión escolar local')
    p.add_argument('--data-dir',help='Carpeta de datos alternativa para pruebas aisladas')
    p.add_argument('--self-test',action='store_true',help=argparse.SUPPRESS)
    args=p.parse_args()
    if args.self_test:
        print(json.dumps(self_test(),ensure_ascii=False)); return
    raise SystemExit(run(args.data_dir))

if __name__=='__main__':main()
