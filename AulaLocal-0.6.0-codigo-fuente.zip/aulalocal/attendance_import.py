"""Lectura local de archivos de ponchador y normalización de marcaciones."""
from __future__ import annotations

import csv
import re
import unicodedata
from collections import defaultdict
from datetime import date, datetime, time, timedelta
from difflib import SequenceMatcher
from pathlib import Path

from .core import AppError


def norm(value):
    return re.sub(r'[^a-z0-9]+', ' ', unicodedata.normalize('NFKD', str(value or '')).encode('ascii', 'ignore').decode().lower()).strip()


def _rows_from_file(path):
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == '.csv':
        for encoding in ('utf-8-sig', 'latin-1'):
            try:
                with path.open(encoding=encoding, newline='') as fh:
                    return [('CSV', list(csv.reader(fh)))]
            except UnicodeDecodeError:
                continue
    if suffix == '.xlsx':
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True, data_only=True)
        return [(ws.title, [list(row) for row in ws.iter_rows(values_only=True)]) for ws in wb.worksheets]
    if suffix == '.xls':
        try:
            import xlrd
        except ImportError as exc:
            raise AppError('Este archivo usa el formato Excel antiguo .xls. Instala la actualización completa de AulaLocal para poder leerlo.') from exc
        book = xlrd.open_workbook(path)
        sheets = []
        for sheet in book.sheets():
            rows = []
            for r in range(sheet.nrows):
                row = []
                for c in range(sheet.ncols):
                    cell = sheet.cell(r, c)
                    value = cell.value
                    if cell.ctype == xlrd.XL_CELL_DATE:
                        value = xlrd.xldate_as_datetime(value, book.datemode)
                    row.append(value)
                rows.append(row)
            sheets.append((sheet.name, rows))
        return sheets
    raise AppError('Seleccione el archivo del ponchador en formato Excel (.xlsx o .xls) o CSV.')


ALIASES = {
    'code': {'codigo', 'codigo empleado', 'codigo personal', 'id', 'id usuario', 'user id', 'employee id', 'pin', 'numero empleado', 'no empleado', 'enroll number', 'ac no'},
    'document': {'documento', 'cedula', 'identificacion', 'document id'},
    'name': {'nombre', 'nombre completo', 'nombres y apellidos', 'empleado', 'personal', 'employee', 'employee name', 'user name', 'usuario'},
    'date': {'fecha', 'dia', 'date', 'work date', 'fecha asistencia'},
    'datetime': {'fecha hora', 'fecha y hora', 'date time', 'datetime', 'check time', 'punch time', 'hora marcacion', 'fecha marcacion'},
    'entry': {'entrada', 'hora entrada', 'primera entrada', 'check in', 'clock in', 'in time', 'first in'},
    'exit': {'salida', 'hora salida', 'ultima salida', 'check out', 'clock out', 'out time', 'last out'},
    'punch': {'hora', 'time', 'marcacion', 'marcaciones', 'registro', 'punch', 'checado', 'fichada'},
}


def _header_kind(value):
    value = norm(value)
    for kind, aliases in ALIASES.items():
        if value in aliases:
            return kind
    if ('entrada' in value or value.endswith(' in')) and 'fecha' not in value:
        return 'entry'
    if ('salida' in value or value.endswith(' out')) and 'fecha' not in value:
        return 'exit'
    if 'nombre' in value and ('empleado' in value or 'personal' in value or value == 'nombre'):
        return 'name'
    if ('marc' in value or 'punch' in value or 'check' in value) and ('fecha' in value or 'time' in value or 'hora' in value):
        return 'datetime'
    return None


def _date_value(value):
    if isinstance(value, datetime):
        return value.date()
    if isinstance(value, date):
        return value
    text = str(value or '').strip()
    if not text:
        return None
    text = text.split()[0]
    for fmt in ('%Y-%m-%d', '%d/%m/%Y', '%d-%m-%Y', '%d.%m.%Y', '%Y/%m/%d', '%m/%d/%Y'):
        try:
            return datetime.strptime(text, fmt).date()
        except ValueError:
            pass
    return None


def _time_values(value):
    if isinstance(value, datetime):
        return [value.time().replace(second=0, microsecond=0)]
    if isinstance(value, time):
        return [value.replace(second=0, microsecond=0)]
    if isinstance(value, (int, float)) and 0 <= value < 1:
        minutes = round(float(value) * 24 * 60)
        return [time((minutes // 60) % 24, minutes % 60)]
    text = str(value or '').strip()
    if not text:
        return []
    matches = re.findall(r'(?<!\d)([01]?\d|2[0-3]):([0-5]\d)(?::[0-5]\d)?\s*([AaPp][Mm])?', text)
    result = []
    for hour, minute, meridiem in matches:
        hour = int(hour); minute = int(minute)
        if meridiem:
            if hour == 12:
                hour = 0
            if meridiem.lower() == 'pm':
                hour += 12
        result.append(time(hour, minute))
    return result


def _datetime_value(value):
    if isinstance(value, datetime):
        return value
    text = str(value or '').strip()
    if not text:
        return None
    for fmt in ('%Y-%m-%d %H:%M:%S', '%Y-%m-%d %H:%M', '%d/%m/%Y %H:%M:%S', '%d/%m/%Y %H:%M', '%d-%m-%Y %H:%M:%S', '%d-%m-%Y %H:%M'):
        try:
            return datetime.strptime(text, fmt)
        except ValueError:
            pass
    d = _date_value(text)
    times = _time_values(text)
    return datetime.combine(d, times[0]) if d and times else None


def _find_header(rows):
    best = None
    for index, row in enumerate(rows[:30]):
        kinds = [_header_kind(value) for value in row]
        date_headers = [_date_value(value) for value in row]
        has_identity = any(kind in ('code', 'document', 'name') for kind in kinds)
        has_time = any(kind in ('date', 'datetime', 'entry', 'exit', 'punch') for kind in kinds) or any(date_headers)
        score = sum(kind is not None for kind in kinds) + sum(value is not None for value in date_headers)
        if has_identity and has_time and (best is None or score > best[0]):
            best = (score, index, kinds, date_headers)
    return best


def _staff_matcher(staff):
    indexes = {key: defaultdict(list) for key in ('code', 'document', 'name')}
    for record in staff:
        data = record['data']
        for key, field in (('code', 'codigo'), ('document', 'documento'), ('name', 'nombre')):
            value = norm(data.get(field))
            if value:
                indexes[key][value].append(record)

    def match(code='', document='', name=''):
        candidates = []
        for key, value in (('code', code), ('document', document), ('name', name)):
            value = norm(value)
            if value and len(indexes[key][value]) == 1:
                candidates.append(indexes[key][value][0])
        if candidates:
            return candidates[0] if len({candidate['id'] for candidate in candidates}) == 1 else None
        needle = norm(name)
        if not needle:
            return None
        names = [(SequenceMatcher(None, needle, key).ratio(), records[0]) for key, records in indexes['name'].items() if len(records) == 1]
        names.sort(key=lambda item: item[0], reverse=True)
        if names and names[0][0] >= .92 and (len(names) == 1 or names[0][0] - names[1][0] >= .04):
            return names[0][1]
        return None
    return match


def analyze(path, staff, start_date, end_date, scheduled_start='08:00', grace_minutes=15):
    """Devuelve una vista previa; no modifica la base de datos."""
    sheets = _rows_from_file(path)
    selected = None
    for sheet_name, rows in sheets:
        header = _find_header(rows)
        if header and (selected is None or header[0] > selected[0]):
            selected = (*header, sheet_name, rows)
    if not selected:
        raise AppError('No pude reconocer las columnas del archivo. Debe contener nombre o código del personal y fecha/hora de marcación.')
    _, header_index, kinds, date_headers, sheet_name, rows = selected
    match_staff = _staff_matcher(staff)
    grouped = defaultdict(lambda: {'times': [], 'entries': [], 'exits': [], 'lines': []})
    unmatched = []
    ignored = []
    source_rows = 0
    for line_number, row in enumerate(rows[header_index + 1:], header_index + 2):
        if not any(value not in (None, '') for value in row):
            continue
        source_rows += 1
        values = defaultdict(list)
        for column, value in enumerate(row):
            kind = kinds[column] if column < len(kinds) else None
            if kind:
                values[kind].append(value)
        code = next((str(value).strip() for value in values['code'] if str(value).strip()), '')
        document = next((str(value).strip() for value in values['document'] if str(value).strip()), '')
        name = next((str(value).strip() for value in values['name'] if str(value).strip()), '')
        person = match_staff(code, document, name)
        identity = name or code or document or f'fila {line_number}'
        if not person:
            unmatched.append(f'Fila {line_number}: {identity}')
            continue

        events = defaultdict(lambda: {'times': [], 'entries': [], 'exits': []})
        explicit_date = next((_date_value(value) for value in values['date'] if _date_value(value)), None)
        for value in values['datetime']:
            dt = _datetime_value(value);event_date=dt.date() if dt else _date_value(value);punches=_time_values(value)
            if event_date:
                events[event_date]['times'].extend(punches or ([dt.time().replace(second=0,microsecond=0)] if dt else []))
        for value in values['entry']:
            for punch in _time_values(value):
                if explicit_date:
                    events[explicit_date]['entries'].append(punch)
        for value in values['exit']:
            for punch in _time_values(value):
                if explicit_date:
                    events[explicit_date]['exits'].append(punch)
        for value in values['punch']:
            dt = _datetime_value(value);event_date=dt.date() if dt else _date_value(value);punches=_time_values(value)
            if event_date:
                events[event_date]['times'].extend(punches or ([dt.time().replace(second=0,microsecond=0)] if dt else []))
            elif explicit_date:
                events[explicit_date]['times'].extend(punches)
        # Formato matricial: cada encabezado es una fecha y cada celda contiene las marcaciones.
        for column, header_date in enumerate(date_headers):
            if header_date and column < len(row):
                events[header_date]['times'].extend(_time_values(row[column]))
        if explicit_date and explicit_date not in events:
            events[explicit_date]  # conserva días con entrada/salida vacías para advertirlos
        for event_date, event in events.items():
            if not (start_date <= event_date.isoformat() <= end_date):
                ignored.append(f'Fila {line_number}: {event_date.strftime("%d/%m/%Y")} está fuera del año escolar')
                continue
            bucket = grouped[(person['id'], event_date.isoformat())]
            bucket['times'].extend(event['times']); bucket['entries'].extend(event['entries']); bucket['exits'].extend(event['exits']); bucket['lines'].append(line_number)
    if not source_rows:
        raise AppError('El archivo no contiene filas de marcaciones.')

    try:
        expected = datetime.strptime(scheduled_start, '%H:%M')
    except ValueError as exc:
        raise AppError('La hora esperada debe tener el formato HH:MM.') from exc
    late_after = (expected + timedelta(minutes=max(0, int(grace_minutes)))).time()
    records = []
    names = {record['id']: record['data']['nombre'] for record in staff}
    incomplete = 0
    for (person_id, event_date), event in sorted(grouped.items(), key=lambda item: (item[0][1], names.get(item[0][0], ''))):
        all_times = sorted(set(event['times'] + event['entries'] + event['exits']))
        entry = min(event['entries']) if event['entries'] else (all_times[0] if all_times else None)
        exit_time = max(event['exits']) if event['exits'] else (all_times[-1] if len(all_times) >= 2 else None)
        if not entry and not exit_time:
            ignored.append(f'{names.get(person_id, person_id)} · {event_date}: sin una hora reconocible')
            continue
        notes = f'Importado del ponchador: {Path(path).name}'
        if entry and not exit_time:
            notes += ' · Falta marcación de salida'; incomplete += 1
        elif exit_time and not entry:
            notes += ' · Falta marcación de entrada'; incomplete += 1
        state = 'Tardanza' if entry and entry > late_after else 'Presente'
        records.append({'personal': person_id, 'fecha': event_date, 'estado': state,
                        'entrada': entry.strftime('%H:%M') if entry else '',
                        'salida': exit_time.strftime('%H:%M') if exit_time else '', 'notas': notes})
    if not records:
        detail = ('\n' + '\n'.join(unmatched[:8])) if unmatched else ''
        raise AppError('No se encontró ninguna marcación que pudiera relacionarse con el personal registrado.' + detail)
    return {'file': Path(path).name, 'sheet': sheet_name, 'source_rows': source_rows, 'records': records,
            'matched_days': len(records), 'unmatched': unmatched, 'ignored': ignored, 'incomplete': incomplete,
            'scheduled_start': scheduled_start, 'grace_minutes': int(grace_minutes)}
