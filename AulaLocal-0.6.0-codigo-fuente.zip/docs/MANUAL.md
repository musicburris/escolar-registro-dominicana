# Manual de AulaLocal

## Primer uso y acceso

Escriba el nombre del centro, nombre del director, usuario y una contraseña de al menos 12 caracteres. AulaLocal mostrará un código de recuperación: guárdelo impreso o en un lugar seguro fuera del Mac. No existen cuentas predeterminadas.

La opción **Mantener mi sesión iniciada** queda seleccionada por defecto. Cerrar la ventana no cierra la sesión; al abrir AulaLocal continuará donde estaba. Use **Cerrar sesión** cuando no quiera mantener el acceso. Si olvida el usuario o la contraseña, pulse **Olvidé mi usuario o contraseña**, escriba su código y defina datos nuevos. Tras recuperarse recibirá un código nuevo. Otra cuenta administradora también puede restablecer contraseñas.

El reloj mostrado corresponde a la fecha, hora y zona horaria configuradas en macOS. El Mac conserva su reloj mientras está apagado; AulaLocal vuelve a consultarlo al abrir. Si alguien cambia manualmente la hora del sistema, la aplicación reflejará ese cambio.

## Años escolares

El selector superior determina el año de todos los módulos. **Abierto** permite guardar; **Congelado** permite consultar y exportar; **Archivado** conserva el histórico. Solo Administración crea períodos, congela, archiva y reabre. Las transiciones exigen contraseña y motivo y quedan auditadas.

Para el año siguiente, créelo y use **Copiar matrículas o personal**. No se copian asistencias, gastos, alimentación ni adjuntos. El expediente anterior permanece intacto.

## Niveles, grados, secciones y edades

En **Niveles, grados y secciones**, Administración puede crear su propia estructura. Se incluyen inicialmente:

- Nivel Inicial: Kínder y Preprimario.
- Nivel Primario: 1.º a 6.º.
- Nivel Secundario: 1.º a 6.º.

Cada grado admite una edad mínima y máxima. Cada sección pertenece a un grado y año escolar y puede tener capacidad. Al registrar un estudiante, los selectores muestran únicamente combinaciones válidas. La ficha muestra edad actual, edad al inicio del año y el rango del grado; una edad fuera del rango se señala como información para revisión, sin impedir la matrícula.

## Importar estudiantes o personal desde Excel

Abra **Estudiantes** o **Personal**, pulse **Descargar plantilla**, complete las filas en Excel y luego pulse **Importar Excel**. También se admite CSV. AulaLocal reconoce encabezados comunes en español, fechas de Excel y variantes como `kinder`, `preprimario`, `primaria` o `secundaria`. Si la hoja no contiene nivel, grado o sección, el programa permite elegir un destino una sola vez para todas las filas.

La importación es completa o nula: si alguna fila contiene un error, no se guarda ninguna y se muestra qué debe corregirse. Los códigos vacíos se crean automáticamente. La plantilla evita tener que digitar estudiantes o empleados uno por uno.

## Estudiantes y personal

Estudiantes conserva identidad, nacimiento, tutor, contacto, salud, apoyos, nivel, grado, sección y matrícula anual. Personal registra identidad, cargo, vínculo, ingreso, salario y contacto. **Ver ficha** muestra el detalle y **Adjuntos** acepta PDF, JPG, PNG, Excel, Word o TXT de hasta 25 MB.

Asistencia usa personal del mismo año y permite presencia, ausencia, permiso, licencia o tardanza con horas de entrada y salida. Para cargar el archivo de una memoria, pulse **Importar ponchador** y seleccione un Excel `.xlsx`, Excel antiguo `.xls` o CSV. Indique la hora esperada y los minutos de tolerancia. El análisis relaciona códigos, documentos o nombres; agrupa todas las marcaciones de cada persona y día; toma la primera como entrada y la última como salida; y muestra una vista previa. Las coincidencias ambiguas o desconocidas no se guardan. Si un día ya existe, la importación lo actualiza en lugar de duplicarlo. Seleccione **Desde** y **Hasta** para generar un PDF imprimible o un Excel con resumen por persona y detalle diario.

## Planta física y visitas

**Planta física** registra fecha, área, condición, hallazgo, acción correctiva, responsable, fecha límite y estado, con evidencia adjunta. **Visitas** registra persona, institución, documento, motivo, quién la recibió y horas de entrada/salida. Estos registros se incluyen en el año seleccionado y en sus exportaciones.

## Alimentación, entregas y gastos

Un **ciclo** es la semana o período durante el cual corresponde un menú. Defina primero los menús por ciclo y luego registre cada recepción con fecha, hora, suplidor, cantidad, unidades rechazadas, responsable, incidencias y observaciones. En **Tipos de alimentación** puede agregar cualquier opción además de Leche, Pan y Almuerzo. **Retirar menú** lo oculta de nuevas recepciones, pero conserva las entregas históricas y sus fotografías.

Use **Entregas y bienes recibidos** para registrar sillas, equipos, materiales, artículos de limpieza, donaciones o cualquier otro bien. Cada registro admite cantidad, unidad, condición, procedencia, destino, observaciones y adjuntos.

Gastos conserva concepto, categoría, suplidor, factura, monto y medio de pago. Un gasto anulado se conserva para auditoría y no suma en el panel. Es contabilidad interna básica, no contabilidad fiscal de doble partida.

## Reportes y documentos

Cada módulo exporta PDF y Excel. **Detalle PDF** genera el expediente completo. Estudiantes y Personal permiten emitir certificaciones o constancias. **Archivo histórico** produce un ZIP con JSON, Excel, estructura académica, auditoría y adjuntos del año. Ese ZIP no reemplaza una copia de seguridad.

Al exportar alimentación o entregas generales, el programa pregunta si desea incluir fotografías. Después de guardar un PDF ofrece abrirlo en Vista Previa para imprimir. Si macOS no permite escribir en una carpeta, elija Escritorio o Documentos. Los fallos inesperados muestran un código y se registran únicamente en el archivo local `errores.log`.

## Agenda, acompañamiento y asistente local

**Agenda y recordatorios** permite registrar reuniones, asambleas, supervisiones, entregas, actividades y fechas límite. Al abrir AulaLocal se muestran asuntos vencidos o de los próximos siete días. Marque como Completado lo ya realizado.

**Acompañamiento docente** conserva la fecha, docente, tipo de acompañamiento, fortalezas, resultados, acuerdos y seguimiento, con PDF, Excel y adjuntos.

**Asistente local** funciona sin internet y no transmite información. Entiende instrucciones como “abre estudiantes”, “reporte PDF de personal” y “recuérdame asamblea el 15/10/2026 a las 09:00”. Solicita confirmación antes de crear un recordatorio. La sección **Ayuda e instructivo** explica cada flujo paso por paso.

## Copias y seguridad

Los respaldos `.aulabackup` se cifran con la contraseña elegida al crearlos. La restauración verifica el contenido antes de sustituir los datos y conserva una copia previa. El límite es 512 MB por respaldo completo.

Las contraseñas se guardan mediante derivación criptográfica; no se almacenan en texto. Cinco intentos fallidos bloquean la cuenta durante cinco minutos. La base activa se protege con los permisos del usuario de macOS; active FileVault para cifrado completo del disco. La auditoría registra accesos y cambios, pero el propietario administrador del Mac mantiene control físico sobre los archivos.
