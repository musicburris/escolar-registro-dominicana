"""Own and start the packaged ARM64 inference engine without external installation."""
import atexit
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import threading
import time
from .core import AppError, app_directory

MODEL = 'qwen3.5:4b-q4_K_M'
_lock = threading.Lock()
_process = None
_port = None
_verified = False
_shutdown = threading.Event()


def resources():
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent.parent / 'Resources' / 'ai'
    return Path(__file__).resolve().parent.parent / 'build-assets' / 'ai'


def available():
    return (resources() / 'runtime' / 'ollama').is_file()


def verify():
    global _verified
    if _verified:return
    root = resources()
    try:
        manifest = json.loads((root / 'manifest.json').read_text())
        for entry in manifest['files']:
            relative=Path(entry['path'])
            if relative.is_absolute() or '..' in relative.parts:raise ValueError('Ruta no válida')
            path=root/relative
            if path.stat().st_size != entry['size']:raise ValueError('Tamaño incorrecto')
            digest=hashlib.sha256()
            with path.open('rb') as source:
                for part in iter(lambda:source.read(8*1024*1024),b''):digest.update(part)
            if digest.hexdigest()!=entry['sha256']:raise ValueError('Archivo alterado')
        _verified=True
    except (OSError, ValueError, KeyError) as exc:
        raise AppError('Los componentes de IA están incompletos o dañados. Reinstale AulaLocal desde el paquete completo.') from exc


def stop():
    global _process, _port
    process=_process;_process=None;_port=None
    if process and process.poll() is None:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass


atexit.register(stop)


def ensure():
    global _process,_port
    with _lock:
        if _process and _process.poll() is None:return _port
        if not available():
            raise AppError('Esta copia no incluye el motor. Instale la edición completa de AulaLocal.')
        if _shutdown.is_set():raise AppError('El análisis fue detenido al cerrar la aplicación.')
        verify()
        if _shutdown.is_set():raise AppError('El análisis fue detenido al cerrar la aplicación.')
        with socket.socket() as probe:
            probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
        root=resources();data=app_directory()/'ai-runtime';data.mkdir(parents=True,exist_ok=True)
        environment=os.environ.copy()
        environment.update(OLLAMA_HOST=f'127.0.0.1:{port}',OLLAMA_MODELS=str(root/'models'),
            OLLAMA_NO_CLOUD='1',OLLAMA_NOPRUNE='1',OLLAMA_NOHISTORY='1',
            OLLAMA_MAX_LOADED_MODELS='1',OLLAMA_NUM_PARALLEL='1',
            OLLAMA_KEEP_ALIVE='0',OLLAMA_TMPDIR=str(data),OLLAMA_DEBUG='0')
        for name in ('HTTP_PROXY','HTTPS_PROXY','ALL_PROXY','http_proxy','https_proxy','all_proxy'):
            environment.pop(name,None)
        with (data/'engine.log').open('ab') as log:
            _process=subprocess.Popen([str(root/'runtime'/'ollama'),'serve'],env=environment,
                cwd=str(root/'runtime'),stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
        _port=port
        for _ in range(100):
            if _process.poll() is not None:
                raise AppError('El motor incluido no pudo iniciarse. El diagnóstico quedó guardado en ai-runtime/engine.log.')
            try:
                with socket.create_connection(('127.0.0.1',port),timeout=.3):return port
            except OSError:time.sleep(.1)
        stop();raise AppError('El motor local tardó demasiado en iniciar. Inténtelo de nuevo.')


def shutdown():
    _shutdown.set()
    stop()
