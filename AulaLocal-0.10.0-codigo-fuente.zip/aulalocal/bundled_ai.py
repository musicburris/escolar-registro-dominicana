"""Own and start the packaged ARM64 inference engine without external installation."""
import atexit
import hashlib
import http.client
import secrets
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import threading
import time
from .core import AppError, app_directory

MODEL = 'qwen3.5:4b-q4_K_M'
_lock = threading.Lock()
_process = None
_port = None
_token = secrets.token_urlsafe(32)
_verified = False
_shutdown = threading.Event()


def resources():
    if getattr(sys, 'frozen', False):
        return Path(sys.executable).parent.parent / 'Resources' / 'ai'
    return Path(__file__).resolve().parent.parent / 'build-assets' / 'ai'


def available():
    return (resources() / 'runtime' / 'llama-server').is_file()


def verify():
    global _verified
    if _verified:return
    root = resources()
    try:
        manifest = json.loads((root / 'manifest.json').read_text())
        for entry in manifest['files']:
            relative=Path(entry['path'])
            if relative.is_absolute() or '..' in relative.parts:raise ValueError('Ruta no válida')
            path=root/relative
            if path.stat().st_size != entry['size']:raise ValueError('Tamaño incorrecto')
            digest=hashlib.sha256()
            with path.open('rb') as source:
                for part in iter(lambda:source.read(8*1024*1024),b''):digest.update(part)
            if digest.hexdigest()!=entry['sha256']:raise ValueError('Archivo alterado')
        _verified=True
    except (OSError, ValueError, KeyError) as exc:
        raise AppError('Los componentes de IA están incompletos o dañados. Reinstale AulaLocal desde el paquete completo.') from exc


def stop():
    global _process, _port
    process=_process;_process=None;_port=None
    if process and process.poll() is None:
        try:os.killpg(process.pid,signal.SIGTERM)
        except ProcessLookupError:pass


atexit.register(stop)


def ensure():
    global _process,_port
    with _lock:
        if _process and _process.poll() is None:return _port
        if not available():
            raise AppError('Esta copia no incluye el motor. Instale la edición completa de AulaLocal.')
        if _shutdown.is_set():raise AppError('El análisis fue detenido al cerrar la aplicación.')
        verify()
        if _shutdown.is_set():raise AppError('El análisis fue detenido al cerrar la aplicación.')
        with socket.socket() as probe:
            probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
        root=resources();data=app_directory()/'ai-runtime';data.mkdir(parents=True,exist_ok=True)
        environment=os.environ.copy()
        for name in list(environment):
            if name.startswith(('OLLAMA_','LLAMA_','HF_','DYLD_')) or name.lower() in ('http_proxy','https_proxy','all_proxy'):
                environment.pop(name,None)
        command=[str(root/'runtime'/'llama-server'),'-m',str(root/'models'/'voice-assistant.gguf'),
            '--mmproj',str(root/'models'/'vision.gguf'),'--host','127.0.0.1','--port',str(port),
            '--alias',MODEL,'--api-key',_token,'-c','4096','-np','1','-b','256','-ub','128',
            '-t',str(min(4,os.cpu_count() or 2)),'-ngl','99','--no-webui',
            '--chat-template-kwargs','{"enable_thinking":false}']
        with (data/'engine.log').open('ab') as log:
            _process=subprocess.Popen(command,env=environment,
                cwd=str(root/'runtime'),stdin=subprocess.DEVNULL,stdout=log,stderr=log,start_new_session=True)
        _port=port
        for _ in range(360):
            if _shutdown.is_set():stop();raise AppError('Análisis detenido al cerrar la aplicación.')
            if _process.poll() is not None:
                raise AppError('El motor incluido no pudo iniciarse. El diagnóstico quedó guardado en ai-runtime/engine.log.')
            check=http.client.HTTPConnection('127.0.0.1',port,timeout=1)
            try:
                check.request('GET','/health',headers={'Authorization':'Bearer '+_token})
                result=check.getresponse();result.read()
                if result.status==200:return port
            except (OSError,http.client.HTTPException):pass
            finally:check.close()
            time.sleep(.5)
        stop();raise AppError('El motor local tardó demasiado en iniciar. Inténtelo de nuevo.')


def shutdown():
    _shutdown.set()
    stop()
