"""Asistente operativo local: interpreta español y prepara borradores confirmables."""
import re, unicodedata
from datetime import date,datetime,timedelta

def normalize(value):
    return unicodedata.normalize('NFKD',str(value)).encode('ascii','ignore').decode().casefold().strip()

NAVIGATION={'estudiante':'students','matricula':'students','personal':'staff','asistencia':'attendance','menu':'menus','alimentacion':'receipts','comida':'receipts','inabie':'receipts','gasto':'expenses','factura':'expenses','planta':'facilities','visita':'visits','entrega':'deliveries','bien recibido':'deliveries','recordatorio':'reminders','agenda':'reminders','acompanamiento':'coaching','docente':'coaching','centro':'settings','respaldo':'backup','copia de seguridad':'backup','ayuda':'help'}
CREATE=('agrega','agregar','anota','anotar','crea','crear','guarda','guardar','registra','registrar','llego','llegaron','vino','visito','entrego','entregaron','recibimos','recibio','pague','compre','acompane')
HELP=('Puedo registrar alimentación con su menú y evidencias, visitas, bienes recibidos, gastos, '
      'planta física, acompañamientos, asistencia, estudiantes, personal y recordatorios. También '
      'abro módulos y preparo reportes. Ejemplo: “Hoy llegó el almuerzo a las 10:35, menú era arroz '
      'con pollo, 85 raciones, suplidor Comedor Escolar y sí correspondía”. Agregue las fotos antes de enviar.')

def _ref(moment=None):
    if moment is None:return datetime.now().astimezone()
    if isinstance(moment,date) and not isinstance(moment,datetime):return datetime.combine(moment,datetime.min.time()).astimezone()
    return moment

def _date(text,original,moment=None):
    ref=_ref(moment);n=normalize(text)
    found=re.search(r'\b(20\d{2}-\d{1,2}-\d{1,2}|\d{1,2}/\d{1,2}/20\d{2})\b',original)
    if found:
        raw=found.group(1)
        try:
            if '/' in raw:d,m,y=map(int,raw.split('/'));return date(y,m,d).isoformat()
            y,m,d=map(int,raw.split('-'));return date(y,m,d).isoformat()
        except ValueError:return ''
    if 'anteayer' in n:return (ref.date()-timedelta(days=2)).isoformat()
    if 'ayer' in n:return (ref.date()-timedelta(days=1)).isoformat()
    if 'pasado manana' in n:return (ref.date()+timedelta(days=2)).isoformat()
    if re.search(r'(?<!la )\bmanana\b',n):return (ref.date()+timedelta(days=1)).isoformat()
    days={'lunes':0,'martes':1,'miercoles':2,'jueves':3,'viernes':4,'sabado':5,'domingo':6}
    for word,index in days.items():
        if re.search(rf'\b{word}\b',n):return (ref.date()+timedelta(days=(index-ref.weekday())%7)).isoformat()
    return ref.date().isoformat()

def _time(text,moment=None):
    n=normalize(text);found=re.search(r'\b(\d{1,2}):(\d{2})\s*(a\.?\s*m\.?|p\.?\s*m\.?)?\b',n)
    if found:hour=int(found.group(1));minute=int(found.group(2));suffix=found.group(3) or ''
    else:
        found=re.search(r'(?:a\s+las|hora(?:\s+de)?)[\s:]*(\d{1,2})\s*(a\.?\s*m\.?|p\.?\s*m\.?|de\s+la\s+manana|de\s+la\s+tarde|de\s+la\s+noche)?\b',n)
        if not found:return _ref(moment).strftime('%H:%M') if any(x in n for x in ('ahora','acaba de')) else ''
        hour=int(found.group(1));minute=0;suffix=found.group(2) or ''
    if hour>23 or minute>59:return ''
    if ('p' in suffix or 'tarde' in suffix or 'noche' in suffix) and hour<12:hour+=12
    if ('a' in suffix or 'manana' in suffix) and hour==12:hour=0
    return f'{hour:02d}:{minute:02d}'

def _capture(original,*patterns):
    for pattern in patterns:
        match=re.search(pattern,original,re.I|re.S)
        if match:
            value=' '.join(match.group(1).strip(' ,.;:-').split())
            if value:return value[:500]
    return ''

def _qty(text):
    found=re.search(r'\b(\d{1,6})\s*(?:raciones?|unidades?|panes?|leches?|cajas?|fundas?|sillas?|mesas?|equipos?|art[ií]culos?)\b',text,re.I)
    return found.group(1) if found else ''

def _service(text):
    n=normalize(text)
    if 'leche' in n:return 'Leche'
    if re.search(r'\bpan(?:es)?\b',n):return 'Pan'
    return 'Almuerzo'

def _food(original,text,moment):
    stop=r'(?=\s*(?:,|;|\.|\b(?:suplidor|cantidad|lleg[oó]|llegaron|se\s+entreg[oó]|entregado\s+por|a\s+las|hora|raciones|observaci[oó]n|incidencia|pero)\b|$))'
    planned=_capture(original,rf'(?:el\s+)?men[uú]\s+(?:era|fue|es|planificado(?:\s+era)?|propuesto(?:\s+era)?)[\s:]+(.+?){stop}',rf'(?:almuerzo|comida)\s+(?:era|fue|de|:)[\s]*(.+?){stop}')
    delivered=_capture(original,r'(?:se\s+)?(?:entreg[oó]|recibi[oó]|lleg[oó]|llegaron)\s+(?:el\s+|la\s+|los\s+|las\s+)?(.+?)(?=\s*(?:,|;|\.|\b(?:el\s+men[uú]|men[uú]|suplidor|cantidad|a\s+las|hora|raciones|entregado\s+por|pero)\b|$))')
    planned=planned or delivered or _service(text)
    supplier=_capture(original,r'\bsuplidor(?:\s+fue|\s+es)?\s*[:,-]?\s*(.+?)(?=\s*(?:,|;|\.|\b(?:cantidad|a\s+las|hora|raciones|correspond|incidencia|observaci[oó]n|pero)\b|$))',r'\b(?:entregado|tra[ií]do)\s+por\s+(.+?)(?=\s*(?:,|;|\.|\b(?:cantidad|a\s+las|hora|raciones|correspond|pero)\b|$))')
    supplier=re.split(r'\s+y\s+(?:sí|si|no)?\s*correspond',supplier,flags=re.I)[0].strip()
    n=normalize(text)
    corresponds='No corresponde' if any(x in n for x in ('no correspondia','no corresponde','era diferente')) else 'Parcialmente' if any(x in n for x in ('parcialmente','incompleto','falto','faltaron')) else 'Sí, corresponde' if any(x in n for x in ('si correspondia','si corresponde','correspondia','coincidia','era lo mismo')) else 'Pendiente de verificar'
    differences=_capture(original,r'\b(?:diferencia|diferencias|falt[oó]|faltaron|pero)\s*[:,-]?\s*(.+?)(?=\s*(?:;|\.|\b(?:incidencia|observaci[oó]n)\b|$))')
    incidents=_capture(original,r'\b(?:incidencia|incidencias|problema|problemas)\s*[:,-]?\s*(.+?)(?=\s*(?:;|\.|\bobservaci[oó]n\b|$))')
    rejected=_capture(original,r'\b(\d{1,6})\s+(?:unidades?\s+)?rechazad[ao]s?\b') or '0'
    data={'fecha':_date(text,original,moment),'hora':_time(text,moment),'servicio':_service(text),'menu':'__assistant_menu__','suplidor':supplier,'cantidad':_qty(original),'rechazadas':rejected,'responsable':'','corresponde':corresponds,'diferencias':differences,'incidencias':incidents,'observaciones':('Entregado: '+delivered) if delivered and normalize(delivered)!=normalize(planned) else '','estado':'Registrado','_assistant_menu_label':planned}
    return {'action':'draft_record','target':'receipts','data':data,'planned_menu':planned,'message':'Preparé la recepción y el menú diario. Revise los datos antes de guardar.','confidence':'alta' if supplier and data['cantidad'] and data['hora'] else 'media'}

def _visit(original,text,moment):
    name=_capture(original,r'\b(?:visitante|persona)\s+(?:llamad[oa]\s+|de\s+nombre\s+)?(.+?)(?=\s*(?:,|;|\.|\b(?:de\s+la|del|para|vino|lleg[oó]|a\s+las|motivo)\b|$))',r'\bllamad[oa]\s+(.+?)(?=\s*(?:,|;|\.|\b(?:para|de\s+la|del|a\s+las)\b|$))')
    institution=_capture(original,r'\b(?:de|desde)\s+(?:la|el)?\s*((?:regional|distrito|inabie|minerd|ayuntamiento|instituci[oó]n|empresa|fundaci[oó]n)\b.+?)(?=\s*(?:,|;|\.|\b(?:para|a\s+las|llamad[oa])\b|$))')
    reason=_capture(original,r'\b(?:para|motivo(?:\s+fue|\s+es)?\s*[:,-]?)\s+(.+?)(?=\s*(?:,|;|\.|\b(?:a\s+las|recibid[oa]\s+por)\b|$))')
    return {'action':'draft_record','target':'visits','data':{'fecha':_date(text,original,moment),'hora_entrada':_time(text,moment),'hora_salida':'','nombre':name,'institucion':institution,'documento':'','motivo':reason,'recibido_por':'','observaciones':''},'message':'Preparé la visita. Complete cualquier dato que no estuviera en el mensaje.','confidence':'alta' if name and reason else 'media'}

def _delivery(original,text,moment):
    article=_capture(original,r'\b(?:entregaron|entreg[oó]|recibimos|recibi[oó]|llegaron|lleg[oó])\s+(?:\d{1,6}\s+)?(.+?)(?=\s*(?:,|;|\.|\b(?:entregado\s+por|lo\s+trajo|suplidor|a\s+las|para|destino|condici[oó]n)\b|$))')
    by=_capture(original,r'\b(?:entregado\s+por|lo\s+trajo|suplidor)\s+(.+?)(?=\s*(?:,|;|\.|\b(?:a\s+las|para|destino|condici[oó]n)\b|$))')
    n=normalize(article+' '+text)
    category='Mobiliario' if any(x in n for x in ('silla','mesa','escritorio','mueble')) else 'Equipos' if any(x in n for x in ('equipo','computadora','impresora','proyector')) else 'Limpieza' if any(x in n for x in ('limpieza','detergente','cloro','jabon')) else 'Materiales educativos' if any(x in n for x in ('libro','cuaderno','lapiz','material educativo')) else 'Otro'
    condition='Dañada' if any(x in n for x in ('danado','danada','roto','rota')) else 'Incompleta' if any(x in n for x in ('incompleto','incompleta','faltante')) else 'Excelente' if 'excelente' in n else 'Buena'
    return {'action':'draft_record','target':'deliveries','data':{'fecha':_date(text,original,moment),'hora':_time(text,moment),'categoria':category,'articulo':article,'cantidad':_qty(original),'unidad':'unidad','entregado_por':by,'recibido_por':'','destino':_capture(original,r'\b(?:para|destino)\s+(?:la|el)?\s*(.+?)(?=\s*(?:,|;|\.|\bcondici[oó]n\b|$))'),'condicion':condition,'observaciones':'','estado':'Recibido'},'message':'Preparé la entrega. Revísela y agregue evidencias si corresponde.','confidence':'alta' if article and _qty(original) else 'media'}

def _expense(original,text,moment):
    money=re.search(r'(?:RD\$|DOP|\$)?\s*([\d,.]+)\s*(?:pesos|dop)',original,re.I);amount=money.group(1).replace(',','') if money else ''
    concept=_capture(original,r'\b(?:gasto|pagu[eé]|compr[eé])\s+(?:de|por|en)?\s*(.+?)(?=\s*(?:,|;|\.|\b(?:por\s+RD\$|RD\$|DOP|\$|suplidor|factura)\b|$))')
    concept=re.split(r'\s+por\s+(?:RD\$|DOP|\$)',concept,flags=re.I)[0].strip()
    supplier=_capture(original,r'\b(?:suplidor|beneficiario|pagado\s+a|comprado\s+a)\s*[:,-]?\s*(.+?)(?=\s*(?:,|;|\.|\b(?:factura|por\s+RD\$|RD\$|DOP|\$)\b|$))')
    n=normalize(text);category='Mantenimiento' if 'mantenimiento' in n else 'Transporte' if any(x in n for x in ('transporte','gasolina','combustible')) else 'Alimentación' if any(x in n for x in ('comida','alimentacion')) else 'Servicios' if 'servicio' in n else 'Materiales' if any(x in n for x in ('material','compra')) else 'Otros'
    payment='Transferencia' if 'transferencia' in n else 'Cheque' if 'cheque' in n else 'Efectivo'
    data={'fecha':_date(text,original,moment),'concepto':concept,'categoria':category,'suplidor':supplier,'factura':_capture(original,r'\bfactura\s*(?:n(?:[úu]mero|o\.?))?\s*[:#-]?\s*([\w-]+)'),'monto':amount,'pago':payment,'referencia':'','estado':'Registrado','notas':''}
    return {'action':'draft_record','target':'expenses','data':data,'message':'Preparé el gasto. Revise el monto y el suplidor.','confidence':'alta' if concept and amount else 'media'}

def _reminder(original,text,moment):
    explicit=re.search(r'(20\d{2}-\d{1,2}-\d{1,2}|\d{1,2}/\d{1,2}/20\d{2})',original)
    title=(original[:explicit.start()] if explicit else original).strip(' ,.-')
    title=re.sub(r'(?i)^(recu[eé]rdame|crear\s+recordatorio|agendar|agenda|anota)\s+(que\s+)?','',title).strip()
    title=re.sub(r'(?i)\s+(hoy|mañana|pasado\s+mañana|el)$','',title).strip() or 'Recordatorio'
    n=normalize(title);category='Asamblea' if 'asamblea' in n else 'Reunión' if 'reunion' in n else 'Supervisión' if 'supervision' in n else 'Entrega' if 'entrega' in n else 'Actividad escolar' if 'actividad' in n else 'Otro'
    data={'titulo':title[:120],'fecha':_date(text,original,moment),'hora':_time(text,moment),'categoria':category,'prioridad':'Urgente' if 'urgente' in normalize(text) else 'Importante' if 'importante' in normalize(text) else 'Normal','responsable':'','detalle':'Creado desde Aula IA.','estado':'Pendiente'}
    return {'action':'draft_record','target':'reminders','data':data,'message':'Preparé el recordatorio.','confidence':'alta'}

def _simple(original,text,moment,target):
    when=_date(text,original,moment);n=normalize(text)
    if target=='facilities':
        area=_capture(original,r'\b(?:en|del|de\s+la|de\s+el)\s+((?:baño|aula|techo|cocina|patio|verja|direcci[oó]n|cancha|pasillo).+?)(?=\s*(?:,|;|\.|\b(?:hay|est[aá]|se\s+encuentra|requiere)\b|$))')
        return {'fecha':when,'area':area,'condicion':'Crítica' if 'critica' in n else 'Mala' if any(x in n for x in ('mala','danado','danada','roto','filtracion')) else 'Regular' if 'regular' in n else 'Buena','hallazgo':original,'accion':'','responsable':'','fecha_limite':'','estado':'Pendiente'}
    if target=='coaching':return {'fecha':when,'personal':'','tipo':'Observación de aula' if 'aula' in n else 'Seguimiento' if 'seguimiento' in n else 'Otro','fortalezas':_capture(original,r'\bfortalezas?\s*[:,-]?\s*(.+?)(?=\s*(?:;|\.|\bacuerdos?\b|\bresultados?\b|$))'),'resultados':_capture(original,r'\b(?:resultado|resultados|mejorar)\s*[:,-]?\s*(.+?)(?=\s*(?:;|\.|\bacuerdos?\b|$))'),'acuerdos':_capture(original,r'\bacuerdos?\s*[:,-]?\s*(.+?)(?=\s*(?:;|\.|\bseguimiento\b|$))'),'fecha_seguimiento':'','estado':'Abierto'}
    if target=='attendance':
        state='Ausente' if 'ausente' in n or 'no asistio' in n else 'Permiso' if 'permiso' in n else 'Licencia' if 'licencia' in n else 'Tardanza' if any(x in n for x in ('tarde','tardanza')) else 'Presente'
        return {'personal':'','fecha':when,'estado':state,'entrada':_time(text,moment),'salida':'','notas':original}
    if target=='students':return {'codigo':_capture(original,r'\bc[oó]digo\s*[:#-]?\s*([\w-]+)'),'nombre':_capture(original,r'\bestudiante\s+(?:llamad[oa]\s+|de\s+nombre\s+)?(.+?)(?=\s*(?:,|;|\.|\b(?:c[oó]digo|naci[oó]|fecha|grado|secci[oó]n)\b|$))'),'nacimiento':'','sexo':'No especificado','documento':'','nacionalidad':'','direccion':'','tutor':'','parentesco':'','telefono':'','emergencia':'','salud':'','apoyos':'','nivel':'','grado':'','seccion':'','fecha':when,'estado':'Activo','notas':'Creado desde Aula IA.'}
    if target=='staff':return {'codigo':_capture(original,r'\bc[oó]digo\s*[:#-]?\s*([\w-]+)'),'nombre':_capture(original,r'\bpersonal\s+(?:llamad[oa]\s+|de\s+nombre\s+)?(.+?)(?=\s*(?:,|;|\.|\b(?:c[oó]digo|c[eé]dula|cargo|ingres[oó])\b|$))'),'documento':'','cargo':_capture(original,r'\bcargo\s*[:,-]?\s*(.+?)(?=\s*(?:,|;|\.|$))'),'telefono':'','direccion':'','ingreso':when,'vinculo':'Fijo','salario':'','estado':'Activo','notas':'Creado desde Aula IA.'}
    return {}

def interpret(message,moment=None):
    original=' '.join(str(message).split());text=normalize(original)
    if not text:return {'action':'reply','message':'Escriba una instrucción. '+HELP}
    if any(x in text for x in ('que puedes hacer','como funcionas','ayuda','instructivo')):return {'action':'reply','message':HELP}
    if 'menu' in text and ('ciclo' in text or any(x in text for x in ('retir','borr','elimin'))):return {'action':'reply','message':'Un ciclo identifica la semana o período del menú. Pulse Eliminar; el historial y las evidencias se conservan.'}
    creating=any(word in text for word in CREATE)
    food=any(x in text for x in ('almuerzo','inabie','leche','pan','menu','comida','racion','suplidor')) and any(x in text for x in ('entrego','entregaron','recibio','recibimos','llego','llegaron','recepcion','menu era','menu fue'))
    if food:return _food(original,text,moment)
    if any(x in text for x in ('recuerdame','recordatorio','agendar','agenda')):return _reminder(original,text,moment)
    if creating and any(x in text for x in ('visita','visitante','vino de la regional','vino del distrito')):return _visit(original,text,moment)
    if creating and any(x in text for x in ('sillas','mesas','mobiliario','donacion','equipos','materiales','bien recibido')):return _delivery(original,text,moment)
    if creating and any(x in text for x in ('gasto','factura','pague','compre')):return _expense(original,text,moment)
    target=None
    if creating and any(x in text for x in ('planta fisica','inspeccion','filtracion','techo danado','bano danado')):target='facilities'
    elif creating and any(x in text for x in ('acompanamiento','acompane','observacion de aula')):target='coaching'
    elif creating and any(x in text for x in ('asistencia','ausente','tardanza','llego tarde','permiso','licencia')):target='attendance'
    elif creating and 'estudiante' in text:target='students'
    elif creating and any(x in text for x in ('personal llamado','personal de nombre','empleado','docente llamado')):target='staff'
    if target:return {'action':'draft_record','target':target,'data':_simple(original,text,moment,target),'message':'Preparé un borrador editable. Complete los campos obligatorios.','confidence':'media'}
    report=any(x in text for x in ('reporte','informe','pdf','excel'));target=next((module for word,module in NAVIGATION.items() if word in text),None)
    if report and target in ('students','staff','attendance','menus','receipts','expenses','facilities','visits','deliveries','reminders','coaching'):return {'action':'report','target':target,'format':'xlsx' if 'excel' in text else 'pdf'}
    if target:return {'action':'navigate','target':target,'message':'Módulo abierto. Puede crear, buscar, editar y generar informes.'}
    if any(x in text for x in ('guardar','imprimir','error','no funciona')):return {'action':'reply','message':'Genere el PDF y guárdelo en Escritorio o Documentos. Si macOS niega permiso, seleccione otra carpeta. Los errores quedan en errores.log.'}
    return {'action':'reply','message':'No reconocí la instrucción con suficiente seguridad y no modifiqué nada. '+HELP}

