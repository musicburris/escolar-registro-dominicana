"""Acceptance tests against the actual bundled neural model on Apple Silicon."""
import json,platform,time,socket
from datetime import datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from .bundled_ai import MODEL,stop
from .neural_assistant import propose
from .core import Store


def run():
    from PIL import Image,ImageDraw
    original=socket.socket.connect
    def local_only(self,address):
        if isinstance(address,tuple) and address[0] not in ('127.0.0.1','::1'):
            raise RuntimeError('La prueba prohíbe conexiones externas')
        return original(self,address)
    socket.socket.connect=local_only
    started=time.monotonic();checks=[];moment=datetime.fromisoformat('2026-10-16T11:30:00-04:00')
    try:
        result=propose('Hoy llegó el almuerzo a las 10:35. El menú planificado era arroz con pollo. Recibimos 27 raciones. Suplidor Comedor Escolar. No se rechazó ninguna. Recibido por Dirección. Sí corresponde con el plan.',MODEL,moment,['receipts','menus','visits'])
        assert result['target']=='receipts',result
        data=result['data']
        assert data.get('cantidad')=='27' and data.get('hora')=='10:35' and data.get('fecha')=='2026-10-16',result
        assert 'arroz' in result['planned_menu'].lower(),result
        data['rechazadas']=data.get('rechazadas') or '0';data['responsable']=data.get('responsable') or 'Dirección'
        with TemporaryDirectory() as tmp:
            store=Store(Path(tmp)/'data');store.bootstrap('director','Prueba-segura-2026','Dirección','Centro de validación');store.create_year('2026-2027','2026-08-01','2027-07-31')
            saved=store.save_assistant_food_entry(1,result['planned_menu'],data)
            assert store.record('receipts',1,saved['receipt_id'])['data']['cantidad']==27
            checks.append({'case':'Alimentación por lenguaje natural y persistencia','status':'ok','proposal':result})
            image=Image.new('RGB',(640,480),'white');draw=ImageDraw.Draw(image)
            draw.text((30,60),'EVIDENCIA DE ENTREGA: SILLAS',fill='black',font_size=30)
            draw.text((30,140),'CODIGO: EVD347',fill='black',font_size=36)
            image_path=Path(tmp)/'evidencia.jpg';image.save(image_path)
            visit=propose('Hoy llegó una visita llamada María Pérez de la Regional 02, a las 09:15, para supervisar el centro. Recibida por Dirección.',MODEL,moment,['visits'])
            assert visit['target']=='visits' and 'María' in visit['data'].get('nombre',''),visit
            assert visit['data'].get('hora_entrada')=='09:15',visit
            rid=store.save_record('visits',1,visit['data']);store.attach('visits',1,rid,image_path)
            assert len(store.attachments('visits',1,rid))==1
            checks.append({'case':'Visita por lenguaje natural con adjunto','status':'ok','proposal':visit})
            delivery=propose('Registra esta entrega hoy a las 09:30: 20 sillas entregadas por Muebles del Sur, recibidas por Dirección, para las aulas. Condición Buena. Incluye en observaciones el código de evidencia impreso en la foto.',MODEL,moment,['deliveries'],[image_path])
            assert delivery['target']=='deliveries' and delivery['data'].get('cantidad')=='20',delivery
            assert 'silla' in delivery['data'].get('articulo','').lower(),delivery
            assert 'EVD347' in delivery['data'].get('observaciones','').upper(),delivery
            checks.append({'case':'Modelo multimodal con fotografía','status':'ok','proposal':delivery})
            store.close()
        return {'status':'ok','architecture':platform.machine(),'model':MODEL,'seconds':round(time.monotonic()-started,2),'checks':checks}
    finally:
        socket.socket.connect=original;stop()
