# Resultado de verificación

Entrega: AulaLocal 0.9.1. Suite actual: **56 pruebas automatizadas**. El proceso de construcción Mac vuelve a ejecutar la suite completa y guarda `tests-macos.xml`.

## Cobertura automatizada

| Área | Comprobación |
|---|---|
| Persistencia | Datos y configuración sobreviven al cierre y reapertura |
| Actualización | Migración desde esquemas anteriores a 3 conserva estudiante y adjunto y normaliza el grado |
| Estructura académica | Niveles, grados, rangos y secciones válidas por año |
| Edad | Cálculo dinámico por fecha de nacimiento/día actual, cambio al cumplir años, edad al inicio del ciclo y rango configurado |
| Importación | Excel masivo de estudiantes, plantilla de personal y operación atómica |
| Ponchador | Excel tabular y matricial, agrupación de marcaciones, tardanza, actualización sin duplicados y filas no identificadas |
| Años | Aislamiento, copia explícita, congelación, archivo y reapertura controlada |
| Acceso | Hash de contraseña, cinco fallos, token persistente, cierre explícito y recuperación rotativa |
| Roles | Restricciones de Secretaría, Alimentación, Contabilidad y Consulta |
| Planta y visitas | Validación y persistencia de ambos módulos |
| Alimentación | Plan por fecha de lunes a viernes, evidencia dentro del día, actualización sin duplicados, comparación con recepción, diferencias, PDF/Excel, cantidades, rechazos e indicadores |
| Eliminación | Ocultación recuperable, conservación de dependencias y adjuntos, restauración y auditoría |
| Gestión ampliada | Entregas generales, recordatorios, acompañamiento y tipos de alimentación configurables |
| Asistente local | Interpretación privada de navegación, reportes y recordatorios con confirmación |
| Gastos | Decimales exactos, valores inválidos y totales |
| Adjuntos | Selección múltiple, miniatura y previsualización, fotos, video MOV/MP4/M4V, detección de duplicados, PDF/ofimática, huella, tamaño y bloqueo histórico |
| Informe INABIE | Evidencias vinculadas al menú y la recepción, agrupadas por semana y fecha exacta, con fotos y listado de videos |
| Reportes | PDF, Excel, resumen de asistencia por persona/período, certificaciones, búsqueda y texto que no se ejecuta como fórmula |
| Respaldo | Cifrado, manipulación/contraseña errónea, recuperación y copia previa |
| Auditoría | Antes/después, zona horaria de presentación e inmutabilidad |
| Interfaz | Construcción de pantallas/formularios, navegación, tarjetas interactivas, filtros y reingreso |
| Tablas | Orden alfabético/numérico/fecha, selección correcta después de ordenar y columnas movibles/redimensionables |
| Personalización | Escala, tema, columnas, widgets y preferencias separadas por cuenta |
| Diagnóstico | Integridad SQLite, relaciones, escritura, espacio, equipo, reloj y privacidad |
| Offline | La auto-validación bloquea sockets mientras genera datos, PDF, Excel y respaldo |

## Validación del paquete

`scripts/build_macos.sh` exige un Mac ARM64, ejecuta pruebas, construye `AulaLocal.app`, confirma arquitectura con `lipo`, verifica la firma, ejecuta `--self-test` desde el bundle y crea DMG/PKG con hashes SHA-256. La evidencia del build queda en `docs/evidencias/validacion-m1.json` y `tests-macos.xml`.

Una firma Developer ID y notarización real solo son posibles con certificados y credenciales del propietario inscrito en Apple Developer Program. Cuando no están disponibles, el paquete queda firmado localmente y macOS puede mostrar el aviso de desarrollador no identificado.

## Aceptación manual recomendada

Antes de usar datos reales, conviene instalar en un usuario limpio, importar una hoja propia, abrir PDF/Excel en Vista Previa y Numbers/Excel, crear y restaurar un respaldo y comprobar el flujo de recuperación. La lista detallada está en `ACEPTACION_MAC.md`.
