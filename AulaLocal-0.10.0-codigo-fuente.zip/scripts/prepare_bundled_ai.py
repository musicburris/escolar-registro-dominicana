"""Build-time download only. End users never download or configure models."""
import hashlib,json,os,subprocess,time,urllib.request,http.client,socket,shutil
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
AI=ROOT/'build-assets'/'ai'
AI.mkdir(parents=True,exist_ok=True)
RUNTIME=AI/'runtime';RUNTIME.mkdir(exist_ok=True)
VERSION='v0.40.5'
ARCHIVE_SHA='75f9907dafa2fd4c61b5967de2ebb81ccc17eb28da9172edbad0dbc717474dcf'
archive=ROOT/'build-assets'/'ollama-darwin.tgz'
url=f'https://github.com/ollama/ollama/releases/download/{VERSION}/ollama-darwin.tgz'
if not archive.exists():urllib.request.urlretrieve(url,archive)
assert hashlib.sha256(archive.read_bytes()).hexdigest()==ARCHIVE_SHA
subprocess.run(['tar','-xzf',str(archive),'-C',str(RUNTIME)],check=True)
# Only ARM64 code is distributed, including helper executables and libraries.
for path in RUNTIME.rglob('*'):
 if not path.is_file() or path.is_symlink():continue
 result=subprocess.run(['lipo','-archs',str(path)],capture_output=True,text=True)
 if result.returncode==0:
  archs=result.stdout.split()
  if 'arm64' not in archs:
   if path.suffix in ('.so','.dylib'):path.unlink();continue
   raise RuntimeError(f'Componente incompatible: {path}')
  if len(archs)>1:
   temporary=path.with_name(path.name+'.arm64')
   subprocess.run(['lipo',str(path),'-thin','arm64','-output',str(temporary)],check=True)
   temporary.chmod(path.stat().st_mode);temporary.replace(path)
  subprocess.run(['codesign','--force','--sign','-',str(path)],check=True)
# Remove links to Intel-only libraries removed above; dangling links invalidate macOS signing.
for path in RUNTIME.rglob('*'):
 if path.is_symlink() and not path.exists():path.unlink()
models=AI/'models';models.mkdir(exist_ok=True)
with socket.socket() as probe:probe.bind(('127.0.0.1',0));port=probe.getsockname()[1]
env=os.environ.copy();env.update(OLLAMA_HOST=f'127.0.0.1:{port}',OLLAMA_MODELS=str(models),OLLAMA_NO_CLOUD='1',OLLAMA_NOPRUNE='1')
with (ROOT/'build-assets'/'ollama-download.log').open('w') as log:
 process=subprocess.Popen([str(RUNTIME/'ollama'),'serve'],env=env,cwd=str(RUNTIME),stdout=log,stderr=log)
 try:
  for _ in range(100):
   try:
    with socket.create_connection(('127.0.0.1',port),.5):break
   except OSError:time.sleep(.2)
  subprocess.run([str(RUNTIME/'ollama'),'pull','qwen3.5:4b'],env=env,check=True,timeout=1800)
 finally:process.terminate();process.wait(timeout=20)
license_dir=AI/'licenses';license_dir.mkdir(exist_ok=True)
for name,url in [('Ollama-MIT.txt','https://raw.githubusercontent.com/ollama/ollama/v0.40.5/LICENSE'),('Qwen-Apache-2.0.txt','https://huggingface.co/Qwen/Qwen3.5-4B/raw/main/LICENSE')]:
 urllib.request.urlretrieve(url,license_dir/name)
manifest={'engine':VERSION,'model':'qwen3.5:4b','files':[]}
for path in sorted(AI.rglob('*')):
 if not path.is_file() or path.name=='manifest.json':continue
 digest=hashlib.sha256()
 with path.open('rb') as f:
  for part in iter(lambda:f.read(8*1024*1024),b''):digest.update(part)
 manifest['files'].append({'path':str(path.relative_to(AI)),'size':path.stat().st_size,'sha256':digest.hexdigest()})
(AI/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Motor y modelo ARM64 incluidos y verificados.',flush=True)
