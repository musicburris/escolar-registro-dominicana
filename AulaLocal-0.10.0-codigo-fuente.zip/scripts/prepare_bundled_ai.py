"""Download pinned ARM64 engine and verified model during build, never at user startup."""
import hashlib,json,subprocess,urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parent.parent
AI=ROOT/'build-assets'/'ai';AI.mkdir(parents=True,exist_ok=True)
RUNTIME=AI/'runtime';RUNTIME.mkdir(exist_ok=True)
VERSION='b11709'
REVISION='e87f176479d0855a907a41277aca2f8ee7a09523'

def sha(path):
 digest=hashlib.sha256()
 with path.open('rb') as source:
  for part in iter(lambda:source.read(8*1024*1024),b''):digest.update(part)
 return digest.hexdigest()

def download(url,path,expected):
 if path.exists() and sha(path)==expected:return
 print('Descargando '+path.name,flush=True)
 request=urllib.request.Request(url,headers={'User-Agent':'AulaLocal-build/0.10.0'})
 with urllib.request.urlopen(request,timeout=120) as response,path.open('wb') as target:
  while block:=response.read(8*1024*1024):target.write(block)
 if sha(path)!=expected:raise RuntimeError('Integridad incorrecta: '+path.name)

archive=ROOT/'build-assets'/'llama-arm64.tar.gz'
download(f'https://github.com/ggml-org/llama.cpp/releases/download/{VERSION}/llama-{VERSION}-bin-macos-arm64.tar.gz',archive,'d53becb535c45791eaa6fea9598ad4635765db13d6b65320371273e11a5e00ba')
subprocess.run(['tar','-xzf',str(archive),'--strip-components','1','-C',str(RUNTIME)],check=True)
# Preserve shared libraries and shaders; ship only the inference executable.
for path in RUNTIME.iterdir():
 if path.is_file() and not path.is_symlink() and path.name.startswith(('llama-','ggml-')) and path.name!='llama-server':path.unlink()
for path in RUNTIME.iterdir():
 if path.is_symlink() and not path.exists():path.unlink()
for path in RUNTIME.rglob('*'):
 if not path.is_file() or path.is_symlink():continue
 result=subprocess.run(['lipo','-archs',str(path)],capture_output=True,text=True)
 if result.returncode==0:
  assert result.stdout.split()==['arm64'],f'Arquitectura no permitida: {path}'
  subprocess.run(['codesign','--force','--sign','-',str(path)],check=True)
models=AI/'models';models.mkdir(exist_ok=True)
base=f'https://huggingface.co/unsloth/Qwen3.5-4B-GGUF/resolve/{REVISION}/'
download(base+'Qwen3.5-4B-Q4_K_M.gguf',models/'voice-assistant.gguf','00fe7986ff5f6b463e62455821146049db6f9313603938a70800d1fb69ef11a4')
download(base+'mmproj-F16.gguf',models/'vision.gguf','cd88edcf8d031894960bb0c9c5b9b7e1fea6ebee02b9f7ce925a00d12891f864')
licenses=AI/'licenses';licenses.mkdir(exist_ok=True)
for name,url in [('llama.cpp-MIT.txt',f'https://raw.githubusercontent.com/ggml-org/llama.cpp/{VERSION}/LICENSE'),('Qwen-Apache-2.0.txt','https://huggingface.co/Qwen/Qwen3.5-4B/raw/main/LICENSE')]:
 with urllib.request.urlopen(url,timeout=60) as response:(licenses/name).write_bytes(response.read())
manifest={'engine':'llama.cpp '+VERSION,'model':'Qwen3.5-4B Q4_K_M','model_revision':REVISION,'model_source':'unsloth/Qwen3.5-4B-GGUF','files':[]}
for path in sorted(AI.rglob('*')):
 if path.is_file() and path.name!='manifest.json':manifest['files'].append({'path':str(path.relative_to(AI)),'size':path.stat().st_size,'sha256':sha(path)})
(AI/'manifest.json').write_text(json.dumps(manifest,indent=2))
print('Motor ARM64 y modelo incluidos con SHA-256 verificados.',flush=True)
