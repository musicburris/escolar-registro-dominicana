import errno,io,zipfile,socket
from pathlib import Path
import pytest
from openpyxl import load_workbook
from pypdf import PdfReader
from aulalocal.core import AppError
from aulalocal.backup import create_backup,restore_backup,atomic_write
from aulalocal import reports
from conftest import PASSWORD,student,staff,expense,receipt

def test_backup_round_trip_with_attachments(store,tmp_path):
    rid=store.save_record('students',1,student());pdf=tmp_path/'expediente.pdf';reports.record_pdf(store,'students',1,rid,pdf);aid=store.attach('students',1,rid,pdf)
    backup=tmp_path/'copia.aulabackup';create_backup(store,backup,PASSWORD)
    assert not backup.read_bytes().startswith(b'SQLite')
    assert b'Mar' not in backup.read_bytes()[:32]
    store.save_record('students',1,student('E002'))
    recovery=restore_backup(store,backup,PASSWORD,PASSWORD)
    assert recovery.exists() and store.user is None
    store.login('director',PASSWORD);assert len(store.list_records('students',1))==1
    assert store.attachment_bytes('students',1,rid,aid)==pdf.read_bytes()

def test_wrong_password_and_tamper_leave_current_data(store,tmp_path):
    store.save_record('students',1,student());backup=tmp_path/'copia.aulabackup';create_backup(store,backup,PASSWORD)
    with pytest.raises(AppError):restore_backup(store,backup,'contraseña-falsa',PASSWORD)
    raw=bytearray(backup.read_bytes());raw[-1]^=1;backup.write_bytes(raw)
    with pytest.raises(AppError):restore_backup(store,backup,PASSWORD,PASSWORD)
    assert len(store.list_records('students',1))==1

def test_backup_permission(store,tmp_path):
    store.save_user('lector','Lector','consulta',PASSWORD);store.login('lector',PASSWORD)
    with pytest.raises(AppError):create_backup(store,tmp_path/'copy',PASSWORD)

def test_read_only_destination_has_clear_message(tmp_path,monkeypatch):
    from aulalocal import backup
    def read_only(*args,**kwargs):raise OSError(errno.EROFS,'Read-only file system')
    monkeypatch.setattr(backup.tempfile,'mkstemp',read_only)
    with pytest.raises(AppError,match='solo lectura'):atomic_write(tmp_path/'reporte.pdf',b'PDF')

def test_pdf_xlsx_and_formula_injection_offline(store,tmp_path,monkeypatch):
    def no_network(*a,**kw):raise AssertionError('La aplicación intentó usar internet')
    monkeypatch.setattr(socket,'socket',no_network)
    rid=store.save_record('students',1,student(name='=HYPERLINK("https://ejemplo.test")'))
    path=tmp_path/'reporte.xlsx';reports.report_xlsx(store,'students',1,path)
    wb=load_workbook(path);assert wb.active['B4'].data_type=='s';assert wb.active['B4'].value.startswith('=HYPERLINK')
    pdf=tmp_path/'reporte.pdf';reports.report_pdf(store,'students',1,pdf)
    assert len(PdfReader(pdf).pages)>=1 and '2026-2027' in PdfReader(pdf).pages[0].extract_text()
    letter=tmp_path/'constancia.pdf';reports.letter_pdf(store,'students',1,rid,letter)
    assert 'CERTIFICACI' in PdfReader(letter).pages[0].extract_text()

def test_excel_money_and_filter(store,tmp_path):
    store.save_record('expenses',1,expense('10.25'));store.save_record('expenses',1,{**expense('99.00'),'concepto':'Otro'})
    path=tmp_path/'gastos.xlsx';reports.report_xlsx(store,'expenses',1,path,'Materiales de prueba')
    ws=load_workbook(path).active
    assert ws.max_row==4;assert ws['F4'].value==10.25;assert ws['F4'].data_type=='n'

def test_frozen_institution_preserved(store,tmp_path):
    store.save_record('students',1,student());store.transition(1,'congelado','Cierre autorizado del año',PASSWORD)
    store.save_settings({'centro':'Nombre nuevo','director':'Director nuevo'})
    assert reports.institution(store,1)['centro']=='Centro de prueba'

def test_year_archive_contains_only_selected_year(store,tmp_path):
    store.save_record('students',1,student());y=store.create_year('2027-2028','2027-08-01','2028-07-31');store.copy_people(1,y,'students')
    z=tmp_path/'año.zip';reports.export_year(store,1,z)
    with zipfile.ZipFile(z) as archive:
        assert 'students.xlsx' in archive.namelist()
        assert '2027-2028' not in archive.read('año.json').decode()
        assert '2027-08-01' not in archive.read('students.json').decode()

def test_long_text_pdf_paginates(store,tmp_path):
    d=expense();d['concepto']='Observación extensa. '*400;store.save_record('expenses',1,d)
    path=tmp_path/'largo.pdf';reports.report_pdf(store,'expenses',1,path)
    assert len(PdfReader(path).pages)>1

def test_export_cannot_overwrite_active_database(store):
    store.save_record('students',1,student())
    with pytest.raises(AppError):reports.report_pdf(store,'students',1,store.path)
    assert len(store.list_records('students',1))==1

def test_inabie_comparison_is_printed_in_pdf_and_excel(store,tmp_path):
    store.save_weekly_lunch_plan(1,'2026-09-07',[{'dia':'Lunes','descripcion':'Arroz con pollo y ensalada','raciones_previstas':'120'}])
    mid=store.weekly_lunch_plan(1,'2026-09-07')[0]['id'];data=receipt(mid);data.update(fecha='2026-09-07',corresponde='Parcialmente',diferencias='Faltó la ensalada')
    store.save_record('receipts',1,data)
    pdf=tmp_path/'control-inabie.pdf';xlsx=tmp_path/'control-inabie.xlsx';reports.report_pdf(store,'receipts',1,pdf);reports.report_xlsx(store,'receipts',1,xlsx)
    text=' '.join(' '.join(page.extract_text().split()) for page in PdfReader(pdf).pages)
    assert 'Arroz con pollo y ensalada' in text and 'Faltó la ensalada' in text
    ws=load_workbook(xlsx).active
    assert ws['D4'].value=='Arroz con pollo y ensalada' and ws['E4'].value=='Parcialmente'

def test_lunch_evidence_report_is_grouped_by_week_and_day(store,tmp_path):
    from PIL import Image
    store.save_weekly_lunch_plan(1,'2026-09-07',[{'dia':'Viernes','descripcion':'Arroz, pollo y ensalada','raciones_previstas':'90'}])
    planned=store.weekly_lunch_plan(1,'2026-09-07')[0];photo=tmp_path/'evidencia-viernes.jpg';Image.new('RGB',(160,90),'orange').save(photo);store.attach('menus',1,planned['id'],photo)
    data=receipt(planned['id']);data.update(fecha='2026-09-11',cantidad='90',rechazadas='0',suplidor='Suplidor semanal');store.save_record('receipts',1,data)
    pdf=tmp_path/'informe-con-evidencias.pdf';reports.report_pdf(store,'receipts',1,pdf,include_photos=True)
    text=' '.join(' '.join(page.extract_text().split()) for page in PdfReader(pdf).pages)
    assert 'Semana del 07/09/2026 al 11/09/2026' in text
    assert 'Viernes 11/09/2026' in text and 'evidencia-viernes.jpg' in text and 'Día planificado' in text
