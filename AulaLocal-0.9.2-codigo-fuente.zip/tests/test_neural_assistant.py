from datetime import datetime
import pytest
from aulalocal.assistant import interpret
from aulalocal.neural_assistant import validate_proposal, propose
from aulalocal.core import AppError
from conftest import receipt


def test_local_food_and_visits_are_drafts():
    moment=datetime(2026,10,16,12,30)
    result=interpret('Hoy llegó el almuerzo a las 10:35, el menú era arroz con pollo, 85 raciones, suplidor Comedor Escolar y sí correspondía.',moment)
    assert result['action']=='draft_record'
    assert result['data']['suplidor']=='Comedor Escolar'
    assert result['data']['cantidad']=='85'
    assert result['data']['fecha']=='2026-10-16'
    visit=interpret('Hoy llegó una visita llamada María Pérez de la Regional 02 para supervisar el centro a las 9:15.',moment)
    assert visit['target']=='visits' and visit['data']['nombre']=='María Pérez'


def test_neural_output_cannot_choose_arbitrary_operation_or_field():
    for proposal in [
        {'action':'delete','target':'students','data':{}},
        {'action':'draft_record','target':'expenses','data':{}},
        {'action':'draft_record','target':'visits','data':{'sql':'DROP TABLE records'}},
        {'action':'draft_record','target':'visits','data':{'nombre':{'nested':'value'}}},
    ]:
        with pytest.raises(AppError):validate_proposal(proposal,['visits'])


def test_neural_references_are_never_trusted():
    result=validate_proposal({'action':'draft_record','target':'attendance','data':{'personal':12345}},['attendance'])
    assert result['data']['personal']==''


def test_neural_engine_uses_schema_and_rejects_remote_model(monkeypatch):
    from aulalocal import neural_assistant as neural
    calls=[]
    def fake(path,payload=None,timeout=120):
        calls.append((path,payload))
        if path=='/api/tags':return {'models':[{'name':'test-local','size':1000}]}
        if path=='/api/show':return {}
        return {'message':{'content':'{"action":"draft_record","target":"visits","data":{"nombre":"María"}}'}}
    monkeypatch.setattr(neural,'request',fake)
    result=propose('Llegó María','test-local',datetime(2026,10,16),['visits'])
    assert result['data']['nombre']=='María'
    assert calls[-1][1]['format']['type']=='object'
    def remote(path,payload=None,timeout=120):
        if path=='/api/tags':return {'models':[{'name':'test-local','size':1000}]}
        return {'remote_host':'cloud.example'}
    monkeypatch.setattr(neural,'request',remote)
    with pytest.raises(AppError):propose('Llegó María','test-local',datetime(2026,10,16),['visits'])


def test_assistant_food_rollback_and_preservation(store):
    data=receipt('placeholder');data['fecha']='2026-10-16';data['cantidad']='0'
    with pytest.raises(AppError):store.save_assistant_food_entry(1,'Arroz con pollo',data)
    assert store.list_records('menus',1)==[]
    data['cantidad']='27'
    result=store.save_assistant_food_entry(1,'Arroz con pollo',data)
    before=store.record('menus',1,result['menu_id'])
    with pytest.raises(AppError):store.save_assistant_food_entry(1,'Otro menú',data)
    assert store.record('menus',1,result['menu_id'])==before
    assert len(store.list_records('receipts',1))==1


def test_assistant_dialog_cancel_does_not_write(store,monkeypatch):
    from PySide6.QtWidgets import QApplication,QDialog,QLineEdit,QPushButton
    from aulalocal.ui import MainWindow,Form
    app=QApplication.instance() or QApplication([])
    window=MainWindow(store);window.show();window.nav.setCurrentRow(window.keys.index('assistant'));app.processEvents()
    monkeypatch.setattr(Form,'exec',lambda self:QDialog.Rejected)
    window.findChild(QLineEdit,'assistantEntry').setText('Hoy llegó una visita llamada María para supervisar a las 09:00')
    next(b for b in window.findChildren(QPushButton) if b.text()=='Entender y preparar' and b.isVisible()).click()
    assert store.list_records('visits',1)==[]
    window.timer.stop();window.close()
