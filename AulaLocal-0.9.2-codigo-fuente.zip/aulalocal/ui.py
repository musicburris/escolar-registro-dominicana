import json, re, sys, time, traceback, secrets, unicodedata
from datetime import date, datetime
from pathlib import Path
from PySide6.QtCore import Qt, QTimer, QLockFile, QEvent, QUrl, QDate, QTime, QStandardPaths, Signal, QSize, QThread
from PySide6.QtGui import QDesktopServices, QAction, QFont, QKeySequence, QPixmap, QIcon
from PySide6.QtWidgets import (QApplication,QMainWindow,QWidget,QVBoxLayout,QHBoxLayout,QGridLayout,QLabel,QPushButton,QLineEdit,QTextEdit,QComboBox,QTableWidget,QTableWidgetItem,QHeaderView,QAbstractItemView,QDialog,QDialogButtonBox,QFormLayout,QScrollArea,QMessageBox,QFileDialog,QInputDialog,QListWidget,QListWidgetItem,QFrame,QCheckBox,QGroupBox,QDateEdit,QTimeEdit,QSpinBox,QTabWidget)
from .core import Store,AppError,app_directory,local_now,timezone_label
from .catalog import MODULES,ACCESS,ROLES
from . import reports
from .backup import create_backup,restore_backup,atomic_write
from .assistant import interpret
from shiboken6 import isValid

THEMES={
 'ocean':dict(bg='#F4F7FA',surface='#FFFFFF',text='#092D3A',muted='#456672',accent='#007F8D',accent2='#006B77',side='#0B3342',sidehover='#174B5B',line='#CFDEE5',soft='#E7F3F5'),
 'indigo':dict(bg='#F6F6FB',surface='#FFFFFF',text='#1D2446',muted='#535D7D',accent='#4F5BD5',accent2='#3E48B5',side='#24294A',sidehover='#363D6B',line='#D7DAE8',soft='#ECEEFC'),
 'emerald':dict(bg='#F4F8F6',surface='#FFFFFF',text='#143A30',muted='#4D6C63',accent='#16866D',accent2='#0F6D59',side='#153D35',sidehover='#24594D',line='#D3E2DD',soft='#E5F3EF'),
 'graphite':dict(bg='#F3F4F6',surface='#FFFFFF',text='#20262D',muted='#555F69',accent='#55616E',accent2='#3F4953',side='#252B31',sidehover='#3A424A',line='#D6DBDF',soft='#ECEFF1'),
 'high_contrast':dict(bg='#FFFFFF',surface='#FFFFFF',text='#000000',muted='#202020',accent='#005FCC',accent2='#004A9F',side='#000000',sidehover='#252525',line='#606060',soft='#E7F1FF')}
SCALES={'compact':12,'comfortable':15,'large':17,'extra_large':20}

def build_style(theme='ocean',scale='comfortable'):
    c=THEMES.get(theme,THEMES['ocean']);base=SCALES.get(scale,15);small=max(12,base-1);brand=base+12;title=base+20
    return '''
QMainWindow,QDialog {background:%(bg)s;color:%(text)s;}
QWidget {font-size:%(base)dpx;font-family:-apple-system,BlinkMacSystemFont,"SF Pro Text";color:%(text)s;}
QScrollArea {border:0;background:transparent;}
QLabel#brand {font-size:%(brand)dpx;font-weight:750;color:%(text)s;letter-spacing:.2px;}
QLabel#title {font-size:%(title)dpx;font-weight:780;color:%(text)s;}
QLabel#muted {color:%(muted)s;font-size:%(small)dpx;}
QLabel#metricLabel {color:%(muted)s;font-size:%(base)dpx;font-weight:620;}
QLabel#clock {color:%(muted)s;font-size:%(small)dpx;font-weight:650;}
QLabel#eyebrow {color:%(accent)s;font-size:%(small)dpx;font-weight:780;letter-spacing:1px;}
QFrame#card,QGroupBox {background:%(surface)s;border:1px solid %(line)s;border-radius:16px;margin-top:7px;}
QFrame#metric {background:%(surface)s;border:1px solid %(line)s;border-left:5px solid %(accent)s;border-radius:16px;}
QFrame#metric:hover {background:%(soft)s;border-color:%(accent)s;}
QLabel#metricLink {color:%(accent)s;font-size:%(small)dpx;font-weight:720;}
QGroupBox::title {subcontrol-origin:margin;left:16px;padding:0 6px;color:%(muted)s;font-weight:700;}
QPushButton {background:%(surface)s;border:1px solid %(line)s;border-radius:10px;padding:10px 15px;color:%(text)s;font-weight:650;}
QPushButton:hover {background:%(soft)s;border-color:%(accent)s;}
QPushButton:pressed {background:%(soft)s;}
QPushButton#primary {background:%(accent)s;color:white;border:1px solid %(accent)s;font-weight:740;}
QPushButton#primary:hover {background:%(accent2)s;}
QPushButton#danger {background:#FFF7F7;color:#922F3A;border:1px solid #DDAEB4;}
QPushButton#danger:hover {background:#FDEBED;border-color:#B95662;}
QPushButton:disabled {color:#7B858C;background:#E9EDEF;border-color:#D6DDE0;}
QLineEdit,QTextEdit,QComboBox,QDateEdit,QTimeEdit,QSpinBox {background:%(surface)s;border:1px solid %(line)s;border-radius:9px;padding:9px;color:%(text)s;selection-background-color:%(accent)s;}
QLineEdit:focus,QTextEdit:focus,QComboBox:focus,QDateEdit:focus,QTimeEdit:focus,QSpinBox:focus {border:2px solid %(accent)s;}
QListWidget {background:%(side)s;color:#F5FAFC;border:0;border-radius:18px;padding:10px;outline:0;}
QListWidget::item {padding:13px 12px;border-radius:9px;margin:2px 0;color:#F5FAFC;}
QListWidget::item:hover {background:%(sidehover)s;}
QListWidget::item:selected {background:%(accent)s;color:white;font-weight:720;}
QTableWidget {background:%(surface)s;alternate-background-color:%(bg)s;border:1px solid %(line)s;border-radius:12px;gridline-color:%(line)s;selection-background-color:%(soft)s;selection-color:%(text)s;}
QHeaderView::section {background:%(soft)s;color:%(text)s;padding:12px;border:0;border-right:1px solid %(line)s;font-weight:700;}
QStatusBar {background:%(surface)s;border-top:1px solid %(line)s;color:%(muted)s;}
QToolTip {background:%(side)s;color:white;border:0;padding:6px;}
''' % {**c,'base':base,'small':small,'brand':brand,'title':title}

STYLE=build_style()

def apply_appearance(store=None):
    pref=store.appearance() if store and store.user else {'ui_theme':'ocean','ui_scale':'comfortable'}
    app=QApplication.instance()
    if app:
        app.setStyleSheet(build_style(pref['ui_theme'],pref['ui_scale']))
        app.setFont(QFont('.AppleSystemUIFont',SCALES.get(pref['ui_scale'],15)))
    return pref

def label(text,name=None):
    w=QLabel(text); w.setTextFormat(Qt.PlainText); w.setWordWrap(True)
    if name: w.setObjectName(name)
    return w

def button(text,fn,primary=False,role=None):
    b=QPushButton(text); b.clicked.connect(fn)
    if role:b.setObjectName(role)
    elif primary:b.setObjectName('primary')
    return b

def clear_layout(layout):
    while layout.count():
        item=layout.takeAt(0)
        if item.widget():
            item.widget().blockSignals(True); item.widget().hide(); item.widget().deleteLater()
        elif item.layout(): clear_layout(item.layout())

def save_dialog(parent,title,filename,file_filter):
    """Abre siempre en una carpeta escribible, nunca dentro del DMG montado."""
    folder=QStandardPaths.writableLocation(QStandardPaths.DocumentsLocation)
    if not folder:folder=QStandardPaths.writableLocation(QStandardPaths.DownloadLocation)
    if not folder:folder=str(Path.home())
    return QFileDialog.getSaveFileName(parent,title,str(Path(folder)/filename),file_filter)[0]

def error(parent,e): QMessageBox.warning(parent,'No se pudo completar',str(e))

def ask_password(parent,prompt):
    text,ok=QInputDialog.getText(parent,'Confirmación',prompt,QLineEdit.Password)
    return text if ok else None

def table_widget(headers,rows):
    t=QTableWidget(len(rows),len(headers)); t.setHorizontalHeaderLabels(headers)
    for i,row in enumerate(rows):
        for j,value in enumerate(row):
            item=SmartTableItem(value); item.setToolTip(str(value)); t.setItem(i,j,item)
    t.setSelectionBehavior(QAbstractItemView.SelectRows); t.setSelectionMode(QAbstractItemView.SingleSelection)
    t.setEditTriggers(QAbstractItemView.NoEditTriggers); t.setAlternatingRowColors(True); t.verticalHeader().setVisible(False)
    header=t.horizontalHeader();header.setSectionsMovable(True);header.setSectionResizeMode(QHeaderView.Interactive);header.setStretchLastSection(False);header.setMinimumSectionSize(70);header.setSortIndicatorShown(True)
    header.sectionDoubleClicked.connect(lambda section:t.resizeColumnToContents(section))
    t.resizeColumnsToContents()
    for column in range(t.columnCount()):t.setColumnWidth(column,min(max(t.columnWidth(column),100),420))
    t.setHorizontalScrollMode(QAbstractItemView.ScrollPerPixel)
    t.verticalHeader().setDefaultSectionSize(40)
    t.setSortingEnabled(True);t.setToolTip('Pulse un encabezado para ordenar. Arrástrelo para cambiar su posición. Arrastre sus bordes para cambiar el ancho; doble clic ajusta automáticamente.')
    return t

class SmartTableItem(QTableWidgetItem):
    """Ordena números, fechas y texto con acentos sin alterar lo mostrado."""
    def __init__(self,value):
        super().__init__(str(value));self.sort_value=self._key(value)
    @staticmethod
    def _key(value):
        text=str(value).strip()
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}',text):return (0,text)
        if re.fullmatch(r'\d{2}/\d{2}/\d{4}',text):
            day,month,year=text.split('/');return (0,f'{year}-{month}-{day}')
        number=text.replace(',','').replace('RD$','').strip()
        if re.fullmatch(r'-?\d+(?:\.\d+)?',number):return (1,float(number))
        normalized=unicodedata.normalize('NFKD',text).encode('ascii','ignore').decode().casefold()
        return (2,normalized)
    def __lt__(self,other):
        return self.sort_value<(other.sort_value if isinstance(other,SmartTableItem) else self._key(other.text()))

class MetricCard(QFrame):
    clicked=Signal()
    def __init__(self,key,parent=None):
        super().__init__(parent);self.metric_key=key;self.setObjectName('metric');self.setCursor(Qt.PointingHandCursor);self.setFocusPolicy(Qt.StrongFocus);self.setAccessibleName(key);self.setToolTip('Haga clic para ver los registros que forman este indicador.')
    def mouseReleaseEvent(self,event):
        if event.button()==Qt.LeftButton and self.rect().contains(event.position().toPoint()):self.clicked.emit()
        super().mouseReleaseEvent(event)
    def keyPressEvent(self,event):
        if event.key() in (Qt.Key_Return,Qt.Key_Enter,Qt.Key_Space):self.clicked.emit();event.accept();return
        super().keyPressEvent(event)

class NeuralWorker(QThread):
    completed=Signal(object)
    failed=Signal(str)
    def __init__(self,message,model,moment,allowed,parent=None):
        super().__init__(parent);self.args=(message,model,moment,allowed)
    def run(self):
        from .neural_assistant import propose
        try:self.completed.emit(propose(*self.args))
        except Exception as exc:self.failed.emit(str(exc))

class Form(QDialog):
    def __init__(self,parent,title,fields,values=None,store=None,year=None):
        super().__init__(parent); self.setWindowTitle(title); self.resize(650,620); self.inputs={}; self.fields=fields
        outer=QVBoxLayout(self); outer.addWidget(label(title,'brand')); outer.addWidget(label('Los campos con * son obligatorios. Fechas: AAAA-MM-DD.','muted'))
        scroll=QScrollArea(); scroll.setWidgetResizable(True); content=QWidget(); form=QFormLayout(content); form.setVerticalSpacing(12); values=values or {}
        for f in fields:
            value=values.get(f.key,'')
            if f.type=='choice':
                w=QComboBox(); w.addItems(f.options)
                if value: w.setCurrentText(str(value))
            elif f.type=='service_choice':
                w=QComboBox();w.setEditable(True);w.addItems(store.food_services())
                if value and w.findText(str(value))<0:w.addItem(str(value))
                if value:w.setCurrentText(str(value))
            elif f.type in ('staff_ref','menu_ref'):
                w=QComboBox(); w.addItem('Seleccione…','')
                target='staff' if f.type=='staff_ref' else 'menus'
                if target=='menus' and values.get('_assistant_menu_label'):
                    w.addItem('Aula IA creará el menú de este día · '+str(values['_assistant_menu_label'])[:100],'__assistant_menu__')
                for r in store.list_records(target,year):
                    d=r['data']; text=d['nombre']
                    if target=='menus' and d.get('estado')!='Activo' and r['id']!=value:continue
                    if target=='menus': text+=f" · {d['servicio']} · {d['ciclo']} · {d['dia']}"
                    w.addItem(text,r['id'])
                idx=w.findData(value); w.setCurrentIndex(max(0,idx))
            elif f.type=='level_ref':
                w=QComboBox();w.addItem('Seleccione…','')
                for item in store.academic_levels():w.addItem(item['name'],item['id'])
                idx=w.findText(str(value));w.setCurrentIndex(max(0,idx))
            elif f.type=='grade_ref':
                w=QComboBox();w.setProperty('initialValue',str(value))
            elif f.type=='section_ref':
                w=QComboBox();w.setProperty('initialValue',str(value))
            elif f.type=='date':
                w=QDateEdit();w.setCalendarPopup(True);w.setDisplayFormat('dd/MM/yyyy');w.setMinimumDate(QDate(1900,1,1));w.setMaximumDate(QDate(2100,12,31));w.setSpecialValueText('Seleccione una fecha')
                parsed=QDate.fromString(str(value),Qt.ISODate);w.setDate(parsed if parsed.isValid() else w.minimumDate())
                if not parsed.isValid():w.calendarWidget().setCurrentPage(QDate.currentDate().year(),QDate.currentDate().month())
            elif f.type=='time':
                w=QTimeEdit();w.setDisplayFormat('hh:mm AP');w.setMinimumTime(QTime(0,0));w.setSpecialValueText('Seleccione una hora')
                parsed=QTime.fromString(str(value),'HH:mm');w.setTime(parsed if parsed.isValid() else w.minimumTime())
            elif f.type=='long': w=QTextEdit(); w.setPlainText(str(value)); w.setMinimumHeight(85); w.setMaximumHeight(120)
            else:
                w=QLineEdit(str(value))
                if f.type=='password': w.setEchoMode(QLineEdit.Password)
                if f.type=='date': w.setPlaceholderText('AAAA-MM-DD')
                if f.type=='time': w.setPlaceholderText('HH:MM')
                if f.type=='money': w.setPlaceholderText('0.00')
            self.inputs[f.key]=w; form.addRow(f.label+(' *' if f.required else ''),w)
        if all(k in self.inputs for k in ('nivel','grado','seccion')):
            def grades():
                level=self.inputs['nivel'].currentData();current=self.inputs['grado'].currentText() or self.inputs['grado'].property('initialValue')
                self.inputs['grado'].clear();self.inputs['grado'].addItem('Seleccione…','')
                for item in store.grades(level):self.inputs['grado'].addItem(item['name'],item['id'])
                self.inputs['grado'].setCurrentIndex(max(0,self.inputs['grado'].findText(str(current))));sections()
            def sections():
                grade=self.inputs['grado'].currentData();current=self.inputs['seccion'].currentText() or self.inputs['seccion'].property('initialValue')
                self.inputs['seccion'].clear();self.inputs['seccion'].addItem('Seleccione…','')
                for item in store.sections(year,grade):self.inputs['seccion'].addItem(item['name'],item['id'])
                self.inputs['seccion'].setCurrentIndex(max(0,self.inputs['seccion'].findText(str(current))))
            self.inputs['nivel'].currentIndexChanged.connect(grades);self.inputs['grado'].currentIndexChanged.connect(sections);grades()
        if all(k in self.inputs for k in ('servicio','menu')):
            menu=self.inputs['menu'];selected=values.get('menu','');records=store.list_records('menus',year);assistant_menu=values.get('_assistant_menu_label','')
            planned=label('Seleccione un menú para ver lo planificado.','muted');planned.setStyleSheet('background:#EEF7F8;color:#315965;padding:10px;border-radius:9px;')
            def load_menus():
                current=menu.currentData() or selected;service=self.inputs['servicio'].currentText();selected_date=self.inputs['fecha'].date().toString(Qt.ISODate) if 'fecha' in self.inputs and isinstance(self.inputs['fecha'],QDateEdit) else ''
                menu.clear();menu.addItem('Seleccione…','');matching=[]
                if assistant_menu:menu.addItem('Aula IA creará el menú de este día · '+str(assistant_menu)[:100],'__assistant_menu__')
                ordered=sorted(records,key=lambda r:(r['data'].get('fecha_planificada')!=selected_date,r['data'].get('fecha_planificada',''),r['data'].get('nombre','')))
                for r in ordered:
                    d=r['data']
                    if d.get('servicio')==service and (d.get('estado')=='Activo' or r['id']==current):
                        exact=' · EXACTO PARA ESTA FECHA' if selected_date and d.get('fecha_planificada')==selected_date else ''
                        menu.addItem(f"{d['nombre']} · {d.get('dia','')}{exact}",r['id'])
                        if exact:matching.append(r['id'])
                choice=menu.findData(current)
                if choice<0 and len(matching)==1:choice=menu.findData(matching[0])
                menu.setCurrentIndex(max(0,choice));show_plan()
            def show_plan(*_):
                if menu.currentData()=='__assistant_menu__':
                    planned.setText('Aula IA creará y vinculará este menú: '+str(assistant_menu));return
                current=next((r['data'] for r in records if r['id']==menu.currentData()),None)
                if not current:planned.setText('Seleccione un menú para ver lo planificado.');return
                portions=f" · {current.get('raciones_previstas')} raciones previstas" if current.get('raciones_previstas') not in ('',None) else ''
                planned.setText(f"{current.get('dia','')} · {current.get('descripcion','')}{portions}")
            self.inputs['servicio'].currentTextChanged.connect(load_menus);menu.currentIndexChanged.connect(show_plan)
            if 'fecha' in self.inputs and isinstance(self.inputs['fecha'],QDateEdit):self.inputs['fecha'].dateChanged.connect(load_menus)
            load_menus();form.addRow('Plan registrado',planned)
        scroll.setWidget(content); outer.addWidget(scroll)
        self.buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel); self.buttons.button(QDialogButtonBox.Save).setText('Guardar'); self.buttons.button(QDialogButtonBox.Cancel).setText('Cancelar')
        self.buttons.accepted.connect(self.accept); self.buttons.rejected.connect(self.reject); outer.addWidget(self.buttons)
    def values(self):
        out={}
        for f in self.fields:
            w=self.inputs[f.key]
            if f.type in ('staff_ref','menu_ref'):out[f.key]=w.currentData()
            elif isinstance(w,QDateEdit):out[f.key]='' if w.date()==w.minimumDate() else w.date().toString(Qt.ISODate)
            elif isinstance(w,QTimeEdit):out[f.key]='' if w.time()==w.minimumTime() else w.time().toString('HH:mm')
            elif isinstance(w,QComboBox):out[f.key]=w.currentText()
            elif isinstance(w,QTextEdit):out[f.key]=w.toPlainText()
            else:out[f.key]=w.text()
        return out

class Login(QDialog):
    def __init__(self,store):
        super().__init__(); self.store=store; self.setWindowTitle('AulaLocal · Acceso'); self.setFixedWidth(450)
        l=QVBoxLayout(self); l.setContentsMargins(32,32,32,32); l.setSpacing(16); l.addWidget(label('AulaLocal','title')); l.addWidget(label('Gestión escolar, en tu Mac.','muted'))
        self.setup=not store.initialized(); self.inputs={}; f=QFormLayout()
        fields=[('username','Usuario'),('password','Contraseña')]
        if self.setup: fields=[('school','Nombre del centro'),('name','Nombre del director'),*fields,('repeat','Repita la contraseña')]
        for key,title in fields:
            w=QLineEdit()
            if key in ('password','repeat'):w.setEchoMode(QLineEdit.Password)
            self.inputs[key]=w; f.addRow(title,w)
        l.addLayout(f)
        if self.setup:l.addWidget(label('La contraseña debe tener al menos 12 caracteres. Al terminar recibirás un código de recuperación para guardarlo en un lugar seguro.','muted'))
        else:
            self.remember=QCheckBox('Mantener mi sesión iniciada en este Mac');self.remember.setChecked(True);l.addWidget(self.remember)
        self.message=label(''); self.message.setStyleSheet('color:#a12d3a;'); l.addWidget(self.message)
        l.addWidget(button('Configurar mi centro' if self.setup else 'Entrar',self.submit,True))
        if not self.setup:l.addWidget(button('Olvidé mi usuario o contraseña',self.recover))
        self.inputs['password'].returnPressed.connect(self.submit)
    def submit(self):
        d={k:w.text() for k,w in self.inputs.items()}
        try:
            if self.setup:
                if d['password']!=d['repeat']:raise AppError('Las contraseñas no coinciden.')
                recovery=self.store.bootstrap(d['username'],d['password'],d['name'],d['school'])
                QMessageBox.information(self,'Guarda tu código de recuperación',f'Este código permite recuperar el acceso sin internet. Guárdalo fuera del Mac y no lo compartas.\n\n{recovery}\n\nPor seguridad solo se muestra ahora; podrás generar otro desde Usuarios y permisos.')
            else:self.store.login(d['username'],d['password'],self.remember.isChecked())
            self.accept()
        except AppError as e:self.message.setText(str(e))
    def recover(self):
        d=QDialog(self);d.setWindowTitle('Recuperar acceso');d.resize(520,300);layout=QVBoxLayout(d)
        layout.addWidget(label('Recuperar usuario y contraseña','brand'));layout.addWidget(label('Escribe el código de recuperación guardado al configurar la cuenta. Este proceso funciona completamente sin internet y permite definir un usuario y una contraseña nuevos.','muted'))
        form=QFormLayout();code=QLineEdit();username=QLineEdit();password=QLineEdit();repeat=QLineEdit();password.setEchoMode(QLineEdit.Password);repeat.setEchoMode(QLineEdit.Password)
        form.addRow('Código de recuperación',code);form.addRow('Nuevo usuario',username);form.addRow('Nueva contraseña',password);form.addRow('Repita la contraseña',repeat);layout.addLayout(form)
        layout.addWidget(label('Si no conserva el código, otra cuenta administradora del centro puede restablecer su contraseña. El teléfono guardado es solo una referencia local; no se envían SMS.','muted'))
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Save).setText('Recuperar acceso');buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);layout.addWidget(buttons)
        while d.exec()==QDialog.Accepted:
            try:
                if password.text()!=repeat.text():raise AppError('Las contraseñas no coinciden.')
                new_code=self.store.recover_access(code.text(),username.text(),password.text());self.inputs['username'].setText(username.text());QMessageBox.information(self,'Acceso recuperado',f'Tu usuario y contraseña fueron actualizados. Entra con los datos nuevos.\n\nGuarda este nuevo código de recuperación; el anterior ya no funciona:\n\n{new_code}');return
            except AppError as e:error(d,e)

class MainWindow(QMainWindow):
    def __init__(self,store):
        super().__init__();QApplication.instance().setQuitOnLastWindowClosed(False); self.store=store;self.appearance=apply_appearance(store); self.setWindowTitle('AulaLocal'); self.resize(1440,900); self.setMinimumSize(1120,740); self.current='dashboard'; self.rows=[];self.current_day=date.today();self.active_dashboard_filter=None
        root=QWidget(); self.setCentralWidget(root); layout=QHBoxLayout(root); layout.setContentsMargins(22,22,22,22); layout.setSpacing(24)
        sidebar=QVBoxLayout(); brand=label('AulaLocal','brand'); sidebar.addWidget(brand); sidebar.addWidget(label('GESTIÓN DEL CENTRO','muted'))
        self.nav=QListWidget(); self.nav.setFixedWidth(self.sidebar_width());self.nav.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff); self.keys=['dashboard']+list(ACCESS[store.user['role']]); self.keys=['dashboard']+[k for k in MODULES if k in ACCESS[store.user['role']]]
        if store.user['role'] in ('admin','direccion'):self.keys+=['audit']
        if store.user['role']=='admin':self.keys+=['academic','years','settings','users','backup']
        if store.user['role'] in ('admin','direccion'):self.keys+=['diagnostics']
        self.keys+=['appearance','assistant','help']
        names={'dashboard':'Dirección','audit':'Auditoría','academic':'Estructura académica','years':'Años escolares','settings':'Mi centro','users':'Usuarios y permisos','backup':'Copias y restauración','diagnostics':'Diagnóstico del sistema','appearance':'Apariencia y accesibilidad','assistant':'Asistente local','help':'Ayuda e instructivo'}
        symbols={'dashboard':'◆','students':'●','staff':'●','attendance':'✓','menus':'◫','receipts':'▣','expenses':'$','facilities':'⌂','visits':'↪','deliveries':'□','reminders':'◷','coaching':'◇','audit':'◎','academic':'▦','years':'◷','settings':'⚙','users':'♙','backup':'⇩','diagnostics':'✓','appearance':'◉','assistant':'✦','help':'?'}
        for k in self.keys:
            title=MODULES[k][0] if k in MODULES else names[k];self.nav.addItem(f"{symbols.get(k,'•')}  {title}");self.nav.item(self.nav.count()-1).setToolTip(title)
        sidebar.addWidget(self.nav,1); sidebar.addWidget(label('100 % local · Sin telemetría','muted')); sidebar.addWidget(button('Cerrar sesión',self.lock))
        layout.addLayout(sidebar)
        right=QVBoxLayout(); layout.addLayout(right,1)
        top=QHBoxLayout(); self.school=label(store.settings()['centro'],'brand'); top.addWidget(self.school,1)
        top.addWidget(label('Año escolar')); self.year_combo=QComboBox(); self.year_combo.setMinimumWidth(200); top.addWidget(self.year_combo); right.addLayout(top)
        identity=QHBoxLayout();self.identity=label(f"{store.user['name']} · {ROLES[store.user['role']]}",'muted');self.identity.setWordWrap(False);identity.addWidget(self.identity);identity.addStretch();self.clock=label('','clock');self.clock.setWordWrap(False);identity.addWidget(self.clock);right.addLayout(identity)
        self.body=QVBoxLayout(); self.body.setSpacing(15); right.addLayout(self.body,1)
        self.statusBar().showMessage('Listo. Los cambios se guardan localmente.')
        self.refresh_years(); self.nav.currentRowChanged.connect(self.navigate); self.year_combo.currentIndexChanged.connect(self.render); self.nav.setCurrentRow(0)
        self.timer=QTimer(self); self.timer.timeout.connect(self.check_session); self.timer.start(1000);self.check_session()
        QApplication.instance().installEventFilter(self)
        self.reminder_timer=QTimer(self);self.reminder_timer.setSingleShot(True);self.reminder_timer.timeout.connect(self.show_due_reminders);self.reminder_timer.start(900)
        self.zoom_in_action=QAction(self);self.zoom_in_action.setShortcut(QKeySequence.StandardKey.ZoomIn);self.zoom_in_action.triggered.connect(lambda:self.change_scale(1));self.addAction(self.zoom_in_action)
        self.zoom_out_action=QAction(self);self.zoom_out_action.setShortcut(QKeySequence.StandardKey.ZoomOut);self.zoom_out_action.triggered.connect(lambda:self.change_scale(-1));self.addAction(self.zoom_out_action)
        self.zoom_reset_action=QAction(self);self.zoom_reset_action.setShortcut(QKeySequence('Ctrl+0'));self.zoom_reset_action.triggered.connect(lambda:self.set_scale('comfortable'));self.addAction(self.zoom_reset_action)
    def sidebar_width(self):
        return {'compact':270,'comfortable':315,'large':350,'extra_large':390}.get(self.appearance.get('ui_scale'),315)
    def set_scale(self,scale):
        values={**self.store.appearance(),'ui_scale':scale};self.store.save_appearance(values);self.appearance=apply_appearance(self.store);self.nav.setFixedWidth(self.sidebar_width());self.render()
    def change_scale(self,direction):
        order=['compact','comfortable','large','extra_large'];current=self.store.appearance()['ui_scale'];self.set_scale(order[max(0,min(len(order)-1,order.index(current)+direction))])
    def eventFilter(self,obj,event):
        if self.store.user and event.type() in (QEvent.KeyPress,QEvent.MouseButtonPress,QEvent.Wheel):
            self.store.last_active=time.monotonic()
        return super().eventFilter(obj,event)
    def closeEvent(self,event):
        if getattr(self,'neural_worker',None) and self.neural_worker.isRunning():
            event.ignore();self.statusBar().showMessage('Espere a que termine el análisis local antes de cerrar.',8000);return
        self.timer.stop();self.reminder_timer.stop();QApplication.instance().removeEventFilter(self);super().closeEvent(event)
    def check_session(self):
        if not self.store.user:self.lock();return
        self.clock.setText(local_now().strftime('%d/%m/%Y · %I:%M:%S %p')+' · '+timezone_label())
        today=date.today()
        if today!=self.current_day:
            self.current_day=today
            if self.current in ('dashboard','students'):QTimer.singleShot(0,self.render)
    def lock(self):
        if getattr(self,'neural_worker',None) and self.neural_worker.isRunning():
            self.statusBar().showMessage('Espere a que termine el análisis local antes de cerrar sesión.',8000);return
        app=QApplication.instance(); app.setQuitOnLastWindowClosed(False)
        self.timer.stop();self.reminder_timer.stop(); self.store.logout()
        for child in self.findChildren(QDialog): child.reject()
        self.hide();app.processEvents()
        login=Login(self.store)
        if login.exec()==QDialog.Accepted:
            replacement=MainWindow(self.store); app.main_window=replacement; replacement.show(); self.close(); self.deleteLater(); app.setQuitOnLastWindowClosed(True)
        else:self.close(); app.quit()
    def safe(self,fn):
        try:return fn()
        except AppError as e:error(self,e)
        except Exception as exc:
            code=datetime.now().strftime('%Y%m%d-%H%M%S')+'-'+secrets.token_hex(2).upper()
            try:
                with (self.store.root/'errores.log').open('a',encoding='utf-8') as log:
                    log.write(f'\n[{code}] {datetime.now().astimezone().isoformat()}\n{traceback.format_exc()}')
            except OSError:pass
            error(self,f'No se pudo completar la operación.\n\nCódigo: {code}\nDetalle: {type(exc).__name__}: {exc}\n\nLa información técnica quedó guardada localmente en errores.log.')
    def year_id(self):return self.year_combo.currentData()
    def refresh_years(self):
        old=self.year_id(); self.year_combo.blockSignals(True); self.year_combo.clear()
        for y in self.store.years():self.year_combo.addItem(f"{y['label']} · {y['status']}",y['id'])
        idx=self.year_combo.findData(old)
        if idx>=0:self.year_combo.setCurrentIndex(idx)
        self.year_combo.blockSignals(False)
    def navigate(self,index):
        if index>=0:self.current=self.keys[index]; self.render()
    def render(self,*_):self.safe(self._render)
    def _render(self):
        self.store.require(); self.table=None;self.search=None;clear_layout(self.body)
        if self.current in ('dashboard','audit') or self.current in MODULES:
            if not self.year_id():
                self.body.addWidget(label('Comienza con tu primer año escolar','title')); self.body.addWidget(label('Crea el período, por ejemplo 2026-2027, para registrar matrículas y movimientos.'))
                if self.store.user['role']=='admin':self.body.addWidget(button('Crear año escolar',lambda:self.safe(self.new_year),True))
                self.body.addStretch();return
        if self.current=='dashboard':self.dashboard()
        elif self.current in MODULES:self.module()
        else:getattr(self,self.current+'_page')()
    def dashboard(self):
        self.body.addWidget(label('CENTRO DE CONTROL','eyebrow'));self.body.addWidget(label('Dirección','title')); self.body.addWidget(label('Resumen vivo del año seleccionado. Haga clic en cualquier indicador para abrir sus registros específicos.','muted'))
        scroll=QScrollArea();scroll.setWidgetResizable(True);content=QWidget();grid=QGridLayout(content);grid.setSpacing(15)
        pref=self.store.appearance();columns=int(pref['dashboard_columns'])
        try:hidden=set(json.loads(pref['dashboard_hidden']))
        except (ValueError,TypeError,json.JSONDecodeError):hidden=set()
        metrics=[item for item in self.store.dashboard(self.year_id()).items() if item[0] not in hidden]
        for i,(key,value) in enumerate(metrics):
            card=MetricCard(key);card.setMinimumHeight({'compact':104,'comfortable':122,'large':138,'extra_large':160}.get(pref['ui_scale'],122)); v=QVBoxLayout(card); v.setContentsMargins(20,13,20,12); v.addWidget(label(key,'metricLabel')); v.addWidget(label(str(value),'title'));v.addWidget(label('Ver detalles  →','metricLink'));card.clicked.connect(lambda k=key:self.safe(lambda:self.open_dashboard_metric(k))); grid.addWidget(card,i//columns,i%columns)
        if not metrics:grid.addWidget(label('No hay indicadores visibles. Puede activarlos en Apariencia y accesibilidad.','muted'),0,0)
        grid.setRowStretch((len(metrics)+columns-1)//columns,1);scroll.setWidget(content);self.body.addWidget(scroll,1); self.body.addWidget(label('Las cantidades de alimentación representan unidades aceptadas acumuladas; no equivalen a estudiantes atendidos. La asistencia de hoy cuenta los registros presentes y con tardanza.','muted'))
        self.body.addWidget(button('Actualizar indicadores',self.render))
    def open_dashboard_metric(self,key):
        if key=='Secciones activas':return self.show_sections_dialog()
        target=None;mode='all';value=None
        mapping={
          'Estudiantes activos':('students','active',None),'Cumpleaños próximos · 30 días':('students','birthdays',None),
          'Personal activo':('staff','active',None),'Presentes hoy':('attendance','today_present',None),
          'Recepciones con incidencias':('receipts','incidents',None),'Menús pendientes de corroborar':('receipts','pending_menu',None),'Recepciones sin evidencia':('receipts','missing_evidence',None),
          'Gastos RD$':('expenses','valid',None),'Visitas de hoy':('visits','today',None),
          'Planta física · pendientes':('facilities','pending',None),'Entregas generales registradas':('deliveries','valid',None),
          'Recordatorios próximos':('reminders','due',None),'Acompañamientos abiertos':('coaching','open',None)}
        if key in mapping:target,mode,value=mapping[key]
        elif key.endswith(' · unidades aceptadas'):target,mode,value='receipts','service',key.rsplit(' · unidades aceptadas',1)[0]
        if not target or target not in self.keys:raise AppError('Su cuenta no tiene acceso al detalle de este indicador.')
        ids=None
        if mode=='birthdays':ids={item['id'] for item in self.store.upcoming_birthdays(self.year_id(),30)}
        self.active_dashboard_filter={'kind':target,'mode':mode,'value':value,'ids':ids,'title':key}
        row=self.keys.index(target)
        if self.nav.currentRow()==row:self.current=target;self.render()
        else:self.nav.setCurrentRow(row)
    def show_sections_dialog(self):
        rows=self.store.academic_summary(self.year_id());d=QDialog(self);d.setWindowTitle('Secciones activas');d.resize(900,560);layout=QVBoxLayout(d);layout.addWidget(label('Secciones activas','brand'));layout.addWidget(label('Distribución del año escolar seleccionado. Puede mover y redimensionar las columnas con el mouse.','muted'))
        layout.addWidget(table_widget(['Nivel','Grado','Sección','Capacidad','Estudiantes'],[[x['level'],x['grade'],x['name'],x['capacity'] or 'Sin límite',x['students']] for x in rows]),1);buttons=QDialogButtonBox(QDialogButtonBox.Close);buttons.button(QDialogButtonBox.Close).setText('Cerrar');buttons.rejected.connect(d.reject);layout.addWidget(buttons);d.exec()
    def clear_dashboard_filter(self):
        self.active_dashboard_filter=None;self.fill_table()
    def module(self):
        kind=self.current; self.body.addWidget(label(MODULES[kind][0],'title'))
        if self.active_dashboard_filter and self.active_dashboard_filter.get('kind')!=kind:self.active_dashboard_filter=None
        if self.active_dashboard_filter:
            notice=QHBoxLayout();notice.addWidget(label('Vista desde Dirección: '+self.active_dashboard_filter['title'],'eyebrow'));notice.addStretch();notice.addWidget(button('Mostrar todos',self.clear_dashboard_filter));self.body.addLayout(notice)
        toolbar=QHBoxLayout(); self.search=QLineEdit(); self.search.setPlaceholderText('Buscar en los registros de este año…'); toolbar.addWidget(self.search,1)
        editable=self.store.user['role']!='consulta' and self.store.year(self.year_id())['status']=='abierto'
        b=button('Nuevo registro',lambda:self.safe(self.new_record),True); b.setEnabled(editable); toolbar.addWidget(b)
        b=button('Editar',lambda:self.safe(self.edit_record)); b.setEnabled(editable); toolbar.addWidget(b)
        b=button('Eliminar',lambda:self.safe(self.delete_record),role='danger');b.setEnabled(editable);toolbar.addWidget(b)
        b=button('Restaurar',lambda:self.safe(self.restore_record));b.setEnabled(editable);toolbar.addWidget(b)
        self.show_deleted=QCheckBox('Mostrar eliminados');self.show_deleted.stateChanged.connect(self.fill_table);toolbar.addWidget(self.show_deleted)
        self.body.addLayout(toolbar)
        if kind=='students':
            filters=QHBoxLayout();filters.addWidget(label('Organizar por:'))
            self.level_filter=QComboBox();self.level_filter.addItem('Todos los niveles','')
            for level in self.store.academic_levels():self.level_filter.addItem(level['name'],level['id'])
            self.grade_filter=QComboBox();self.grade_filter.addItem('Todos los grados','');self.section_filter=QComboBox();self.section_filter.addItem('Todas las secciones','')
            def update_grades():
                self.grade_filter.blockSignals(True);self.grade_filter.clear();self.grade_filter.addItem('Todos los grados','')
                for grade in self.store.grades(self.level_filter.currentData() or None):self.grade_filter.addItem(grade['name'],grade['id'])
                self.grade_filter.blockSignals(False);update_sections()
            def update_sections():
                self.section_filter.blockSignals(True);self.section_filter.clear();self.section_filter.addItem('Todas las secciones','')
                for section in self.store.sections(self.year_id(),self.grade_filter.currentData() or None):
                    if not self.level_filter.currentText().startswith('Todos') and section['level']!=self.level_filter.currentText():continue
                    self.section_filter.addItem(f"{section['name']} · {section['grade']}",section['name'])
                self.section_filter.blockSignals(False)
                if getattr(self,'table',None) is not None and self.table.isVisible():self.fill_table()
            self.level_filter.currentIndexChanged.connect(update_grades);self.grade_filter.currentIndexChanged.connect(update_sections);self.section_filter.currentIndexChanged.connect(self.fill_table)
            for w in (self.level_filter,self.grade_filter,self.section_filter):filters.addWidget(w)
            filters.addStretch();self.body.addLayout(filters);update_grades()
        if kind=='attendance':
            period=QHBoxLayout();period.addWidget(label('Período del informe:'))
            y=self.store.year(self.year_id());start=QDate.fromString(y['start_date'],Qt.ISODate);end=QDate.fromString(y['end_date'],Qt.ISODate)
            self.attendance_from=QDateEdit(start);self.attendance_from.setCalendarPopup(True);self.attendance_from.setDisplayFormat('dd/MM/yyyy');self.attendance_from.setMinimumDate(start);self.attendance_from.setMaximumDate(end)
            self.attendance_to=QDateEdit(end);self.attendance_to.setCalendarPopup(True);self.attendance_to.setDisplayFormat('dd/MM/yyyy');self.attendance_to.setMinimumDate(start);self.attendance_to.setMaximumDate(end)
            period.addWidget(label('Desde'));period.addWidget(self.attendance_from);period.addWidget(label('Hasta'));period.addWidget(self.attendance_to);period.addStretch();self.body.addLayout(period)
            self.attendance_from.dateChanged.connect(self.fill_table);self.attendance_to.dateChanged.connect(self.fill_table)
        self.table=table_widget([],[]); self.body.addWidget(self.table,1); self.search.textChanged.connect(self.fill_table); self.table.doubleClicked.connect(lambda _:self.safe(self.edit_record))
        self.fill_table()
        evidence_label='Evidencias (fotos/videos)' if kind in ('receipts','deliveries') else 'Adjuntos'
        actions=[('Ver ficha',self.view_detail),('Detalle PDF',self.detail_pdf),('Reporte PDF',lambda:self.export('pdf')),('Excel',lambda:self.export('xlsx')),(evidence_label,self.attachments_dialog)]
        if kind in ('students','staff'):
            actions.extend([('Importar Excel',self.import_excel),('Descargar plantilla',self.import_template)])
        if kind=='attendance':actions.insert(0,('Importar ponchador',self.import_attendance))
        if kind in ('staff','students') and self.store.user['role'] in ('admin','direccion','secretaria'):actions.append(('Emitir constancia',self.letter))
        if kind=='menus':actions.extend([('Planificar semana',self.weekly_menu_dialog),('Tipos de alimentación',self.food_services_dialog)])
        action_grid=QGridLayout();action_grid.setHorizontalSpacing(10);action_grid.setVerticalSpacing(8)
        for i,(text,fn) in enumerate(actions):
            b=button(text,lambda checked=False,f=fn:self.safe(f),text in ('Importar Excel','Importar ponchador'));action_grid.addWidget(b,i//4,i%4)
        self.body.addLayout(action_grid)
        hint='Pulse cualquier encabezado para ordenar; vuelva a pulsarlo para invertir el orden. Arrastre encabezados y bordes para mover o redimensionar columnas. Doble clic para editar. Los reportes respetan la búsqueda visible.'
        if kind=='menus':hint+=' “Planificar semana” permite registrar el almuerzo de lunes a viernes. Las recepciones se comparan con esta planificación. Eliminar oculta el registro sin borrar el historial y Restaurar lo recupera.'
        elif kind=='attendance':hint+=' Importar ponchador reconoce Excel/CSV, agrupa las marcaciones del día y prepara entrada, salida, tardanza y horas trabajadas antes de guardar.'
        else:hint+=' Eliminar es recuperable y conserva informes, adjuntos y auditoría. Active “Mostrar eliminados” para restaurar un registro.'
        self.body.addWidget(label(hint,'muted'))
    def fill_table(self,*_):
        table=getattr(self,'table',None);search=getattr(self,'search',None)
        if table is None or search is None or not isValid(table) or not isValid(search):return
        kind=self.current; query=search.text();show_deleted=getattr(self,'show_deleted',None) is not None and self.show_deleted.isChecked();self.rows=self.store.list_records(kind,self.year_id(),query,include_deleted=show_deleted)
        start=end=''
        if kind=='attendance' and hasattr(self,'attendance_from'):
            start=self.attendance_from.date().toString(Qt.ISODate);end=self.attendance_to.date().toString(Qt.ISODate)
            if start>end:return self.statusBar().showMessage('La fecha inicial no puede ser posterior a la final.')
            self.rows=[r for r in self.rows if start<=r['data'].get('fecha','')<=end]
        data=reports.readable_rows(self.store,kind,self.year_id(),query,start,end,include_deleted=show_deleted); cols=list(reports.COLUMNS[kind]); fields={f.key:f.label for f in MODULES[kind][1]}
        fields.update(edad='Edad actual',horas='Horas trabajadas',menu_previsto='Menú planificado',fecha_planificada='Fecha planificada',situacion='Situación',evidencias='Evidencias')
        if show_deleted:cols.append('situacion')
        if kind=='students' and hasattr(self,'level_filter'):
            level='' if self.level_filter.currentText().startswith('Todos') else self.level_filter.currentText();grade='' if self.grade_filter.currentText().startswith('Todos') else self.grade_filter.currentText();section=self.section_filter.currentData() or ''
            keep=lambda r:(not level or r['data'].get('nivel')==level) and (not grade or r['data'].get('grado')==grade) and (not section or r['data'].get('seccion')==section)
            self.rows=[r for r in self.rows if keep(r)];ids={r['id'] for r in self.rows};data=[r for r in data if r['id'] in ids]
        if kind=='menus' and not show_deleted:
            self.rows=[r for r in self.rows if r['data'].get('estado')=='Activo'];ids={r['id'] for r in self.rows};data=[r for r in data if r['id'] in ids]
        dashboard_filter=self.active_dashboard_filter if self.active_dashboard_filter and self.active_dashboard_filter.get('kind')==kind else None
        if dashboard_filter:
            today=date.today().isoformat();mode=dashboard_filter['mode'];value=dashboard_filter.get('value');wanted=dashboard_filter.get('ids')
            def matches(row):
                d=row['data']
                if mode=='active':return d.get('estado')=='Activo'
                if mode=='birthdays':return row['id'] in (wanted or set())
                if mode=='today_present':return d.get('fecha')==today and d.get('estado') in ('Presente','Tardanza')
                if mode=='service':return d.get('servicio')==value and d.get('estado')!='Anulado'
                if mode=='incidents':return bool(d.get('incidencias')) or int(d.get('rechazadas') or 0)>0
                if mode=='pending_menu':return d.get('servicio')=='Almuerzo' and (d.get('corresponde') or 'Pendiente de verificar')=='Pendiente de verificar'
                if mode=='missing_evidence':return d.get('estado')!='Anulado' and not self.store.evidence_items('receipts',self.year_id(),row['id'])
                if mode=='valid':return d.get('estado')!='Anulado'
                if mode=='today':return d.get('fecha')==today
                if mode=='pending':return d.get('estado')!='Resuelto'
                if mode=='due':return row['id'] in {x['id'] for x in self.store.due_reminders(self.year_id())}
                if mode=='open':return d.get('estado')!='Cerrado'
                return True
            self.rows=[r for r in self.rows if matches(r)];ids={r['id'] for r in self.rows};data=[r for r in data if r['id'] in ids]
        sort_column=table.horizontalHeader().sortIndicatorSection();sort_order=table.horizontalHeader().sortIndicatorOrder();table.setSortingEnabled(False)
        table.setColumnCount(len(cols)); table.setHorizontalHeaderLabels([fields[c] for c in cols]); table.setRowCount(len(data))
        for i,r in enumerate(data):
            for j,c in enumerate(cols):
                item=SmartTableItem(r.get(c,'')); item.setToolTip(str(r.get(c,'')));item.setData(Qt.UserRole,r['id']); table.setItem(i,j,item)
        if not table.property('columnsInitialized'):
            table.resizeColumnsToContents()
            for column in range(table.columnCount()):table.setColumnWidth(column,min(max(table.columnWidth(column),100),420))
            table.setProperty('columnsInitialized',True)
        table.setSortingEnabled(True)
        if 0<=sort_column<table.columnCount():table.sortItems(sort_column,sort_order)
        self.statusBar().showMessage(f'{len(data)} registros en el año seleccionado')
    def selected(self):
        if self.table is None or not isValid(self.table):raise AppError('La lista se está actualizando. Inténtelo nuevamente.')
        i=self.table.currentRow()
        if i<0:raise AppError('Seleccione un registro de la tabla.')
        item=next((self.table.item(i,column) for column in range(self.table.columnCount()) if self.table.item(i,column)),None);rid=item.data(Qt.UserRole) if item else None
        record=next((row for row in self.rows if row['id']==rid),None)
        if not record:raise AppError('No se pudo identificar el registro seleccionado. Selecciónelo nuevamente.')
        return record
    def new_record(self):self.record_form()
    def edit_record(self):
        record=self.selected()
        if record['data'].get('_deleted'):raise AppError('Restaure el registro antes de editarlo.')
        self.record_form(record)
    def record_form(self,record=None):
        kind=self.current; self.store.require(kind,write=True); self.store._open(self.year_id())
        values=record['data'] if record else {}
        if not record:
            y=self.store.year(self.year_id()); today=date.today().isoformat(); values={'fecha':today if y['start_date']<=today<=y['end_date'] else y['start_date']}
            if kind in ('receipts','deliveries'):values['hora']=local_now().strftime('%H:%M')
            if kind=='receipts':values.update(rechazadas='0',corresponde='Pendiente de verificar')
            if kind=='menus':
                selected=date.fromisoformat(values['fecha']);monday=date.fromordinal(selected.toordinal()-selected.weekday())
                values.update(semana_inicio=monday.isoformat(),ciclo=f"Semana del {monday.strftime('%d/%m/%Y')}",dia=('Lunes','Martes','Miércoles','Jueves','Viernes','Sábado','Domingo')[selected.weekday()],servicio='Almuerzo',estado='Activo')
            if kind=='deliveries':values.update(cantidad='1',unidad='unidad',estado='Recibido')
            if kind=='reminders':values.update(prioridad='Normal',estado='Pendiente')
        f=Form(self,MODULES[kind][0],MODULES[kind][1],values,self.store,self.year_id())
        while f.exec()==QDialog.Accepted:
            try:
                rid=self.store.save_record(kind,self.year_id(),f.values(),record['id'] if record else None,record['version'] if record else None); self.render()
                if not record and kind in ('receipts','deliveries'):
                    title='Evidencias de la recepción' if kind=='receipts' else 'Evidencias de la entrega'
                    if QMessageBox.question(self,title,'El registro se guardó correctamente. ¿Desea agregar ahora fotos o videos de evidencia?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:
                        self._attachments_dialog_for(kind,self.year_id(),rid)
                        self.render()
                return
            except AppError as e:error(f,e)
    def export(self,fmt):
        path=save_dialog(self,'Guardar reporte',f"{self.current}-{self.store.year(self.year_id())['label']}.{fmt}",f'{fmt.upper()} (*.{fmt})')
        if path:
            if not path.lower().endswith('.'+fmt):path+='.'+fmt
            include_photos=False
            if fmt=='pdf' and self.current in ('receipts','deliveries'):
                choice=QMessageBox.question(self,'Evidencias en el informe','¿Desea incluir las fotografías y el listado de videos adjuntos en el PDF?',QMessageBox.Yes|QMessageBox.No|QMessageBox.Cancel)
                if choice==QMessageBox.Cancel:return
                include_photos=choice==QMessageBox.Yes
            start=end=''
            if self.current=='attendance' and hasattr(self,'attendance_from'):
                start=self.attendance_from.date().toString(Qt.ISODate);end=self.attendance_to.date().toString(Qt.ISODate)
                if start>end:raise AppError('La fecha inicial no puede ser posterior a la final.')
            if fmt=='pdf':reports.report_pdf(self.store,self.current,self.year_id(),path,self.search.text(),include_photos,start,end)
            else:reports.report_xlsx(self.store,self.current,self.year_id(),path,self.search.text(),start,end)
            self.statusBar().showMessage('Reporte guardado correctamente.')
            if QMessageBox.question(self,'Reporte guardado','El archivo se creó correctamente. ¿Desea abrirlo ahora para revisar o imprimir?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:QDesktopServices.openUrl(QUrl.fromLocalFile(path))
    def detail_pdf(self):
        r=self.selected(); path=save_dialog(self,'Guardar expediente',f"expediente-{r['id']}.pdf",'PDF (*.pdf)')
        if path:
            if not path.lower().endswith('.pdf'):path+='.pdf'
            reports.record_pdf(self.store,self.current,self.year_id(),r['id'],path);self.statusBar().showMessage('Expediente PDF guardado.')
            if QMessageBox.question(self,'PDF guardado','¿Desea abrirlo para revisar o imprimir?',QMessageBox.Yes|QMessageBox.No)==QMessageBox.Yes:QDesktopServices.openUrl(QUrl.fromLocalFile(path))
    def view_detail(self):
        r=self.selected();d=QDialog(self);d.setWindowTitle('Ficha del registro');d.resize(720,680);outer=QVBoxLayout(d);outer.addWidget(label(r['data'].get('nombre',MODULES[self.current][0]),'brand'))
        if self.current=='students':
            profile=self.store.student_profile(self.year_id(),r['data']);color='#19734A' if profile['edad_en_rango'] is True else '#A05A00' if profile['edad_en_rango'] is False else '#607482'
            age=label(f"Edad actual automática: {profile['edad']}  ·  Al iniciar el año: {profile['edad_inicio_año']}  ·  Rango configurado: {profile['rango_esperado']}  ·  Actualizada: {date.fromisoformat(profile['calculada_el']).strftime('%d/%m/%Y')}");age.setStyleSheet(f'color:{color};font-size:15px;font-weight:700;padding:10px;background:#FFFFFF;border-radius:8px;');outer.addWidget(age)
            if profile['edad_en_rango'] is False:outer.addWidget(label('La edad está fuera del rango configurado. Es una alerta informativa: el registro no se modifica automáticamente.','muted'))
        if self.current=='receipts':
            comparison=self.store.receipt_comparison(self.year_id(),r['data']);status=comparison['verificacion'];color='#19734A' if status=='Sí, corresponde' else '#A13D48' if status=='No corresponde' else '#A05A00'
            check=label(f"Corroboración INABIE: {status}\nMenú planificado: {comparison['menu_planificado']}\nFecha planificada: {comparison['fecha_planificada'] or 'No definida'}\nDiferencias: {comparison['diferencias'] or 'No registradas'}");check.setStyleSheet(f'color:{color};font-size:14px;font-weight:650;padding:12px;background:#FFFFFF;border-radius:9px;');outer.addWidget(check)
        if r['data'].get('_deleted'):
            outer.addWidget(label(f"Registro eliminado el {r['data'].get('_deleted_at','')} por {r['data'].get('_deleted_by','')}. Puede restaurarse desde la lista.",'muted'))
        scroll=QScrollArea();scroll.setWidgetResizable(True);content=QWidget();form=QFormLayout(content)
        for field in MODULES[self.current][1]:form.addRow(field.label,label(str(r['data'].get(field.key,'') or 'No registrado')))
        scroll.setWidget(content);outer.addWidget(scroll);close=QDialogButtonBox(QDialogButtonBox.Close);close.button(QDialogButtonBox.Close).setText('Cerrar');close.rejected.connect(d.reject);outer.addWidget(close);d.exec()
    def import_template(self):
        path=save_dialog(self,'Guardar plantilla',f'plantilla-{self.current}.xlsx','Excel (*.xlsx)')
        if path:self.store.create_import_template(self.current,path);QMessageBox.information(self,'Plantilla creada','La plantilla está lista. Puedes completarla en Excel y luego importarla.')
    def import_excel(self):
        path,_=QFileDialog.getOpenFileName(self,'Importar datos','','Excel o CSV (*.xlsx *.csv)')
        if not path:return
        defaults={}
        if self.current=='students':
            dialog=QDialog(self);dialog.setWindowTitle('Destino de los estudiantes');layout=QVBoxLayout(dialog);layout.addWidget(label('Clasificar estudiantes importados','brand'));layout.addWidget(label('Estas opciones se aplican cuando la hoja no trae nivel, grado o sección.','muted'));form=QFormLayout()
            level=QComboBox();grade=QComboBox();section=QComboBox()
            for item in self.store.academic_levels():level.addItem(item['name'],item['id'])
            def load_grades():
                grade.clear()
                for item in self.store.grades(level.currentData()):grade.addItem(item['name'],item['id'])
                load_sections()
            def load_sections():
                section.clear()
                for item in self.store.sections(self.year_id(),grade.currentData()):section.addItem(item['name'],item['id'])
            level.currentIndexChanged.connect(load_grades);grade.currentIndexChanged.connect(load_sections);form.addRow('Nivel',level);form.addRow('Grado',grade);form.addRow('Sección',section);layout.addLayout(form);load_grades()
            buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Ok).setText('Importar');buttons.accepted.connect(dialog.accept);buttons.rejected.connect(dialog.reject);layout.addWidget(buttons)
            if dialog.exec()!=QDialog.Accepted:return
            defaults={'nivel':level.currentText(),'grado':grade.currentText(),'seccion':section.currentText()}
        count=self.store.import_records(self.current,self.year_id(),path,defaults);QMessageBox.information(self,'Importación completada',f'Se importaron {count} registros correctamente.');self.render()
    def import_attendance(self):
        path,_=QFileDialog.getOpenFileName(self,'Seleccionar archivo del ponchador','','Archivos de asistencia (*.xlsx *.xls *.csv)')
        if not path:return
        options=QDialog(self);options.setWindowTitle('Analizar archivo del ponchador');options.resize(560,300);layout=QVBoxLayout(options);layout.addWidget(label('Organizar asistencia automáticamente','brand'));layout.addWidget(label('AulaLocal detectará nombres o códigos, fechas y marcaciones. La primera hora será la entrada y la última será la salida. Nada se guardará hasta que revises la vista previa.','muted'))
        form=QFormLayout();expected=QTimeEdit(QTime(8,0));expected.setDisplayFormat('hh:mm AP');grace=QSpinBox();grace.setRange(0,180);grace.setValue(15);grace.setSuffix(' minutos')
        form.addRow('Hora esperada de entrada',expected);form.addRow('Tolerancia para tardanza',grace);layout.addLayout(form)
        buttons=QDialogButtonBox(QDialogButtonBox.Ok|QDialogButtonBox.Cancel);buttons.button(QDialogButtonBox.Ok).setText('Analizar archivo');buttons.accepted.connect(options.accept);buttons.rejected.connect(options.reject);layout.addWidget(buttons)
        if options.exec()!=QDialog.Accepted:return
        preview=self.store.preview_attendance_import(self.year_id(),path,expected.time().toString('HH:mm'),grace.value())
        review=QDialog(self);review.setWindowTitle('Revisar importación del ponchador');review.resize(1050,680);box=QVBoxLayout(review);box.addWidget(label('Vista previa de asistencia','brand'))
        summary=f"{preview['matched_days']} días de asistencia reconocidos · {preview['source_rows']} filas leídas · {len(preview['unmatched'])} personas no identificadas · {preview['incomplete']} días con una sola marcación"
        box.addWidget(label(summary,'muted'));names={r['id']:r['data']['nombre'] for r in self.store.list_records('staff',self.year_id())}
        rows=[[names.get(item['personal'],str(item['personal'])),date.fromisoformat(item['fecha']).strftime('%d/%m/%Y'),item['estado'],item['entrada'] or '—',item['salida'] or '—',item['notas']] for item in preview['records']]
        preview_table=table_widget(['Personal','Fecha','Estado','Entrada','Salida','Observación'],rows);box.addWidget(preview_table,1)
        if preview['unmatched'] or preview['ignored']:
            notices=(['No se guardarán estas filas:']+preview['unmatched'][:6]+preview['ignored'][:6]);warning=label('\n'.join(notices));warning.setStyleSheet('color:#8A4B08;background:#FFF5E6;padding:10px;border-radius:8px;');box.addWidget(warning)
        review_buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);review_buttons.button(QDialogButtonBox.Save).setText('Importar asistencia');review_buttons.accepted.connect(review.accept);review_buttons.rejected.connect(review.reject);box.addWidget(review_buttons)
        if review.exec()!=QDialog.Accepted:return
        result=self.store.apply_attendance_import(self.year_id(),preview);QMessageBox.information(self,'Asistencia importada',f"Se crearon {result['created']} registros y se actualizaron {result['updated']}.\n\nFilas no identificadas: {result['unmatched']}\nDías con una sola marcación: {result['incomplete']}\n\nPuedes usar Reporte PDF o Excel para imprimir el período seleccionado.");self.render()
    def letter(self):
        r=self.selected(); d=QDialog(self); d.setWindowTitle('Revisar constancia antes de imprimir'); d.resize(720,650); l=QVBoxLayout(d)
        l.addWidget(label('Revisa el texto y genera el PDF','brand')); text=QTextEdit();text.setPlainText(reports.document_text(self.store,self.current,self.year_id(),r['id']));l.addWidget(text)
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);l.addWidget(buttons)
        if d.exec()==QDialog.Accepted:
            path=save_dialog(self,'Guardar constancia','constancia.pdf','PDF (*.pdf)')
            if path:reports.letter_pdf(self.store,self.current,self.year_id(),r['id'],path,text.toPlainText());self.statusBar().showMessage('Constancia guardada. Abra el PDF para imprimirlo.')
    def attachments_dialog(self):
        r=self.selected();self._attachments_dialog_for(self.current,self.year_id(),r['id'])
    def _attachments_dialog_for(self,kind,year,rid):
        d=QDialog(self);d.setWindowTitle('Evidencias y documentos');d.resize(760,520);l=QVBoxLayout(d)
        l.addWidget(label('Evidencias del registro','brand'));l.addWidget(label('Puede guardar varias fotos y videos de la entrega, además de documentos. Todo queda local dentro de AulaLocal y se incluye en las copias de seguridad.','muted'))
        listing=QListWidget();listing.setAlternatingRowColors(True);l.addWidget(listing,1);items=[]
        def refresh():
            items[:]=self.store.attachments(kind,year,rid);listing.clear()
            for a in items:
                category='Foto' if a['mime'].startswith('image/') else 'Video' if a['mime'].startswith('video/') else 'Documento'
                size=f"{a['size']/(1024*1024):.1f} MB" if a['size']>=1024*1024 else f"{max(1,a['size']//1024)} KB"
                listing.addItem(f"{category} · {a['name']} · {size}")
        def add():
            paths,_=QFileDialog.getOpenFileNames(d,'Seleccionar una o varias evidencias','','Evidencias y documentos (*.png *.jpg *.jpeg *.mov *.mp4 *.m4v *.pdf *.xlsx *.docx *.txt);;Fotos (*.png *.jpg *.jpeg);;Videos (*.mov *.mp4 *.m4v);;Todos los admitidos (*)')
            if not paths:return
            result=self.store.attach_many(kind,year,rid,paths);refresh()
            message=f"Se guardaron {len(result['saved'])} archivo(s)."
            if result['errors']:message+='\n\nNo se guardaron:\n'+'\n'.join(result['errors'])
            QMessageBox.information(d,'Evidencias procesadas',message)
        def save():
            i=listing.currentRow()
            if i<0:raise AppError('Seleccione un adjunto.')
            a=items[i];path=save_dialog(d,'Guardar copia',a['name'],'Todos los archivos (*)')
            if path:atomic_write(path,self.store.attachment_bytes(kind,year,rid,a['id']))
        def open_item():
            i=listing.currentRow()
            if i<0:raise AppError('Seleccione una evidencia para abrirla.')
            a=items[i];folder=self.store.root/'vista-previa';folder.mkdir(exist_ok=True);path=folder/f"{a['id']}-{Path(a['name']).name}"
            atomic_write(path,self.store.attachment_bytes(kind,year,rid,a['id']))
            if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(path))):raise AppError('macOS no encontró una aplicación para abrir este archivo.')
        refresh();bar=QHBoxLayout();b=button('Agregar fotos o videos',lambda:self.safe(add),True);b.setEnabled(self.store.year(year)['status']=='abierto' and self.store.user['role']!='consulta');bar.addWidget(b);bar.addWidget(button('Abrir / reproducir',lambda:self.safe(open_item)));bar.addWidget(button('Guardar copia',lambda:self.safe(save)));l.addLayout(bar)
        listing.itemDoubleClicked.connect(lambda _item:self.safe(open_item));l.addWidget(label('Selección múltiple habilitada · fotos hasta 50 MB · videos MOV/MP4/M4V hasta 500 MB · documentos hasta 25 MB. Las fotos pueden incrustarse en el PDF; los videos se enumeran y permanecen en el expediente digital.','muted'));close=QDialogButtonBox(QDialogButtonBox.Close);close.button(QDialogButtonBox.Close).setText('Cerrar');close.rejected.connect(d.reject);l.addWidget(close);d.exec()
    def delete_record(self):
        record=self.selected();data=record['data']
        if data.get('_deleted'):raise AppError('Ese registro ya está eliminado. Puede restaurarlo.')
        name=data.get('nombre') or data.get('titulo') or data.get('concepto') or data.get('articulo') or f"registro {record['id']}"
        links=self.store.record_dependencies(self.current,self.year_id(),record['id'])
        history='\n\nSe conservarán: '+', '.join(f'{value} {key.lower()}' for key,value in links.items())+'.' if links else ''
        question=f'¿Desea eliminar “{name}” de la lista activa?\n\nLa eliminación es recuperable y quedará registrada en auditoría.{history}'
        if QMessageBox.question(self,'Eliminar de forma segura',question,QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        self.store.archive_record(self.current,self.year_id(),record['id']);self.render();QMessageBox.information(self,'Registro eliminado','El registro dejó de aparecer en la lista activa. Puede recuperarlo usando “Mostrar eliminados” y “Restaurar”.')
    def restore_record(self):
        record=self.selected();data=record['data']
        legacy_menu=self.current=='menus' and data.get('estado')=='Inactivo'
        if not data.get('_deleted') and not legacy_menu:raise AppError('Seleccione un registro eliminado.')
        name=data.get('nombre') or data.get('titulo') or data.get('concepto') or f"registro {record['id']}"
        if QMessageBox.question(self,'Restaurar registro',f'¿Desea restaurar “{name}” a la lista activa?',QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        self.store.restore_record(self.current,self.year_id(),record['id']);self.render();QMessageBox.information(self,'Registro restaurado','El registro volvió a la lista activa.')
    def retire_menu(self):
        record=self.selected();name=record['data'].get('nombre','este menú')
        if QMessageBox.question(self,'Retirar menú',f'¿Desea retirar “{name}”?\n\nDejará de aparecer en nuevas recepciones. Las entregas anteriores y sus evidencias no se borrarán.',QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        referenced=self.store.archive_menu(self.year_id(),record['id']);self.render()
        QMessageBox.information(self,'Menú retirado','El menú fue retirado y el historial quedó protegido.' if referenced else 'El menú fue retirado de las opciones activas.')
    def delete_menu(self):
        record=self.selected();name=record['data'].get('nombre','este menú');uses=self.store.menu_usage_count(self.year_id(),record['id'])
        history=f' Tiene {uses} recepción(es) asociada(s), que se conservarán.' if uses else ''
        if QMessageBox.question(self,'Eliminar menú',f'¿Desea eliminar “{name}” de la lista activa?\n\nDejará de aparecer en nuevas recepciones.{history}\nPodrá verlo activando “Mostrar eliminados”.',QMessageBox.Yes|QMessageBox.No)!=QMessageBox.Yes:return
        self.store.delete_menu(self.year_id(),record['id']);self.render();QMessageBox.information(self,'Menú eliminado','El menú fue eliminado correctamente.')
    def weekly_menu_dialog(self):
        year=self.store.year(self.year_id());d=QDialog(self);d.setWindowTitle('Menú oficial semanal INABIE');d.resize(1080,860);layout=QVBoxLayout(d)
        layout.addWidget(label('PLANIFICACIÓN INABIE','eyebrow'));layout.addWidget(label('Menú y evidencias por día','brand'));layout.addWidget(label('Cada pestaña es un expediente diario: planifique lo que debe llegar y agregue ahí mismo varias fotos o videos. Las evidencias se organizan automáticamente por semana y día en el informe.','muted'))
        start=QDate.fromString(year['start_date'],Qt.ISODate);end=QDate.fromString(year['end_date'],Qt.ISODate);today=QDate.currentDate();candidate=today if start<=today<=end else start;candidate=candidate.addDays(-candidate.dayOfWeek()+1)
        if candidate<start:candidate=candidate.addDays(7)
        controls=QHBoxLayout();previous=button('← Semana anterior',lambda:change_week(-7));controls.addWidget(previous);controls.addWidget(label('Semana que inicia:'))
        week=QDateEdit(candidate);week.setCalendarPopup(True);week.setDisplayFormat('dd/MM/yyyy');week.setMinimumDate(start);week.setMaximumDate(end);controls.addWidget(week);next_week=button('Semana siguiente →',lambda:change_week(7));controls.addWidget(next_week);controls.addStretch();week_range=label('','eyebrow');controls.addWidget(week_range);layout.addLayout(controls)
        days=('Lunes','Martes','Miércoles','Jueves','Viernes');tabs=QTabWidget();editors={};pending={};week_records={};drafts={};loaded_week=[None]
        for day in days:
            page=QWidget();box=QVBoxLayout(page);date_label=label('','title');box.addWidget(date_label);box.addWidget(label('Menú / alimentos que INABIE propone entregar','metricLabel'));description=QTextEdit();description.setPlaceholderText('Ejemplo: arroz, habichuelas guisadas, pollo y ensalada');description.setMinimumHeight(95);description.setMaximumHeight(120);box.addWidget(description)
            form=QFormLayout();rations=QSpinBox();rations.setRange(0,100000);rations.setSpecialValueText('Sin definir');observations=QTextEdit();observations.setPlaceholderText('Indicaciones, restricciones o notas de planificación');observations.setMinimumHeight(65);observations.setMaximumHeight(85);form.addRow('Raciones previstas',rations);form.addRow('Observaciones',observations);box.addLayout(form)
            evidence_box=QGroupBox('Fotos y videos de este día');evidence_layout=QHBoxLayout(evidence_box);evidence_list=QListWidget();evidence_list.setIconSize(QSize(84,62));evidence_list.setMinimumSize(330,185);evidence_list.setStyleSheet('QListWidget{background:#FFFFFF;color:#092D3A;border:1px solid #CFDEE5;border-radius:10px;} QListWidget::item{color:#092D3A;padding:6px;} QListWidget::item:selected{background:#E7F3F5;color:#092D3A;}');evidence_layout.addWidget(evidence_list,1)
            preview=QLabel('Seleccione una foto para previsualizarla.\nLos videos pueden abrirse y reproducirse.');preview.setAlignment(Qt.AlignCenter);preview.setWordWrap(True);preview.setFixedSize(360,180);preview.setStyleSheet('background:#F4F7FA;border:1px dashed #AFC6D0;border-radius:10px;color:#456672;padding:10px;');evidence_layout.addWidget(preview)
            evidence_actions=QVBoxLayout();evidence_actions.addWidget(button('Agregar fotos o videos',lambda checked=False,current=day:self.safe(lambda:add_evidence(current)),True));evidence_actions.addWidget(button('Abrir / reproducir',lambda checked=False,current=day:self.safe(lambda:open_evidence(current))));evidence_actions.addWidget(button('Quitar antes de guardar',lambda checked=False,current=day:self.safe(lambda:remove_pending(current))));evidence_actions.addStretch();evidence_layout.addLayout(evidence_actions);box.addWidget(evidence_box)
            status=label('Aún no guardado','muted');box.addWidget(status);tabs.addTab(page,day);editors[day]={'date':date_label,'description':description,'rations':rations,'observations':observations,'status':status,'list':evidence_list,'preview':preview}
            evidence_list.currentItemChanged.connect(lambda _current,_previous,current_day=day:preview_evidence(current_day))
            evidence_list.itemDoubleClicked.connect(lambda _item,current_day=day:self.safe(lambda:open_evidence(current_day)))
        layout.addWidget(tabs,1)
        def normalized_monday(value):
            monday=value.addDays(-value.dayOfWeek()+1)
            if monday<start:monday=monday.addDays(7)
            return monday
        def evidence_key(day):return (week.date().toString(Qt.ISODate),day)
        def local_preview(path):
            pixmap=QPixmap(str(path))
            return QIcon(pixmap.scaled(84,62,Qt.KeepAspectRatio,Qt.SmoothTransformation)) if not pixmap.isNull() else QIcon()
        def refresh_evidence(day):
            editor=editors[day];listing=editor['list'];listing.clear();record=week_records.get(day);stored=[]
            if record:stored=self.store.attachments('menus',self.year_id(),record['id'])
            for item in stored:
                media='Foto' if item['mime'].startswith('image/') else 'Video' if item['mime'].startswith('video/') else 'Documento';widget=QListWidgetItem(f"{media} guardado · {item['name']}")
                data={'stored':True,'id':item['id'],'record_id':record['id'],'mime':item['mime'],'name':item['name']}
                if item['mime'].startswith('image/'):
                    pixmap=QPixmap();pixmap.loadFromData(self.store.attachment_preview_bytes('menus',self.year_id(),record['id'],item['id']));widget.setIcon(QIcon(pixmap.scaled(84,62,Qt.KeepAspectRatio,Qt.SmoothTransformation)))
                widget.setData(Qt.UserRole,data);listing.addItem(widget)
            for path in pending.get(evidence_key(day),[]):
                extension=Path(path).suffix.lower();media='Foto' if extension in ('.jpg','.jpeg','.png') else 'Video';widget=QListWidgetItem(f"{media} listo para guardar · {Path(path).name}");widget.setIcon(local_preview(path));widget.setData(Qt.UserRole,{'stored':False,'path':path,'mime':'image/pending' if media=='Foto' else 'video/pending','name':Path(path).name});listing.addItem(widget)
            editor['status'].setText(('Guardado' if record else 'Aún no guardado')+f" · {len(stored)} evidencia(s) guardada(s) · {len(pending.get(evidence_key(day),[]))} lista(s) para guardar")
            if listing.count():listing.setCurrentRow(0)
            else:editor['preview'].setPixmap(QPixmap());editor['preview'].setText('Todavía no hay evidencias para este día.')
        def add_evidence(day):
            paths,_=QFileDialog.getOpenFileNames(d,f'Agregar evidencias del {day}','','Fotos y videos (*.png *.jpg *.jpeg *.mov *.mp4 *.m4v);;Fotos (*.png *.jpg *.jpeg);;Videos (*.mov *.mp4 *.m4v)')
            if not paths:return
            key=evidence_key(day);current=pending.setdefault(key,[])
            for path in paths:
                if path not in current:current.append(path)
            refresh_evidence(day)
        def remove_pending(day):
            item=editors[day]['list'].currentItem()
            if not item:raise AppError('Seleccione una evidencia de la lista.')
            data=item.data(Qt.UserRole) or {}
            if data.get('stored'):raise AppError('La evidencia ya guardada forma parte del historial. Puede quitar únicamente archivos que todavía no se han guardado.')
            key=evidence_key(day);pending[key]=[path for path in pending.get(key,[]) if path!=data.get('path')];refresh_evidence(day)
        def evidence_path(data):
            if not data.get('stored'):return Path(data['path'])
            folder=self.store.root/'vista-previa';folder.mkdir(exist_ok=True);path=folder/f"menu-{data['id']}-{Path(data['name']).name}";atomic_write(path,self.store.attachment_bytes('menus',self.year_id(),data['record_id'],data['id']));return path
        def open_evidence(day):
            item=editors[day]['list'].currentItem()
            if not item:raise AppError('Seleccione una foto o video.')
            if not QDesktopServices.openUrl(QUrl.fromLocalFile(str(evidence_path(item.data(Qt.UserRole) or {})))):raise AppError('macOS no encontró una aplicación para abrir esta evidencia.')
        def preview_evidence(day):
            item=editors[day]['list'].currentItem();preview=editors[day]['preview']
            if not item:return
            data=item.data(Qt.UserRole) or {};mime=data.get('mime','')
            if mime.startswith('image/'):
                pixmap=QPixmap()
                if data.get('stored'):pixmap.loadFromData(self.store.attachment_preview_bytes('menus',self.year_id(),data['record_id'],data['id']))
                else:pixmap.load(data.get('path',''))
                if not pixmap.isNull():preview.setText('');preview.setPixmap(pixmap.scaled(preview.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation));return
            preview.setPixmap(QPixmap());preview.setText(f"VIDEO\n{data.get('name','')}\n\nDoble clic o pulse Abrir / reproducir para revisarlo.")
        def capture_drafts():
            if not loaded_week[0]:return
            for day in days:
                editor=editors[day];drafts[(loaded_week[0],day)]={'description':editor['description'].toPlainText(),'rations':editor['rations'].value(),'observations':editor['observations'].toPlainText()}
        def change_week(delta):
            candidate=week.date().addDays(delta)
            if start<=candidate<=end:week.setDate(candidate)
        def load_week(*_):
            capture_drafts()
            monday=normalized_monday(week.date())
            if monday!=week.date():week.blockSignals(True);week.setDate(monday);week.blockSignals(False)
            week_iso=monday.toString(Qt.ISODate);week_records.clear();week_records.update({r['data']['dia']:r for r in self.store.weekly_lunch_plan(self.year_id(),week_iso)});loaded_week[0]=week_iso
            friday=monday.addDays(4);week_range.setText(f"{monday.toString('dd/MM')} — {friday.toString('dd/MM/yyyy')}")
            previous.setEnabled(monday.addDays(-7)>=start);next_week.setEnabled(monday.addDays(7)<=end)
            for index,day in enumerate(days):
                exact=monday.addDays(index);editor=editors[day];editor['date'].setText(f"{day} · {exact.toString('dd/MM/yyyy')}");tabs.setTabText(index,f"{day} · {exact.toString('dd/MM')}");record=week_records.get(day);data=record['data'] if record else drafts.get((week_iso,day),{})
                editor['description'].setPlainText(str(data.get('descripcion',data.get('description',''))));editor['rations'].setValue(int(data.get('raciones_previstas',data.get('rations',0)) or 0));editor['observations'].setPlainText(str(data.get('observaciones',data.get('observations',''))));refresh_evidence(day)
        def item_for(index):
            day=days[index];editor=editors[day]
            return {'dia':day,'descripcion':editor['description'].toPlainText().strip(),'raciones_previstas':str(editor['rations'].value()) if editor['rations'].value() else '','observaciones':editor['observations'].toPlainText().strip()}
        def save_items(items,one_day=False):
            if one_day and not items[0]['descripcion']:raise AppError('Escriba el menú planificado para este día antes de guardarlo.')
            if not any(item['descripcion'] for item in items):raise AppError('Escriba al menos un menú de la semana antes de guardar.')
            week_iso=week.date().toString(Qt.ISODate);result=self.store.save_weekly_lunch_plan(self.year_id(),week_iso,items);saved_records={r['data']['dia']:r for r in self.store.weekly_lunch_plan(self.year_id(),week_iso)};media_saved=0;media_errors=[]
            for item in items:
                day=item['dia'];record=saved_records.get(day)
                if not record:continue
                key=(week_iso,day);remaining=[]
                for path in pending.get(key,[]):
                    try:self.store.attach('menus',self.year_id(),record['id'],path);media_saved+=1
                    except (AppError,OSError) as exc:remaining.append(path);media_errors.append(f"{day} · {Path(path).name}: {exc}")
                pending[key]=remaining;drafts.pop(key,None)
            loaded_week[0]=None;load_week();message=f"Se crearon {result['created']} día(s), se actualizaron {result['updated']} y se guardaron {media_saved} evidencia(s)."
            if media_errors:message+='\n\nRequieren revisión:\n'+'\n'.join(media_errors)
            QMessageBox.information(d,'Día y evidencias guardados',message)
        week.dateChanged.connect(load_week);load_week()
        actions=QHBoxLayout();actions.addWidget(button('Guardar día + evidencias',lambda:self.safe(lambda:save_items([item_for(tabs.currentIndex())],True)),True));actions.addWidget(button('Guardar semana completa',lambda:self.safe(lambda:save_items([item_for(i) for i in range(len(days))]))));actions.addStretch();actions.addWidget(label('Las selecciones se previsualizan antes de guardar. Los duplicados se detectan automáticamente.','muted'));layout.addLayout(actions)
        close=QDialogButtonBox(QDialogButtonBox.Close);close.button(QDialogButtonBox.Close).setText('Cerrar');close.rejected.connect(d.reject);layout.addWidget(close);d.exec();self.render()
    def food_services_dialog(self):
        d=QDialog(self);d.setWindowTitle('Tipos de alimentación');d.resize(560,460);layout=QVBoxLayout(d)
        layout.addWidget(label('Tipos de alimentación','brand'));layout.addWidget(label('Agregue cualquier alimento o modalidad adicional. Los tipos activos aparecerán automáticamente al crear menús y recepciones.','muted'))
        listing=QListWidget();layout.addWidget(listing,1);items=[]
        def refresh():
            items[:]=[(name,True) for name in self.store.food_services(True)]+[(name,False) for name in self.store.food_services(False) if name not in self.store.food_services(True)]
            listing.clear()
            for name,active in items:listing.addItem(('Activo · ' if active else 'Retirado · ')+name)
        def add():
            name,ok=QInputDialog.getText(d,'Nuevo tipo','Nombre del alimento o servicio:')
            if ok:self.store.save_food_service(name,True);refresh()
        def change(active):
            row=listing.currentRow()
            if row<0:raise AppError('Seleccione un tipo de la lista.')
            name,current=items[row]
            if current==active:return
            self.store.save_food_service(name,active);refresh()
        bar=QHBoxLayout();bar.addWidget(button('Agregar tipo',lambda:self.safe(add),True));bar.addWidget(button('Retirar',lambda:self.safe(lambda:change(False))));bar.addWidget(button('Reactivar',lambda:self.safe(lambda:change(True))));layout.addLayout(bar)
        close=QDialogButtonBox(QDialogButtonBox.Close);close.button(QDialogButtonBox.Close).setText('Cerrar');close.rejected.connect(d.reject);layout.addWidget(close);refresh();d.exec();self.render()
    def show_due_reminders(self):
        if 'reminders' not in ACCESS[self.store.user['role']] or not self.year_id():return
        try:rows=self.store.due_reminders(self.year_id())
        except AppError:return
        if not rows:return
        lines=[]
        for row in rows[:6]:
            data=row['data'];when=data['fecha']+(' · '+data['hora'] if data.get('hora') else '')
            lines.append(f"• {when} — {data['titulo']} ({data['prioridad']})")
        if len(rows)>6:lines.append(f'• Y {len(rows)-6} recordatorios más')
        QMessageBox.information(self,'Agenda próxima','Estos asuntos están vencidos o suceden en los próximos 7 días:\n\n'+'\n'.join(lines))
    def assistant_page(self):
        self.body.addWidget(label('Aula IA','title'));self.body.addWidget(label('Prepare registros y adjunte evidencias. El modo básico usa reglas; el modo neuronal requiere Ollama y un modelo local. Las fotos se guardan como evidencia, no se analizan.','muted'))
        chat=QTextEdit();chat.setObjectName('assistantChat');chat.setReadOnly(True);chat.setPlainText('Aula IA: Dígame lo ocurrido como usted lo contaría normalmente. Prepararé un borrador editable y nunca guardaré nada sin que usted lo revise y confirme.');self.body.addWidget(chat,1)
        engine_row=QHBoxLayout();engine=QComboBox();engine.addItem('Básico · reglas locales','');engine_row.addWidget(engine,1)
        def find_models():
            from .neural_assistant import local_models
            names=local_models();engine.clear();engine.addItem('Básico · reglas locales','')
            for name in names:engine.addItem('Neuronal local · '+name,name)
            if names:engine.setCurrentIndex(1)
            else:raise AppError('No hay modelos locales descargados en Ollama.')
        engine_row.addWidget(button('Detectar motor local',lambda:self.safe(find_models)))
        self.body.addLayout(engine_row)
        examples=QHBoxLayout();examples.addWidget(label('Ejemplos:','eyebrow'))
        example_texts=('Hoy llegó el almuerzo…','Llegó una visita…','Entregaron 20 sillas…','Recuérdame una asamblea…')
        entry=QLineEdit();entry.setObjectName('assistantEntry')
        for example in example_texts:
            examples.addWidget(button(example,lambda checked=False,value=example:entry.setText(value)))
        examples.addStretch();self.body.addLayout(examples)
        evidence_box=QGroupBox('Evidencias para la instrucción');evidence_layout=QHBoxLayout(evidence_box)
        evidence_list=QListWidget();evidence_list.setObjectName('assistantEvidence');evidence_list.setIconSize(QSize(72,54));evidence_list.setMinimumHeight(105);evidence_list.setStyleSheet('QListWidget{background:#FFFFFF;color:#092D3A;border:1px solid #CFDEE5;border-radius:10px;} QListWidget::item{color:#092D3A;padding:5px;} QListWidget::item:selected{background:#E7F3F5;color:#092D3A;}');evidence_layout.addWidget(evidence_list,1)
        preview=QLabel('Puede agregar varias fotos o videos.\nLa evidencia quedará vinculada al registro creado.');preview.setAlignment(Qt.AlignCenter);preview.setWordWrap(True);preview.setFixedSize(300,105);preview.setStyleSheet('background:#F4F7FA;border:1px dashed #AFC6D0;border-radius:10px;color:#456672;padding:8px;');evidence_layout.addWidget(preview)
        evidence_actions=QVBoxLayout();pending=[]
        def refresh_evidence():
            evidence_list.clear()
            for path in pending:
                extension=Path(path).suffix.lower();media='Foto' if extension in ('.jpg','.jpeg','.png') else 'Video' if extension in ('.mov','.mp4','.m4v') else 'Documento'
                item=QListWidgetItem(f'{media} · {Path(path).name}');item.setData(Qt.UserRole,path)
                if media=='Foto':
                    pixmap=QPixmap(path)
                    if not pixmap.isNull():item.setIcon(QIcon(pixmap.scaled(72,54,Qt.KeepAspectRatio,Qt.SmoothTransformation)))
                evidence_list.addItem(item)
            if evidence_list.count():evidence_list.setCurrentRow(0)
            else:preview.setPixmap(QPixmap());preview.setText('Puede agregar varias fotos o videos.\nLa evidencia quedará vinculada al registro creado.')
        def add_evidence():
            paths,_=QFileDialog.getOpenFileNames(self,'Agregar evidencias para Aula IA','','Evidencias (*.png *.jpg *.jpeg *.mov *.mp4 *.m4v *.pdf);;Fotos (*.png *.jpg *.jpeg);;Videos (*.mov *.mp4 *.m4v);;PDF (*.pdf)')
            for path in paths:
                if path not in pending:pending.append(path)
            refresh_evidence()
        def remove_evidence():
            row=evidence_list.currentRow()
            if row<0:raise AppError('Seleccione una evidencia para quitarla.')
            pending.pop(row);refresh_evidence()
        def open_evidence():
            item=evidence_list.currentItem()
            if not item:raise AppError('Seleccione una evidencia para abrirla.')
            if not QDesktopServices.openUrl(QUrl.fromLocalFile(item.data(Qt.UserRole))):raise AppError('macOS no encontró una aplicación para abrir el archivo.')
        def preview_evidence(item,_previous=None):
            if not item:return
            path=item.data(Qt.UserRole);pixmap=QPixmap(path)
            if not pixmap.isNull():preview.setText('');preview.setPixmap(pixmap.scaled(preview.size(),Qt.KeepAspectRatio,Qt.SmoothTransformation))
            else:preview.setPixmap(QPixmap());preview.setText(f'{Path(path).suffix.upper().lstrip(".")} · {Path(path).name}\n\nDoble clic para abrir o reproducir.')
        evidence_actions.addWidget(button('Agregar fotos o videos',lambda:self.safe(add_evidence),True));evidence_actions.addWidget(button('Abrir / reproducir',lambda:self.safe(open_evidence)));evidence_actions.addWidget(button('Quitar',lambda:self.safe(remove_evidence)));evidence_actions.addStretch();evidence_layout.addLayout(evidence_actions);self.body.addWidget(evidence_box)
        evidence_list.currentItemChanged.connect(preview_evidence);evidence_list.itemDoubleClicked.connect(lambda _item:self.safe(open_evidence))
        row=QHBoxLayout();entry.setPlaceholderText('Ejemplo: hoy llegó el almuerzo a las 10:35, menú era arroz con pollo, 85 raciones…');row.addWidget(entry,1)
        def save_draft(result):
            target=result['target']
            if target not in self.keys:chat.append('\nAula IA: Su cuenta no tiene permiso para crear ese registro.');return
            initial=dict(result.get('data',{}));person=self.store.user['name']
            for key in ('responsable','recibido_por'):
                if key in initial and not initial[key]:initial[key]=person
            title=f"Revise lo que Aula IA entendió · {MODULES[target][0]}"
            form=Form(self,title,MODULES[target][1],initial,store=self.store,year=self.year_id())
            plan_editor=None
            if target=='receipts' and result.get('planned_menu'):
                plan_editor=QLineEdit(result['planned_menu']);form.layout().insertWidget(1,label('Menú planificado — revise o corrija el texto:'));form.layout().insertWidget(2,plan_editor)
            form.buttons.button(QDialogButtonBox.Save).setText('Confirmar y guardar')
            while form.exec()==QDialog.Accepted:
                try:
                    values=form.values();attachment_kind=target
                    if target=='receipts' and values.get('menu')=='__assistant_menu__':
                        saved=self.store.save_assistant_food_entry(self.year_id(),plan_editor.text() if plan_editor else result.get('planned_menu',''),values)
                        record_id=saved['receipt_id'];attachment_kind='receipts';attachment_id=record_id
                    else:
                        record_id=self.store.save_record(target,self.year_id(),values);attachment_id=record_id
                    attached=0;problems=[];remaining=[]
                    for path in list(pending):
                        try:self.store.attach(attachment_kind,self.year_id(),attachment_id,path);attached+=1
                        except (AppError,OSError) as exc:remaining.append(path);problems.append(f'{Path(path).name}: {exc}')
                    pending[:]=remaining;refresh_evidence()
                    message=f"Guardado correctamente en {MODULES[target][0]}. Se vincularon {attached} evidencia(s)."
                    if problems:message+=' Algunas evidencias requieren revisión: '+'; '.join(problems)
                    chat.append('\nAula IA: '+message);self.statusBar().showMessage(message,8000);return
                except AppError as exc:error(form,exc)
        def send():
            message=entry.text().strip()
            if not message:return
            if getattr(self,'neural_worker',None) and self.neural_worker.isRunning():return
            chat.append('\nUsted: '+message);entry.clear()
            if engine.currentData():
                worker=NeuralWorker(message,engine.currentData(),local_now(),list(ACCESS[self.store.user['role']]),QApplication.instance());self.neural_worker=worker
                send_button.setEnabled(False);entry.setEnabled(False);engine.setEnabled(False)
                captured_year=self.year_id()
                def finish(result=None,failure=None):
                    if not isValid(chat) or self.current!='assistant':return
                    send_button.setEnabled(True);entry.setEnabled(True);engine.setEnabled(True)
                    if self.year_id()!=captured_year:
                        chat.append('\nAula IA: Cambió el año escolar. Vuelva a preparar la instrucción.');return
                    if failure:chat.append('\nAula IA: '+failure);return
                    self.safe(lambda:handle(result))
                worker.completed.connect(lambda result:finish(result=result));worker.failed.connect(lambda failure:finish(failure=failure));worker.start();return
            handle(interpret(message,local_now()))
        def handle(result):
            action=result['action']
            if action=='reply':chat.append('\nAula IA: '+result['message']);return
            if action=='navigate':
                target=result['target']
                if target not in self.keys:chat.append('\nAula IA: Su cuenta no tiene permiso para abrir ese módulo.');return
                chat.append('\nAula IA: '+result.get('message','Módulo abierto.'));self.nav.setCurrentRow(self.keys.index(target));return
            if action=='draft_record':
                chat.append(f"\nAula IA: {result['message']} Revise los datos antes de confirmar.")
                save_draft(result);return
            if action=='report':
                target=result['target']
                if target not in self.keys:chat.append('\nAula IA: Su cuenta no tiene permiso para generar ese reporte.');return
                self.current=target;self.nav.blockSignals(True);self.nav.setCurrentRow(self.keys.index(target));self.nav.blockSignals(False);self.render();self.export(result['format'])
        send_button=button('Entender y preparar',lambda:self.safe(send),True);row.addWidget(send_button);self.body.addLayout(row);entry.returnPressed.connect(lambda:self.safe(send))
        self.body.addWidget(label('Revise nombres, fechas, cantidades y adjuntos: la interpretación puede equivocarse. Solo se guarda al confirmar. Los campos obligatorios y los permisos se validan en la aplicación.','muted'))
    def help_page(self):
        self.body.addWidget(label('Ayuda e instructivo','title'));self.body.addWidget(label('Guía rápida para trabajar sin conocimientos técnicos.','muted'))
        scroll=QScrollArea();scroll.setWidgetResizable(True);content=QWidget();layout=QVBoxLayout(content)
        sections=[
          ('Primeros pasos','1. Seleccione el año escolar arriba. 2. Entre al módulo deseado. 3. Pulse Nuevo registro. 4. Complete los campos con asterisco y pulse Guardar. Los datos permanecen en este Mac.'),
          ('Planificación semanal','Elija Planificar semana y abra el día deseado. Registre menú, raciones y observaciones; agregue ahí mismo varias fotos o videos, previsualícelos y pulse Guardar día + evidencias. La recepción diaria queda enlazada con ese expediente.'),
          ('Tipos de alimentación','En Planificación semanal INABIE pulse Tipos de alimentación. Puede agregar otros alimentos además de leche, pan y almuerzo, retirarlos o reactivarlos.'),
          ('Edades automáticas','AulaLocal nunca guarda una edad fija. La calcula desde la fecha de nacimiento y la fecha actual del Mac cada vez que abre o actualiza la lista; por eso cambia automáticamente cuando el estudiante cumple años.'),
          ('Eliminar y restaurar','En cualquier módulo seleccione un registro y pulse Eliminar. Se oculta sin romper asistencia, informes, adjuntos ni auditoría. Para recuperarlo, active Mostrar eliminados, selecciónelo y pulse Restaurar.'),
          ('Planificación semanal INABIE','Entre a Planificación semanal INABIE y pulse Planificar semana. Cada día incluye menú, raciones, observaciones y sus propias evidencias. En Alimentación escolar marque si lo entregado corresponde y explique cualquier diferencia.'),
          ('Fotos, videos y documentos','Dentro de cada día del menú pulse Agregar fotos o videos; puede seleccionar varios JPG, PNG, MOV, MP4 o M4V, verlos antes de guardar y abrirlos después. También existen evidencias adicionales en la recepción. El PDF organiza las fotos por semana y día y enumera los videos.'),
          ('Asistencia desde el ponchador','Entre a Asistencia y pulse Importar ponchador. Seleccione el Excel, XLS o CSV de la memoria. Confirme la hora esperada y la tolerancia. AulaLocal relaciona nombres o códigos con el personal, usa la primera marcación como entrada y la última como salida, y muestra una vista previa antes de guardar. Las filas no identificadas se señalan y no se mezclan. Use el período Desde/Hasta y luego Reporte PDF o Excel para imprimir el informe organizado.'),
          ('Guardar, abrir e imprimir PDF','Pulse Reporte PDF o Detalle PDF, elija Escritorio o Documentos y guarde. AulaLocal ofrecerá abrir el archivo; desde Vista Previa use Archivo → Imprimir. Si macOS bloquea una carpeta, seleccione otra.'),
          ('Entregas generales','Use Entregas y bienes recibidos para sillas, equipos, materiales, donaciones u otros artículos. Registre cantidad, condición, quién entrega, quién recibe y adjunte evidencias.'),
          ('Agenda y recordatorios','Registre asambleas, reuniones, supervisiones, fechas límite y actividades. Al abrir la aplicación se mostrarán los pendientes vencidos o de los próximos siete días.'),
          ('Acompañamiento docente','Registre docente, fecha, fortalezas, resultados, acuerdos y fecha de seguimiento. El informe queda disponible en PDF y Excel para supervisión.'),
          ('Aula IA · asistente inteligente local','Puede contar lo ocurrido con naturalidad: “Hoy llegó el almuerzo a las 10:35, menú era arroz con pollo, 85 raciones, suplidor Comedor Escolar”. Agregue fotos o videos en el mismo chat. Aula IA reconoce alimentación, visitas, entregas, gastos, planta física, acompañamientos, asistencia, estudiantes, personal y recordatorios; prepara un formulario editable y solo guarda después de su confirmación. Todo funciona dentro del Mac, sin enviar datos a internet.'),
          ('Copias de seguridad','Entre a Copias y restauración y cree periódicamente un archivo .aulabackup en una memoria USB. Recuerde la contraseña del respaldo.')]
        for title,text in sections:
            box=QGroupBox(title);inside=QVBoxLayout(box);inside.addWidget(label(text));layout.addWidget(box)
        layout.addStretch();scroll.setWidget(content);self.body.addWidget(scroll,1)
    def new_year(self):
        from .catalog import F
        f=Form(self,'Crear año escolar',[F('label','Año escolar',required=True),F('start','Inicio','date',True),F('end','Fin','date',True)],{'label':'2026-2027','start':'2026-08-01','end':'2027-07-31'})
        while f.exec()==QDialog.Accepted:
            try:
                d=f.values();new=self.store.create_year(d['label'],d['start'],d['end']);self.refresh_years();self.year_combo.setCurrentIndex(self.year_combo.findData(new));self.render();return
            except AppError as e:error(f,e)
    def academic_page(self):
        self.body.addWidget(label('Niveles, grados y secciones','title'));self.body.addWidget(label('Estructura académica configurable. Los rangos de edad generan alertas informativas y aparecen en la ficha del estudiante.','muted'))
        tabs=QGridLayout();levels=self.store.academic_levels(False);grades=self.store.grades(active_only=False);sections=self.store.academic_summary(self.year_id()) if self.year_id() else []
        level_box=QGroupBox('Niveles educativos');ll=QVBoxLayout(level_box);ll.addWidget(table_widget(['Nivel','Orden'],[[x['name'],x['sort_order']] for x in levels]));
        grade_box=QGroupBox('Grados y rangos de edad');gl=QVBoxLayout(grade_box);gl.addWidget(table_widget(['Nivel','Grado','Edad mínima','Edad máxima'],[[x['level'],x['name'],x['min_age'] if x['min_age'] is not None else '',x['max_age'] if x['max_age'] is not None else ''] for x in grades]));
        section_box=QGroupBox('Secciones del año seleccionado');sl=QVBoxLayout(section_box);sl.addWidget(table_widget(['Nivel','Grado','Sección','Capacidad','Estudiantes'],[[x['level'],x['grade'],x['name'],x['capacity'] or '',x['students']] for x in sections]));
        tabs.addWidget(level_box,0,0);tabs.addWidget(grade_box,0,1);tabs.addWidget(section_box,1,0,1,2);self.body.addLayout(tabs,1)
        def new_level():
            from .catalog import F
            f=Form(self,'Crear nivel educativo',[F('name','Nombre',required=True),F('order','Orden','integer',True)],{'order':'40'})
            if f.exec()==QDialog.Accepted:self.store.save_level(f.values()['name'],f.values()['order']);self.render()
        def new_grade():
            d=QDialog(self);d.setWindowTitle('Crear grado');l=QFormLayout(d);level=QComboBox()
            for x in levels:level.addItem(x['name'],x['id'])
            name=QLineEdit();minimum=QLineEdit();maximum=QLineEdit();order=QLineEdit('10');l.addRow('Nivel',level);l.addRow('Nombre',name);l.addRow('Edad mínima',minimum);l.addRow('Edad máxima',maximum);l.addRow('Orden',order);buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);l.addRow(buttons)
            if d.exec()==QDialog.Accepted:self.store.save_grade(level.currentData(),name.text(),minimum.text(),maximum.text(),order.text());self.render()
        def new_section():
            d=QDialog(self);d.setWindowTitle('Crear sección');l=QFormLayout(d);grade=QComboBox()
            for x in grades:grade.addItem(f"{x['level']} · {x['name']}",x['id'])
            name=QLineEdit();capacity=QLineEdit();l.addRow('Grado',grade);l.addRow('Sección',name);l.addRow('Capacidad (opcional)',capacity);buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);l.addRow(buttons)
            if d.exec()==QDialog.Accepted:self.store.save_section(self.year_id(),grade.currentData(),name.text(),capacity.text());self.render()
        bar=QHBoxLayout();bar.addWidget(button('Crear nivel',lambda:self.safe(new_level)));bar.addWidget(button('Crear grado',lambda:self.safe(new_grade)));bar.addWidget(button('Crear sección',lambda:self.safe(new_section),True));bar.addStretch();self.body.addLayout(bar)
    def years_page(self):
        self.body.addWidget(label('Años escolares','title'));self.body.addWidget(label('Congelar bloquea los cambios. Archivar conserva el año para consultas. La reapertura requiere tu contraseña y un motivo.','muted'))
        years=self.store.years();self.body.addWidget(table_widget(['Año','Inicio','Fin','Estado'],[[y['label'],y['start_date'],y['end_date'],y['status']] for y in years]),1)
        self.body.addWidget(label('Las acciones siguientes se aplican al año seleccionado arriba.','muted'))
        bar=QHBoxLayout();bar.addWidget(button('Crear año',lambda:self.safe(self.new_year),True))
        for text,state in [('Congelar','congelado'),('Reabrir','abierto'),('Archivar','archivado')]:bar.addWidget(button(text,lambda checked=False,s=state:self.safe(lambda:self.change_year_state(s))))
        self.body.addLayout(bar);self.body.addWidget(button('Copiar matrículas o personal al año seleccionado',lambda:self.safe(self.copy_people)));self.body.addWidget(button('Exportar archivo histórico del año',lambda:self.safe(self.archive)))
    def change_year_state(self,state):
        y=self.store.year(self.year_id());reason,ok=QInputDialog.getMultiLineText(self,'Motivo de la acción',f"{y['label']}: {y['status']} → {state}\nExplique el motivo:")
        if not ok:return
        pw=ask_password(self,'Confirme su contraseña de administrador:')
        if pw is None:return
        self.store.transition(y['id'],state,reason,pw);self.refresh_years();self.render()
    def copy_people(self):
        target=self.store.year(self.year_id());sources=[y for y in self.store.years() if y['label']<target['label']]
        if not sources:raise AppError('Primero cree un año posterior y selecciónelo como destino.')
        source,ok=QInputDialog.getItem(self,'Copiar desde otro año','Año de origen:',[y['label'] for y in sources],0,False)
        if not ok:return
        kind,ok=QInputDialog.getItem(self,'Registros a copiar','Tipo:',['Estudiantes','Personal'],0,False)
        if not ok:return
        if QMessageBox.question(self,'Confirmar copia',f"Se copiarán los registros activos de {source} a {target['label']}. Los códigos existentes se omiten. Revise grado y sección después: no se promueven automáticamente.")!=QMessageBox.Yes:return
        count=self.store.copy_people(next(y['id'] for y in sources if y['label']==source),target['id'],'students' if kind=='Estudiantes' else 'staff');QMessageBox.information(self,'Copia completa',f'{count} registros copiados.');self.render()
    def archive(self):
        y=self.store.year(self.year_id());path=save_dialog(self,'Guardar archivo histórico',f"archivo-{y['label']}.zip",'ZIP (*.zip)')
        if path:reports.export_year(self.store,y['id'],path);QMessageBox.information(self,'Archivo exportado','Se guardaron los registros, hojas Excel, auditoría y adjuntos de este año. Este ZIP no está cifrado; guárdelo en un lugar protegido.')
    def settings_page(self):
        self.body.addWidget(label('Mi centro','title'));self.body.addWidget(label('Identidad institucional utilizada en informes, certificaciones y archivos históricos.','muted'));s=self.store.settings();inputs={}
        scroll=QScrollArea();scroll.setWidgetResizable(True);content=QWidget();layout=QVBoxLayout(content);layout.setSpacing(18)
        summary=QFrame();summary.setObjectName('card');sl=QVBoxLayout(summary);school_name=label(s.get('centro','Centro educativo'),'title');school_name.setStyleSheet('font-size:26px;font-weight:750;color:#102F3E;');sl.addWidget(school_name);sl.addWidget(label(f"Código: {s.get('codigo') or 'No registrado'}  ·  Dirección: {s.get('director') or 'No registrada'}",'muted'));layout.addWidget(summary)
        identity_box=QGroupBox('Datos del centro educativo');form=QFormLayout(identity_box);form.setVerticalSpacing(14)
        for key,title in [('centro','Nombre completo del centro'),('codigo','Código del centro'),('director','Director/a'),('direccion','Dirección física'),('telefono','Teléfono')]:
            w=QLineEdit(s.get(key,''));w.setMinimumHeight(42);w.setStyleSheet('font-size:15px;');inputs[key]=w;form.addRow(title,w)
        layout.addWidget(identity_box)
        def save():
            self.store.save_settings({k:w.text() for k,w in inputs.items()});updated=self.store.settings();self.school.setText(updated['centro']);school_name.setText(updated['centro']);self.statusBar().showMessage('Datos del centro guardados correctamente.');QMessageBox.information(self,'Mi centro','Los datos institucionales fueron guardados.')
        layout.addWidget(button('Guardar datos del centro',lambda:self.safe(save),True))
        system_box=QGroupBox('Fecha, hora y sesión');system_layout=QVBoxLayout(system_box);system_layout.addWidget(label(f'Reloj actual del Mac: {local_now().strftime("%d/%m/%Y %I:%M:%S %p")} · {timezone_label()}','clock'));system_layout.addWidget(label('AulaLocal consulta el reloj y la zona horaria del sistema. macOS conserva la fecha aunque el equipo permanezca apagado. La sesión seguirá activa hasta que pulse Cerrar sesión.','muted'));layout.addWidget(system_box)
        templates=QGroupBox('Plantillas de documentos');tl=QVBoxLayout(templates);tl.addWidget(label('Personalice cartas y certificaciones sin modificar la programación.','muted'))
        for kind,title in [('staff','Carta de trabajo'),('students','Certificación de matrícula')]:tl.addWidget(button('Editar plantilla: '+title,lambda checked=False,k=kind:self.safe(lambda:self.edit_template(k))))
        layout.addWidget(templates);layout.addStretch();scroll.setWidget(content);self.body.addWidget(scroll,1)
    def appearance_page(self):
        self.body.addWidget(label('Apariencia y accesibilidad','title'));self.body.addWidget(label('Ajuste la legibilidad y el panel para esta cuenta. Los cambios se conservan en este Mac.','muted'))
        pref=self.store.appearance();box=QGroupBox('Lectura y colores');form=QFormLayout(box)
        scale=QComboBox();scale_items=[('Compacto','compact'),('Cómodo — recomendado','comfortable'),('Grande','large'),('Extra grande','extra_large')]
        for text,value in scale_items:scale.addItem(text,value)
        scale.setCurrentIndex(max(0,scale.findData(pref['ui_scale'])))
        theme=QComboBox();theme_items=[('Océano','ocean'),('Índigo','indigo'),('Esmeralda','emerald'),('Grafito','graphite'),('Alto contraste','high_contrast')]
        for text,value in theme_items:theme.addItem(text,value)
        theme.setCurrentIndex(max(0,theme.findData(pref['ui_theme'])));form.addRow('Tamaño del texto',scale);form.addRow('Paleta de colores',theme);self.body.addWidget(box)
        dash=QGroupBox('Widgets del panel Dirección');dl=QVBoxLayout(dash);columns=QComboBox();columns.addItem('2 columnas',2);columns.addItem('3 columnas',3);columns.addItem('4 columnas',4);columns.setCurrentIndex(max(0,columns.findData(int(pref['dashboard_columns']))));dl.addWidget(label('Elija cuántas columnas y qué indicadores desea ver.','muted'));dl.addWidget(columns)
        try:hidden=set(json.loads(pref['dashboard_hidden']))
        except (TypeError,ValueError,json.JSONDecodeError):hidden=set()
        checks=[]
        metrics=list(self.store.dashboard(self.year_id()).keys()) if self.year_id() else []
        checks_grid=QGridLayout()
        for i,name in enumerate(metrics):
            check=QCheckBox(name);check.setChecked(name not in hidden);checks.append((name,check));checks_grid.addWidget(check,i//2,i%2)
        dl.addLayout(checks_grid);self.body.addWidget(dash)
        preview=QFrame();preview.setObjectName('metric');pl=QVBoxLayout(preview);pl.addWidget(label('Vista de lectura','metricLabel'));pl.addWidget(label('Texto claro, nítido y ajustable','brand'));pl.addWidget(label('También puede usar ⌘+ y ⌘− para cambiar el tamaño rápidamente.','muted'));self.body.addWidget(preview)
        def save():
            hidden_now=[name for name,check in checks if not check.isChecked()]
            self.store.save_appearance({'ui_scale':scale.currentData(),'ui_theme':theme.currentData(),'dashboard_columns':str(columns.currentData()),'dashboard_hidden':json.dumps(hidden_now,ensure_ascii=False)});self.appearance=apply_appearance(self.store);self.nav.setFixedWidth(self.sidebar_width());self.statusBar().showMessage('Apariencia actualizada.');self.render()
        bar=QHBoxLayout();bar.addWidget(button('Aplicar cambios',lambda:self.safe(save),True));bar.addWidget(button('Restablecer diseño',lambda:self.safe(lambda:self.store.save_appearance({'ui_scale':'comfortable','ui_theme':'ocean','dashboard_columns':'3','dashboard_hidden':'[]'}) or self.set_scale('comfortable'))));bar.addStretch();self.body.addLayout(bar);self.body.addStretch()
    def diagnostics_page(self):
        self.body.addWidget(label('Diagnóstico del sistema','title'));self.body.addWidget(label('Revisión local y no destructiva. No envía datos, no cambia registros y funciona sin internet.','muted'))
        checks=self.store.diagnostics();table=table_widget(['Componente','Estado','Detalle'],[[c['name'],c['status'],c['detail']] for c in checks]);self.body.addWidget(table,1)
        counts={status:sum(1 for item in checks if item['status']==status) for status in ('Correcto','Atención','Error')};summary=' · '.join(f'{status}: {count}' for status,count in counts.items() if count)
        self.body.addWidget(label(summary,'muted'))
        def save_report():
            path=save_dialog(self,'Guardar informe de diagnóstico',f"AulaLocal-diagnostico-{date.today()}.txt",'Texto (*.txt)')
            if not path:return
            lines=['AulaLocal · Diagnóstico local',local_now().isoformat(),f'Centro: {self.store.settings().get("centro","")}',*['%s | %s | %s'%(c['name'],c['status'],c['detail']) for c in checks]]
            atomic_write(path,('\n'.join(lines)+'\n').encode('utf-8'));QMessageBox.information(self,'Diagnóstico','Informe guardado correctamente.')
        bar=QHBoxLayout();bar.addWidget(button('Volver a analizar',self.render,True));bar.addWidget(button('Guardar informe',lambda:self.safe(save_report)));bar.addStretch();self.body.addLayout(bar)
    def edit_template(self,kind):
        s=self.store.settings();d=QDialog(self);d.setWindowTitle('Plantilla');d.resize(720,560);l=QVBoxLayout(d);l.addWidget(label('Conserva los nombres entre llaves para completar los datos automáticamente.','muted'));text=QTextEdit();text.setPlainText(s.get('template_'+kind,reports.DEFAULT_TEMPLATES[kind]));l.addWidget(text)
        l.addWidget(button('Restablecer texto original',lambda:text.setPlainText(reports.DEFAULT_TEMPLATES[kind])))
        buttons=QDialogButtonBox(QDialogButtonBox.Save|QDialogButtonBox.Cancel);buttons.accepted.connect(d.accept);buttons.rejected.connect(d.reject);l.addWidget(buttons)
        if d.exec()==QDialog.Accepted:
            from string import Formatter
            valid={'centro','director','direccion','telefono','año','codigo_estudiante','fecha_emision'}|{f.key for f in MODULES[kind][1]}
            try:
                for _,field,spec,conv in Formatter().parse(text.toPlainText()):
                    if field is not None and (field not in valid or spec or conv):raise ValueError()
            except ValueError:raise AppError('La plantilla contiene un campo no permitido.')
            self.store.save_settings({**s,'template_'+kind:text.toPlainText()})
    def users_page(self):
        self.body.addWidget(label('Usuarios y permisos','title'));users=self.store.users();t=table_widget(['Usuario','Nombre','Teléfono de referencia','Rol','Estado'],[[u['username'],u['name'],u.get('phone',''),ROLES[u['role']],'Activo' if u['active'] else 'Inactivo'] for u in users]);self.body.addWidget(t,1)
        def edit(existing=False):
            from .catalog import F
            u=None
            if existing:
                if t.currentRow()<0:raise AppError('Seleccione una cuenta.')
                u=users[t.currentRow()]
            values={} if not u else {**u,'role':ROLES[u['role']],'active':'Activo' if u['active'] else 'Inactivo'}
            f=Form(self,'Cuenta de usuario',[F('username','Usuario',required=True),F('name','Nombre',required=True),F('phone','Teléfono de recuperación (referencia local)'),F('role','Rol','choice',True,tuple(ROLES.values())),F('password','Nueva contraseña (vacío = conservar)','password'),F('active','Estado','choice',True,('Activo','Inactivo'))],values)
            while f.exec()==QDialog.Accepted:
                try:
                    d=f.values();role=next(k for k,v in ROLES.items() if v==d['role']);self.store.save_user(d['username'],d['name'],role,d['password'],d['active']=='Activo',u['id'] if u else None,d['phone']);self.render();return
                except AppError as e:error(f,e)
        def reset_password():
            if t.currentRow()<0:raise AppError('Seleccione una cuenta.')
            u=users[t.currentRow()];pw=ask_password(self,f"Nueva contraseña para {u['username']}:")
            if pw:self.store.reset_user_password(u['id'],pw);QMessageBox.information(self,'Contraseña actualizada','La cuenta deberá entrar con la contraseña nueva.')
        def recovery_key():
            pw=ask_password(self,'Confirma tu contraseña actual:')
            if pw:
                code=self.store.create_recovery_key(pw);QMessageBox.information(self,'Nuevo código de recuperación',f'Guárdalo fuera del Mac. El código anterior deja de funcionar.\n\n{code}')
        bar=QHBoxLayout();bar.addWidget(button('Nueva cuenta',lambda:self.safe(lambda:edit(False)),True));bar.addWidget(button('Editar cuenta',lambda:self.safe(lambda:edit(True))));bar.addWidget(button('Restablecer contraseña',lambda:self.safe(reset_password)));bar.addWidget(button('Generar código de recuperación',lambda:self.safe(recovery_key)));self.body.addLayout(bar)
        self.body.addWidget(label('El teléfono se guarda solo como referencia para la administración del centro: AulaLocal no envía SMS. Para no perder el acceso, conserve el código de recuperación y cree una segunda cuenta administradora de respaldo.','muted'))
    def audit_page(self):
        self.body.addWidget(label('Auditoría del año','title'));rows=self.store.audit(self.year_id());self.body.addWidget(table_widget(['Fecha local','Usuario','Acción','Detalle'],[[r['at_local'],r['usuario'],r['action'],r['detail']] for r in rows]),1)
        self.body.addWidget(label('Los cambios de datos conservan los valores anteriores y nuevos. Los eventos generales de acceso se incluyen al consultar toda la auditoría.','muted'))
        def all_audit():
            d=QDialog(self);d.setWindowTitle('Auditoría completa');d.resize(1000,600);l=QVBoxLayout(d);l.addWidget(table_widget(['Fecha local','Usuario','Acción','Año','Detalle'],[[r['at_local'],r['usuario'],r['action'],r['year_id'],r['detail']] for r in self.store.audit()]));d.exec()
        self.body.addWidget(button('Ver todos los eventos',lambda:self.safe(all_audit)))
    def backup_page(self):
        self.body.addWidget(label('Copias de seguridad','title'));self.body.addWidget(label('Guarda una copia cifrada en un archivo local o en un disco externo. Incluye todos los años, usuarios, configuraciones y adjuntos.','muted'))
        self.body.addWidget(button('Crear copia cifrada',lambda:self.safe(self.backup),True));self.body.addWidget(button('Restaurar desde archivo',lambda:self.safe(self.restore)))
        self.body.addWidget(label('La contraseña de la copia puede ser diferente a la de acceso. Sin ella no se puede recuperar el archivo. Antes de restaurar se conserva una copia del estado actual con esa misma contraseña.','muted'));self.body.addStretch()
        self.body.addWidget(label('Ubicación de datos: '+str(self.store.root),'muted'));self.body.addWidget(label('Los datos de trabajo no están cifrados por la aplicación. Protege el Mac con FileVault y una cuenta individual. Las copias .aulabackup sí están cifradas.','muted'))
    def backup(self):
        path=save_dialog(self,'Guardar copia cifrada',f"AulaLocal-{date.today()}.aulabackup",'Respaldo AulaLocal (*.aulabackup)')
        if not path:return
        pw=ask_password(self,'Contraseña para proteger esta copia (mínimo 12 caracteres):')
        if pw is None:return
        again=ask_password(self,'Repita la contraseña de la copia:')
        if again is None:return
        if pw!=again:raise AppError('Las contraseñas no coinciden.')
        create_backup(self.store,path,pw);QMessageBox.information(self,'Respaldo completo','Copia cifrada guardada correctamente.')
    def restore(self):
        path,_=QFileDialog.getOpenFileName(self,'Abrir respaldo','','Respaldo AulaLocal (*.aulabackup)')
        if not path:return
        if QMessageBox.question(self,'Restaurar datos','Se sustituirán TODOS los años y cuentas por los del respaldo. Se conservará una copia previa. ¿Desea continuar?')!=QMessageBox.Yes:return
        current=ask_password(self,'Contraseña actual de administrador:')
        if current is None:return
        pw=ask_password(self,'Contraseña del archivo de respaldo:')
        if pw is None:return
        recovery=restore_backup(self.store,path,pw,current);QMessageBox.information(self,'Restauración completa',f'Inicie sesión con una cuenta del respaldo.\nCopia previa: {recovery.name}');self.lock()

def run(data_dir=None):
    app=QApplication(sys.argv);app.setApplicationName('AulaLocal');app.setOrganizationName('AulaLocal');app.setStyle('Fusion');apply_appearance();app.setQuitOnLastWindowClosed(False)
    root=Path(data_dir or app_directory());root.mkdir(parents=True,exist_ok=True)
    lock=QLockFile(str(root/'application.lock'));lock.setStaleLockTime(0)
    if not lock.tryLock(100):QMessageBox.information(None,'AulaLocal','La aplicación ya está abierta con estos datos.');return 1
    try:
        store=Store(root)
        if not store.user:
            login=Login(store)
            if login.exec()!=QDialog.Accepted:store.close();return 0
        window=MainWindow(store);app.main_window=window;window.show();app.setQuitOnLastWindowClosed(True)
        result=app.exec();store.close();return result
    except Exception as e:QMessageBox.critical(None,'AulaLocal','No se pudo abrir la aplicación: '+str(e));return 1
    finally:lock.unlock()
