# AulaLocal 0.9.2

AulaLocal es una aplicación de gestión integral para centros educativos que funciona localmente en Mac Apple Silicon. Los datos, adjuntos, reportes y copias permanecen en el equipo; el uso cotidiano no necesita internet.

## Funciones incluidas

- Panel de Dirección con indicadores calculados desde los registros reales y tarjetas que abren directamente su detalle filtrado.
- Apariencia por usuario con cuatro tamaños de texto, cinco paletas —incluido alto contraste—, atajos de zoom y widgets configurables.
- Diagnóstico local de base de datos, relaciones, escritura, espacio, equipo, reloj y privacidad, con informe guardable.
- Estudiantes por año escolar, nivel, grado y sección; edad actual calculada automáticamente desde el reloj del Mac, edad al inicio del ciclo y rango esperado.
- Catálogo académico editable: Nivel Inicial, Primario y Secundario precargados, con capacidad para crear otros grados y secciones.
- Importación masiva desde Excel o CSV para estudiantes y personal, con plantillas listas para completar.
- Personal y asistencia con importación automática del Excel/CSV del ponchador, agrupación de entrada/salida, detección de tardanzas, revisión previa e informes por período.
- Planificación semanal del almuerzo INABIE separada por fecha y día, comparación con la entrega del suplidor, diferencias, cumplimiento, cantidades y observaciones.
- Evidencias integradas en cada pestaña diaria del menú: selección múltiple, miniaturas, previsualización grande, reproducción y guardado conjunto del día.
- Varias fotos y videos MOV/MP4/M4V para almuerzo, pan, leche, otros alimentos y entregas generales; apertura local y PDF organizado por semana y día.
- Indicador de recepciones sin evidencia, conteo visible y detección automática de archivos duplicados.
- Tablas ordenables alfabética, numérica o cronológicamente; columnas movibles, redimensionables y autoajustables con el mouse.
- Eliminación segura y recuperable en todos los módulos, con restauración, conservación de vínculos y auditoría.
- Entregas generales de mobiliario, equipos, materiales, donaciones o cualquier otro bien.
- Agenda con recordatorios locales y acompañamiento docente con resultados, acuerdos y seguimiento.
- Asistente local privado para abrir módulos, explicar funciones, crear recordatorios y preparar reportes.
- Ayuda e instructivo integrado dentro de la aplicación.
- Planta física y registro de visitantes.
- Gastos, facturas y adjuntos.
- PDF, Excel, certificaciones, constancias y archivo histórico por año.
- Años abiertos, congelados o archivados, sin mezclar información.
- Usuarios por rol y teléfono de referencia local, auditoría, código de recuperación, administrador alterno y sesión persistente hasta cerrar sesión explícitamente.
- Copias de seguridad cifradas y restauración local.
- Reloj y zona horaria tomados del sistema macOS.

## Instalación

Use `AulaLocal-0.9.2-arm64.dmg` y arrastre AulaLocal a Aplicaciones. La guía completa está en [docs/INSTALACION.md](docs/INSTALACION.md).

Documentos del proyecto:

- [Manual de uso](docs/MANUAL.md)
- [Arquitectura y seguridad](docs/ARQUITECTURA.md)
- [Pruebas realizadas](docs/PRUEBAS.md)
- [Lista de aceptación Mac](docs/ACEPTACION_MAC.md)

## Desarrollo y pruebas

```bash
python -m pip install -r requirements-build.txt
QT_QPA_PLATFORM=offscreen python -m pytest -q
```

`scripts/build_macos.sh` ejecuta las pruebas, crea la aplicación ARM64, verifica su arquitectura y firma, ejecuta una validación offline del bundle y genera DMG y PKG. Si se proporcionan credenciales Apple, también admite Developer ID y notarización; sin ellas aplica una firma técnica local.

Las capturas y documentos de prueba contienen exclusivamente datos ficticios. No existe una cuenta predeterminada. Las dependencias y licencias se describen en `THIRD_PARTY.md`.

## Asistente 0.9.2: alcance real

El chat permite adjuntar evidencias, preparar formularios y confirmar registros.
El modo básico utiliza reglas. El modo neuronal conecta exclusivamente con Ollama
en 127.0.0.1:11434 y requiere un modelo descargado en el Mac. El instalador no
incluye Ollama ni pesos de IA. Pulse Detectar motor local para listar modelos.
No se interpretan imágenes ni videos: se conservan como evidencias del registro.
Las respuestas se revisan antes de guardar; la IA puede equivocarse. Solo admite
creación de un borrador por solicitud, sin edición/eliminación autónoma ni memoria conversacional.

Se probaron validación de respuestas simuladas, permisos de operaciones, cancelación,
conservación de planes existentes y rollback. No se ha validado la calidad de un
modelo real ni su rendimiento en Mac. No se presenta como una IA completa lista
para producción. Documentación del protocolo: https://docs.ollama.com/capabilities/structured-outputs
